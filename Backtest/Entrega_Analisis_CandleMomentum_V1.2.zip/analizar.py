from pathlib import Path
import xml.etree.ElementTree as ET
import hashlib, json, re, itertools, sys
import numpy as np
import pandas as pd

OUT=Path(__file__).resolve().parent
BASE=OUT.parent
SS='urn:schemas-microsoft-com:office:spreadsheet'
NS={'s':SS,'o':'urn:schemas-microsoft-com:office:office'}
TF=['M1','M3','M5','M15','M30','H1','H2','H4']
PARAMS=['InpSignalTimeframe','InpMinBodyPercent','InpMinRangeATR','InpRR']
METRICS=['Result','Profit','Expected Payoff','Profit Factor','Recovery Factor','Sharpe Ratio','Custom','Equity DD %','Trades']
frames=[]; meta=[]; rawframes=[]
for path in sorted(BASE.glob('*.xml')):
    data=path.read_bytes()
    namespaces=[{'prefix':p,'uri':u} for _,(p,u) in ET.iterparse(path,events=['start-ns'])]
    root=ET.fromstring(data)
    assert root.tag=='{'+SS+'}Workbook'
    props={x.tag.split('}')[-1]:x.text for x in root.find('o:DocumentProperties',NS)}
    m={'file':path.name,'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data),'namespaces':namespaces,'properties':props,'sheets':[]}
    year=int(re.search(r'20\d{2}',path.name).group())
    for ws in root.findall('s:Worksheet',NS):
        rows=[]; types=[]; positions=[]; physical=0
        table=ws.find('s:Table',NS)
        for row in table.findall('s:Row',NS):
            physical=int(row.get('{'+SS+'}Index',physical+1))
            cells=[]; ct=[]; ix=0
            for cell in row.findall('s:Cell',NS):
                ix=int(cell.get('{'+SS+'}Index',ix+1))
                while len(cells)<ix-1: cells.append(None);ct.append(None)
                node=cell.find('s:Data',NS)
                cells.append(''.join(node.itertext()) if node is not None else None)
                ct.append(node.get('{'+SS+'}Type') if node is not None else None)
                merge=int(cell.get('{'+SS+'}MergeAcross',0))
                cells.extend([None]*merge);ct.extend([None]*merge);ix+=merge
            rows.append(cells);types.append(ct);positions.append(physical)
        headers=rows[0]
        assert headers==['Pass']+METRICS+PARAMS, headers
        assert all(len(x)==len(headers) for x in rows[1:]), 'Incomplete rows'
        raw=pd.DataFrame(rows[1:],columns=headers)
        df=raw.apply(pd.to_numeric,errors='coerce')
        df.insert(0,'XML_Row',positions[1:]);df.insert(0,'SourceFile',path.name);df.insert(0,'Year',year)
        raw.insert(0,'SourceFile',path.name)
        rawframes.append(raw);frames.append(df)
        m['sheets'].append({'name':ws.get('{'+SS+'}Name'),'table_attributes':table.attrib,'rows_including_header':len(rows),'passes':len(df),'headers':headers,'cell_types':sorted(set(t for row in types[1:] for t in row if t)),'missing_cells':int((raw.isna()|raw.eq('')).sum().sum()),'invalid_numeric':int(df[headers].isna().sum().sum()),'duplicate_passes':int(df.Pass.duplicated().sum()),'parameter_values':{c:sorted(df[c].unique().tolist()) for c in PARAMS}})
    meta.append(m)
D=pd.concat(frames,ignore_index=True)
D['TF']=D.InpSignalTimeframe.map(dict(enumerate(TF)))
assert D.TF.notna().all()
D['ID']=D.Year.astype(str)+':'+D.Pass.astype(int).astype(str)
assert D.ID.is_unique
if '--inspect' in sys.argv:
    print(json.dumps(meta,ensure_ascii=False,indent=2))
    print(D.groupby('Year')[METRICS].agg(['min','median','max']).to_string())
    print('full_grid',np.prod([D[c].nunique() for c in PARAMS]),'unique_parameter_sets',len(D[PARAMS].drop_duplicates()))
OUT.mkdir(exist_ok=True)
(OUT/'Auditoria_XML.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding='utf-8')
D.to_pickle(OUT/'datos.pkl')
if '--inspect' in sys.argv: sys.exit(0)

def csv(df,name):
    df.to_csv(OUT/(name+'.csv'),index=False,encoding='utf-8-sig')
def summarize(g):
    distinct=g.MetricGroup.nunique()
    return pd.Series({'Pases':len(g),'Positivos':int(g.Profit.gt(0).sum()),'Negativos':int(g.Profit.lt(0).sum()),'Cero':int(g.Profit.eq(0).sum()),'Rentables_pct':g.Profit.gt(0).mean()*100,'Profit_mediana':g.Profit.median(),'PF_mediana':g.PF_interpretable_value.median(),'DD_mediana':g['Equity DD %'].median(),'Trades_mediana':g.Trades.median(),'N50_pct':g.Trades.ge(50).mean()*100,'N100_pct':g.Trades.ge(100).mean()*100,'N200_pct':g.Trades.ge(200).mean()*100,'Sin_trades':int(g.Trades.eq(0).sum()),'Metricas_ausentes_invalidas':int(g.InvalidMetric.sum()),'PF_no_interpretable':int((~g.PF_interpretable).sum()),'DD20':int(g['Equity DD %'].gt(20).sum()),'DD50':int(g['Equity DD %'].gt(50).sum()),'Distintos':distinct,'Redundantes':len(g)-distinct,'Redundancia_pct':100*(1-distinct/len(g)),'Favorables50':int(g.Favorable50.sum())})

D['InvalidMetric']=~np.isfinite(D[METRICS]).all(axis=1)
D['PF_interpretable']=np.isfinite(D['Profit Factor']) & D['Profit Factor'].ge(0) & D['Profit Factor'].lt(1e6) & D.Trades.gt(0)
D['PF_interpretable_value']=D['Profit Factor'].where(D.PF_interpretable)
D['Favorable50']=(D.Profit.gt(0)&D['Expected Payoff'].gt(0)&D['Profit Factor'].gt(1)&D.PF_interpretable&D.Trades.ge(50)&D['Equity DD %'].le(20)&~D.InvalidMetric)
D['MetricSignature']=D[METRICS].apply(lambda r:hashlib.sha256('|'.join('MISSING' if pd.isna(v) else float(v).hex() for v in r).encode()).hexdigest(),axis=1)
D['MetricGroup']=D.Year.astype(str)+':'+D.MetricSignature
D['MetricGroupSize']=D.groupby('MetricGroup').ID.transform('size')
D['MetricRepresentative']=D.groupby('MetricGroup').Pass.transform('min')
D['RedundantExtra']=D.Pass.ne(D.MetricRepresentative)
assert not D.duplicated(['Year']+PARAMS).any()
grids={year:set(map(tuple,g[PARAMS].to_numpy())) for year,g in D.groupby('Year')}
assert all(x==grids[2023] for x in grids.values())
expected=set(itertools.product(*[sorted(D[c].unique()) for c in PARAMS]))
assert grids[2023]==expected
assert D.groupby('Pass')[PARAMS].nunique().max().max()==1
assert np.allclose(D.Result,D.Custom.round(2),atol=1e-9)
score_expected=np.where(D.Trades<50,-1e6+D.Trades/50,D['Recovery Factor']*np.minimum(1,D.Trades/100))
score_error=np.abs(D.Custom-score_expected)
print('SCORE approximation using rounded recovery: max error',score_error.max(),'mismatches >2e-6',int((score_error>2e-6).sum()))
csv(D[D.MetricGroupSize>1].sort_values(['Year','MetricRepresentative','Pass']),'Pases_Redundantes')
SUMMARY=D.groupby('Year').apply(summarize,include_groups=False).reset_index()
BYTF=D.groupby('TF',sort=False).apply(summarize,include_groups=False).reindex(TF).reset_index()
BYTFYEAR=D.groupby(['Year','TF']).apply(summarize,include_groups=False).reset_index()
csv(SUMMARY,'Resumen_Anual');csv(BYTF,'Resumen_Temporalidad');csv(BYTFYEAR,'Resumen_Anual_Temporalidad')
DIST=[]
for year,g in [('TODOS',D)]+list(D.groupby('Year')):
    for col in METRICS:
        v=g[col].where(np.isfinite(g[col])).dropna()
        DIST.append({'Periodo':year,'Metrica':col,'N_validos':len(v),'N_ausentes_invalidos':len(g)-len(v),'Media':v.mean(),'Desvio':v.std(),'Min':v.min(),'P05':v.quantile(.05),'P25':v.quantile(.25),'Mediana':v.median(),'P75':v.quantile(.75),'P95':v.quantile(.95),'Max':v.max()})
csv(pd.DataFrame(DIST),'Distribuciones_Metricas')
rawall=pd.concat(rawframes,ignore_index=True)
issues=[]
for idx,row in D[D.InvalidMetric].iterrows():
    for col in METRICS:
        if not np.isfinite(row[col]): issues.append({'ID':row.ID,'SourceFile':row.SourceFile,'XML_Row':row.XML_Row,'Pass':row.Pass,'Column':col,'Raw':rawall.iloc[idx][col],'Reason':'Celda vacía' if rawall.iloc[idx][col] in ['',None] else 'No finito o no numérico'})
csv(pd.DataFrame(issues),'Incidencias_Calidad')

# Comparaciones emparejadas: solo cambia un parámetro, se conserva año y el resto.
PAIRS=[]; CONDITIONAL=[]
for p in PARAMS:
    keys=['Year']+[q for q in PARAMS if q!=p]
    for key,g in D.groupby(keys):
        g=g.sort_values(p)
        fixed=dict(zip(keys,key))
        k=g.MetricSignature.nunique()
        CONDITIONAL.append({**fixed,'Parametro':p,'N':len(g),'Resultados_distintos':k,'Exceso_redundante':len(g)-k,'Valores':'|'.join(map(str,g[p]))})
        rows=list(g.to_dict('records'))
        for a,b in zip(rows,rows[1:]):
            rec={**fixed,'Parametro':p,'TF':a['TF'] if p!='InpSignalTimeframe' else a['TF']+'→'+b['TF'],'Desde':a[p],'Hasta':b[p],'ID_A':a['ID'],'ID_B':b['ID'],'Pass_A':a['Pass'],'Pass_B':b['Pass'],'Identicos':a['MetricSignature']==b['MetricSignature'],'Trades_min':min(a['Trades'],b['Trades']),'Profit_A':a['Profit'],'Profit_B':b['Profit'],'Cambio_signo':a['Profit']*b['Profit']<0,'Ambos_favorables50':a['Favorable50'] and b['Favorable50']}
            for c in ['Profit','Profit Factor','Equity DD %','Trades','Expected Payoff']:
                rec['Delta_'+c]=b[c]-a[c]
            rec['AbsDeltaProfit']=abs(rec['Delta_Profit'])
            rec['AbsDeltaProfit_pctdeposito']=rec['AbsDeltaProfit']/1000
            rec['Drastico']=rec['AbsDeltaProfit']>=1000
            rec['Similar']=rec['AbsDeltaProfit']<=500 and abs(rec['Delta_Profit Factor'])<=.1 and abs(rec['Delta_Equity DD %'])<=1
            PAIRS.append(rec)
P=pd.DataFrame(PAIRS)
csv(P,'Comparaciones_Vecinos');csv(pd.DataFrame(CONDITIONAL),'Redundancia_Condicional')
def pairsummary(g):
    return pd.Series({'Pares':len(g),'Identicos':int(g.Identicos.sum()),'Identicos_pct':100*g.Identicos.mean(),'DeltaProfit_mediana':g.Delta_Profit.median(),'AbsDeltaProfit_mediana':g.AbsDeltaProfit.median(),'AbsDeltaProfit_P90':g.AbsDeltaProfit.quantile(.9),'DeltaPF_mediana':g['Delta_Profit Factor'].median(),'DeltaDD_mediana':g['Delta_Equity DD %'].median(),'DeltaTrades_mediana':g.Delta_Trades.median(),'DeltaEP_mediana':g['Delta_Expected Payoff'].median(),'Cambio_signo_pct':100*g.Cambio_signo.mean(),'Drastico_pct':100*g.Drastico.mean(),'Similares_pct':100*g.Similar.mean(),'Ambos_favorables50_pct':100*g.Ambos_favorables50.mean(),'N50_ambos':int(g.Trades_min.ge(50).sum())})
PS=P.groupby(['Parametro','TF']).apply(pairsummary,include_groups=False).reset_index();csv(PS,'Sensibilidad_Parametro_TF')
PI=P.groupby(['Parametro','TF','Desde','Hasta']).apply(pairsummary,include_groups=False).reset_index();csv(PI,'Sensibilidad_Intervalos')
csv(P[P.Identicos],'Intervalos_Sin_Cambio')
csv(P[P.Drastico].sort_values('AbsDeltaProfit',ascending=False),'Cambios_Importantes')

# Vecindad axial, no interpretar como trades independientes ni mezclar temporalidades.
edges=P[P.Parametro!='InpSignalTimeframe']
neighbors={id:[] for id in D.ID}
for r in edges.itertuples(): neighbors[r.ID_A].append(r.ID_B);neighbors[r.ID_B].append(r.ID_A)
lookup=D.set_index('ID')
stability=[]
for id,ids in neighbors.items():
    g=lookup.loc[ids];center=lookup.loc[id]
    stability.append({'ID':id,'NeighborCount':len(ids),'NeighborPositivePct':100*g.Profit.gt(0).mean(),'NeighborFavorable50Pct':100*g.Favorable50.mean(),'NeighborProfitMedian':g.Profit.median(),'NeighborProfitMin':g.Profit.min(),'NeighborTradesMin':g.Trades.min(),'NeighborAbsDeltaProfitMedian':(g.Profit-center.Profit).abs().median(),'NeighborIDs':'|'.join(ids)})
D=D.merge(pd.DataFrame(stability),on='ID',validate='one_to_one')
csv(D.sort_values(['Year','Pass']),'Optimizacion_Procesada')
csv(D[['ID','Pass','Year','TF']+PARAMS[1:]+list(pd.DataFrame(stability).columns[1:])],'Estabilidad_Vecindad')

# Resumen de familias idénticas en cuatro períodos; NO cartera concatenada.
CF=[]
for key,g in D.groupby(PARAMS):
    keydict=dict(zip(PARAMS,key));gs=g.sort_values('Year')
    rec={**keydict,'TF':g.TF.iloc[0],'Pass':int(g.Pass.iloc[0]),'Periodos':len(g),'PeriodosPositivos':int(g.Profit.gt(0).sum()),'PeriodosFavorables50':int(g.Favorable50.sum()),'TradesMin':g.Trades.min(),'TradesMediana':g.Trades.median(),'PFmin':g.PF_interpretable_value.min(),'PFmediana':g.PF_interpretable_value.median(),'ProfitMin':g.Profit.min(),'ProfitMediana':g.Profit.median(),'DDmax':g['Equity DD %'].max(),'EPmin':g['Expected Payoff'].min(),'VecinosFavorablesMediana':g.NeighborFavorable50Pct.median(),'VecinosFavorablesMin':g.NeighborFavorable50Pct.min(),'VecinosProfitMin':g.NeighborProfitMin.min(),'VecinosDeltaMediana':g.NeighborAbsDeltaProfitMedian.median(),'Profile':'|'.join(gs.MetricSignature)}
    for _,r in gs.iterrows():
        for c in ['Profit','Profit Factor','Equity DD %','Trades','Expected Payoff','NeighborFavorable50Pct']:
            rec[str(r.Year)+'_'+c]=r[c]
    CF.append(rec)
C=pd.DataFrame(CF)
csv(C.drop(columns='Profile'),'Consistencia_Entre_Periodos')
SENS=[]
for year,g in [('TODOS',D)]+list(D.groupby('Year')):
    for n in [50,100,200]:
        ok=g.Trades.ge(n); fav=g.Favorable50&ok
        SENS.append({'Periodo':year,'MinTrades':n,'ConMuestra':int(ok.sum()),'Positivos':int((ok&g.Profit.gt(0)).sum()),'Favorables':int(fav.sum()),'Rentables_pct_condicional':100*g.loc[ok].Profit.gt(0).mean(),'Favorables_vecindad50ge67':int((fav&g.NeighborFavorable50Pct.ge(200/3-1e-9)).sum())})
csv(pd.DataFrame(SENS),'Sensibilidad_Muestra')
for param in PARAMS[1:]:
    cols=['Year','TF',param]
    ag=D.groupby(cols).agg(Pases=('ID','size'),Profit_mediana=('Profit','median'),PF_mediana=('PF_interpretable_value','median'),DD_mediana=('Equity DD %','median'),Trades_mediana=('Trades','median'),EP_mediana=('Expected Payoff','median'),Rentables_pct=('Profit',lambda x:100*x.gt(0).mean()),N50_pct=('Trades',lambda x:100*x.ge(50).mean()),Favorables50=('Favorable50','sum')).reset_index()
    csv(ag,'Marginal_'+param)
for a,b in itertools.combinations(PARAMS,2):
    ag=D.groupby(['Year',a,b]).agg(Pases=('ID','size'),Profit_mediana=('Profit','median'),PF_mediana=('PF_interpretable_value','median'),Trades_mediana=('Trades','median'),DD_mediana=('Equity DD %','median'),Favorables50=('Favorable50','sum')).reset_index()
    csv(ag,'Cruce_'+a+'_'+b)
# Spearman descriptivo dentro de familia; sin p-values (dependencia entre pases).
COR=[]
for p in PARAMS[1:]:
    for key,g in D.groupby(['Year']+[q for q in PARAMS if q!=p]):
        for m in ['Profit','PF_interpretable_value','Equity DD %','Trades','Expected Payoff']:
            valid=g[[p,m]].dropna()
            rho=valid.rank().corr().iloc[0,1] if valid[m].nunique()>1 else np.nan
            COR.append({'Year':key[0],'TF':g.TF.iloc[0],'Parametro':p,'Metrica':m,'Rho':rho})
COR=pd.DataFrame(COR)
csv(COR.groupby(['Parametro','TF','Metrica']).Rho.agg(['count','median','min','max']).reset_index(),'Correlaciones_Condicionales')
print('ANUAL\n',SUMMARY.to_string(index=False));print('TF\n',BYTF.to_string(index=False))
print('POS PERIODS\n',C.groupby('PeriodosPositivos').size().to_string())
print('PROMISING\n',C[(C.PeriodosPositivos>=3)&(C.TradesMin>=50)].sort_values(['PeriodosFavorables50','VecinosFavorablesMin','ProfitMin'],ascending=False).head(35).drop(columns='Profile').to_string(index=False))
print('PAIR SUMMARY\n',P.groupby('Parametro').apply(pairsummary,include_groups=False).to_string())
D.to_pickle(OUT/'datos.pkl');C.to_pickle(OUT/'configuraciones.pkl')
