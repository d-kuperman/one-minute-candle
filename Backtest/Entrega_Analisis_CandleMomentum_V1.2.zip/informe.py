from pathlib import Path
import pandas as pd,numpy as np,json
O=Path(__file__).resolve().parent
D=pd.read_pickle(O/'datos.pkl');C=pd.read_pickle(O/'configuraciones.pkl')
def read(s):return pd.read_csv(O/(s+'.csv'))
S=read('Top_20_Candidatos');A=read('Resumen_Anual');T=read('Resumen_Temporalidad');TY=read('Resumen_Anual_Temporalidad');P=read('Comparaciones_Vecinos');PS=read('Sensibilidad_Parametro_TF');PI=read('Sensibilidad_Intervalos');R=read('Regiones_ATR_Favorables');B=read('Regiones_Rectangulares');E=read('Descomposicion_Varianza_Profit');V=read('Sensibilidad_Muestra_Vecinos')
TF=['M1','M3','M5','M15','M30','H1','H2','H4'];MET=['Result','Profit','Expected Payoff','Profit Factor','Recovery Factor','Sharpe Ratio','Custom','Equity DD %','Trades']
def fmt(x):
    if pd.isna(x):return 'n/d'
    if isinstance(x,(float,np.floating)):
        if x==int(x):return f'{x:,.0f}'
        return f'{x:,.3f}' if abs(x)<10 else f'{x:,.2f}'
    return str(x).replace('|',' / ').replace('\n',' ')
def table(df):
    return '| '+' | '.join(map(str,df.columns))+' |\n| '+' | '.join(['---']*len(df.columns))+' |\n'+'\n'.join('| '+' | '.join(fmt(x) for x in row)+' |' for row in df.itertuples(index=False,name=None))
def fig(name,desc):return f'\n![{desc}](Graficos/{name}.png)\n'
def short(df,cols,rename=None):return table(df[cols].rename(columns=rename or {}))
parts=[]
def add(x):parts.append(x.strip())

add(f'''# Informe Candle Momentum Research V1.2 — EURUSD

**Fecha del análisis:** 18 de octubre de 2026. **Universo:** cuatro exportaciones completas de MT5, 2023–2026. **Estado:** exploración retrospectiva; ninguna configuración validada para operar en real.

## 1. Resumen ejecutivo

**Hechos comprobados.** Hay **12.960 pases**, 3.240 por archivo, con una malla balanceada de 8 temporalidades, 5 cuerpos, 9 mínimos ATR y 9 RR. Las mismas 3.240 configuraciones aparecen en cada período. El encabezado M5 es el gráfico del tester, no la temporalidad de señal de cada pase. 2026 termina el **17/10/2026**, por lo que no representa un año completo.

**Cálculos derivados.** {D.Profit.gt(0).sum():,} pases ({100*D.Profit.gt(0).mean():.2f}%) tienen Profit positivo; {D.Profit.lt(0).sum():,} negativo y {D.Trades.eq(0).sum()} no operan. Solo **830** cumplen simultáneamente Profit>0, PF>1, Expected Payoff>0, DD≤20% y al menos 50 trades. Son **424** con 100 y **119** con 200. Ninguna configuración gana en los cuatro períodos y alcanza 50 trades en cada uno. La única positiva en los cuatro, pase 1838, tiene 13–21 trades por período.

**Cálculos derivados.** Hay **585 pases excedentes redundantes (4,51%)** y **719 filas pertenecientes a grupos duplicados (5,55%)**. Son conceptos diferentes. H4 concentra 392 excedentes y H2 178. No hay duplicados de métricas en M1, M3, M5 ni M15. El ATR cambia las métricas en 11.198 de 11.520 comparaciones adyacentes controladas (97,20%); por sí solo esto no demuestra mejores señales ni ventaja sobre pips.

**Interpretación.** La evidencia más interesante aparece en **M30** y algunas regiones de **M15/H1**, pero depende fuertemente del período. La región M30 de cuerpo 75–85%, ATR aproximadamente 1,75–2,25 y RR 2–3 contiene familias prometedoras; no es favorable en todo ese rectángulo ni en todos los años. **2024 contradice buena parte de esa hipótesis.** H4 parece mejor si se cuenta cualquier ganancia, pero su mediana es apenas 15 trades. M1 pierde en sus 1.620 pases observados.

**Limitaciones comprobadas.** Se exportaron únicamente `InpSignalTimeframe`, `InpMinBodyPercent`, `InpMinRangeATR` e `InpRR`. Faltan el modo de filtro y los valores fijos del run. Hay 72 PF vacíos en pases sin operaciones y **46 discrepancias entre Expected Payoff y Profit/Trades**, todas con 1–4 trades. No hay telemetría real vinculada a estas optimizaciones. Los CSV de ejemplo Research son sintéticos y se excluyeron.

**Recomendación.** Se proponen **15 representantes**, cinco con tres períodos positivos y diez controles de hipótesis locales. No son un ranking de ganancias ni 15 estrategias aprobadas. Primero recuperar la configuración exacta y reconciliar operaciones/costos; después ejecutar un protocolo previamente fijado en datos no utilizados para seleccionar parámetros.

Convención numérica: las tablas usan punto decimal y coma de miles. Los CSV usan coma como separador, punto decimal, UTF-8 con BOM y preservan el número original de pase. `Año:Pase` identifica un resultado sin ambigüedad.''')

add('''## 2. Validación del archivo

### Estructura y cobertura

Se leyó cada archivo completo con un parser XML consciente de SpreadsheetML. La raíz es `Workbook` del namespace `urn:schemas-microsoft-com:office:spreadsheet`. Se respetan los namespaces `o`, `x`, `ss` y `html`; el namespace por defecto cambia localmente a `office` dentro de DocumentProperties y vuelve al de spreadsheet fuera de él. Cada archivo tiene una hoja **Tester Optimizator Results**, una `Table`, una fila de encabezados y 3.240 filas de datos: **3.241 filas de hoja**. No hay filas truncadas ni columnas desplazadas. Las métricas son `Number`, salvo las celdas PF vacías exportadas como `String` en 2024 y 2026.

Los pases cubren 0–3239, sin repeticiones dentro de cada año. Se verificó el producto cartesiano íntegro y la correspondencia del mismo pase con los mismos cuatro parámetros en los cuatro archivos. Por tanto, **la cobertura observada es exhaustiva de esta malla**. Esto aporta evidencia fuerte a favor de una búsqueda completa, pero el archivo no registra el selector del algoritmo: no se afirma que se haya confirmado “Slow complete” frente a genética. `Condition=0` se conserva sin asignarle un significado no verificado.

### Metadatos''')
meta=json.loads((O/'Auditoria_XML.json').read_text(encoding='utf-8'))
add(table(pd.DataFrame([{'Archivo':m['file'],'Período declarado':m['properties']['Title'].split()[-1],'Depósito':m['properties']['Deposit'],'Apalancamiento':'1:'+m['properties']['Leverage'],'Pases':m['sheets'][0]['passes']} for m in meta])))
add('''Instrumento EURUSD; EA `CandleMomentum_Research_v1_2`; gráfico del tester M5; servidor `FivePercentOnline-Real`. Se conserva el nombre de servidor, pero **no demuestra que estos resultados procedan de una cuenta real operativa**. No se exportan número de cuenta, modo hedging/netting, modelo de ticks, calidad del histórico, latencia, comisiones ni configuración completa. `Version=500` y `Build=64` son campos del XML; no se usan para certificar el build del terminal. Las fechas declaradas no prueban cobertura de ticks hasta el último segundo ni excluyen un desplazamiento del inicio por falta de histórico.

Los presets `Original_Pips.set`, `RangeATR.set` y `Research.set` son ejemplos generales. Los INI de `validation` corresponden a pruebas del 12–13/10/2026, no a las cuatro optimizaciones. No se trasladan sus valores a estas corridas.

### Columnas originales

`Pass`, `Result`, `Profit`, `Expected Payoff`, `Profit Factor`, `Recovery Factor`, `Sharpe Ratio`, `Custom`, `Equity DD %`, `Trades`, `InpSignalTimeframe`, `InpMinBodyPercent`, `InpMinRangeATR`, `InpRR`.

### Integridad y conciliación

Los hashes SHA-256 anteriores y posteriores coinciden en los cuatro XML. Se releen las exportaciones y se comparan **181.440 celdas originales (12.960 × 14) por texto exacto**, incluidos decimales y vacíos. `Optimizacion_Procesada.csv` conserva estas representaciones y agrega columnas derivadas, fuente y fila XML. Se verificaron los 15 candidatos y sus 60 registros de los cuatro períodos contra el origen. Los controles están en `Verificacion_Exportaciones.json` y el inventario en `Auditoria_XML.json`.

Hay **72 celdas ausentes**, todas PF: 27 en 2024 y 45 en 2026. No hay valores numéricos no finitos ni negativos imposibles en trades/DD; los DD quedan entre 0 y 100. Los 72 pases sin trades no son evidencia de rentabilidad ni se rellenan con PF=0.

La identidad Expected Payoff=Profit/Trades se cumple dentro del redondeo de seis decimales en 12.842 de los 12.888 pases con trades. **Falla en 46**: 41 H4/2024 con un trade y 5 H2/2025 con 1–4 trades. Ejemplo: `2024:3119`, Profit=434,45, Trades=1, Expected Payoff=435,73, PF=340,414062. Diferencia=1,28 USD/trade. Es compatible con diferencias de imputación contable, pero su causa no está demostrada. Se preserva la métrica original y se añade `NetPayoffDerived=Profit/Trades`, sin corregir silenciosamente. Ver `Discrepancias_ExpectedPayoff.csv`. Estos pases no llegan al filtro mínimo de 50 trades.''')

add('''## 3. Descripción de parámetros y criterio de optimización

### Parámetros efectivamente variados''')
inv=read('Resumen_Parametros');add(short(inv[inv.Presente_XML],['Parametro','Valores_XML','Min_XML','Max_XML','N_valores_XML'],{'Valores_XML':'Valores observados','Min_XML':'Mínimo','Max_XML':'Máximo','N_valores_XML':'Valores distintos'}))
add('''El enum del código local mapea 0=M1, 1=M3, 2=M5, 3=M15, 4=M30, 5=H1, 6=H2 y 7=H4. No son los enteros de `ENUM_TIMEFRAMES` estándar. La malla usa cuerpo 75–95 en pasos de 5 puntos porcentuales; ATR 0,5–2,5 en pasos de 0,25; RR 1–5 en pasos de 0,5. Cada TF tiene 405 pases por año, cada celda TF×ATR 45, TF×cuerpo 81 y TF×RR 45. Los cruces originales están equilibrados; los subconjuntos N≥50/100/200 dejan de estarlo.

### Qué documenta el código y qué no documentan las corridas

En el fuente disponible, cuerpo = 100·|Close−Open|/(High−Low). La vela gatillo es la cerrada `shift=1`; RangeATR=(High−Low)/ATR, con ATR anterior `shift=2` en la misma temporalidad de señal. El período ATR es configurable y no está exportado. Los umbrales son inclusivos con tolerancia numérica. El SL es el extremo de la vela y el TP usa el RR solicitado, redondeado al tick. No hay EMA ni trailing. Las restricciones de posiciones simultáneas, dirección, margen, spread y ejecución pueden cambiar qué señales llegan a ser trades.

**Riesgo monetario:** el EA contiene `InpRiskPercent`, un porcentaje del balance anterior a la operación; no un importe fijo por trade. El importe efectivo depende del balance, SL, tamaño de contrato y redondeo de volumen. Su valor usado aquí no consta. El default 1% no se trata como valor confirmado.

| Filtro del código | Parámetros de rango activos | Parámetros de rango irrelevantes |
|---|---|---|
| PIPS | Mínimo/máximo pips | Mínimo/máximo ATR para selección |
| ATR | Mínimo/máximo ATR y período ATR | Mínimo/máximo pips |
| PIPS_AND_ATR | Ambos conjuntos, período ATR | Ninguno de esos filtros |
| DISABLED | Ningún umbral de rango | Mínimos y máximos pips/ATR |

Máximo cero desactiva el límite en el código, pero **no se sabe si los máximos eran cero en estas corridas**. Spread máximo es irrelevante si su filtro está apagado; los inputs Research son ajenos a la selección comercial en MODE_TRADING. El período ATR también puede afectar disponibilidad de datos aunque no se aplique el umbral ATR. El inventario completo de los 26 inputs, con defaults etiquetados como referencia y nunca como ajustes del run, está en `Resumen_Parametros.csv`.

**Inferencia sustentada:** el comportamiento es MODE_TRADING bajo el código disponible: hay operaciones y el score no es el sentinel Research de −1.000.000.000. Además, al variar únicamente ATR en el espacio exportado cambian resultados, por lo que el filtro ATR parece activo: ATR o PIPS_AND_ATR. No puede distinguirse cuál. Esto presupone que el binario ejecutado corresponde al fuente local y que los ajustes no exportados se mantuvieron fijos dentro de cada optimización. No hay hash del binario ni metadatos de ejecución que cierren esa comprobación.

### Result y Custom

**Comprobado en los datos:** `Result=round(Custom,2)` en los 12.960 pases. Result no es Profit. El código de `OnTester()` usa n=STAT_TRADES, P=STAT_PROFIT, D=STAT_EQUITY_DD monetario y N=InpMinTradesForScore:

```text
Si MODE_RESEARCH: −1.000.000.000
Si n < N: −1.000.000 + n/N
En otro caso: clip[P/max(1,D) × min(1,n/(2N)), −999.999, 999.999]
Si resultado no finito: −1.000.000.000
```

**Validación derivada:** N=50 reproduce exactamente la rama de penalización; en los demás casos `Recovery Factor × min(1,n/100)` coincide con Custom con error máximo inferior a 5·10⁻⁷, consistente con el redondeo exportado de Recovery Factor. El DD monetario no está exportado, por lo que no se puede recomputar D independientemente a partir del DD porcentual. No se confunden ambos.

La evidencia identifica Result como la salida Custom del EA, consistente con “Custom max”. No certifica el selector original del tester. El score favorece retorno frente a DD y reduce peso entre 50 y 99 trades; no evalúa estabilidad de vecinos ni persistencia anual. Para N<50, los valores cercanos a −1.000.000 son penalizaciones, no pérdidas monetarias. La mediana global del score y su media mezclan ramas distintas, por lo que no se interpretan como retorno.

Referencia técnica: [MT5 — tipos y criterios de optimización](https://www.metatrader5.com/en/terminal/help/algotrading/optimization_types). La fórmula concreta procede del fuente local `OnTester()`, no de una fórmula universal de MT5.''')

add('## 4. Estadísticas globales')
add(short(A,['Year','Pases','Positivos','Negativos','Sin_trades','Rentables_pct','Profit_mediana','PF_mediana','DD_mediana','Trades_mediana'],{'Year':'Período','Rentables_pct':'% positivos','Profit_mediana':'Profit med. USD','PF_mediana':'PF med.','DD_mediana':'DD med. %','Trades_mediana':'Trades med.'}))
add(f'''Globalmente hay {D.Trades.lt(50).sum():,} pases con menos de 50 trades (incluidos 72 sin trades), {D.Trades.lt(100).sum():,} con menos de 100 y {D.Trades.lt(200).sum():,} con menos de 200. Son {D['Equity DD %'].gt(20).sum():,} con DD>20% y {D['Equity DD %'].gt(50).sum():,} con DD>50%. El umbral 20% es una convención exploratoria explícita, no un límite de riesgo aprobado por el usuario. Los conteos pueden superponerse.

Hay 72 pases con alguna métrica ausente, cero valores no finitos adicionales y 46 incidencias aritméticas de Expected Payoff separadas de esos faltantes. PF no interpretable por ausencia/sin operaciones: 72. Los PF finitos extremos no se anulan por ser altos, pero se separan por muestra: el máximo observado, 340,414062, procede de un único trade. Con ≥50 trades, el PF máximo es {D.loc[D.Trades.ge(50),'Profit Factor'].max():.6f}. No hay conteos de ganadoras/perdedoras para explicar esos cocientes.''')
dist=read('Distribuciones_Metricas');add(short(dist[dist.Periodo.astype(str).eq('TODOS')],['Metrica','N_validos','Min','P25','Mediana','P75','P95','Max'],{'Metrica':'Métrica','N_validos':'N numérico'}))
add('''Las medias, desvíos, percentiles 5/25/50/75/95 y extremos de cada año están en `Distribuciones_Metricas.csv`. Estas distribuciones describen la malla de configuraciones, no una distribución de retornos independientes ni de probabilidades de éxito. No se suman los beneficios de estrategias alternativas ni se promedian PF para producir un PF de cartera. PF=0 con operaciones se conserva como resultado numéricamente posible; PF vacío queda ausente. Un Sharpe alto en pocos trades no prueba significancia ni se usa para seleccionar candidatos.''')
add(fig('01_Distribucion_Profit','Distribución de beneficio de todos los pases')+fig('02_Profit_Trades','Beneficio y número de operaciones')+fig('03_PF_Drawdown','Profit Factor y drawdown con muestra visible'))

add('''## 5. Redundancia de optimizaciones

### Definiciones y conteos

La firma usa exactamente las nueve métricas exportadas: Result, Profit, Expected Payoff, PF, Recovery Factor, Sharpe, Custom, DD% y Trades. No se redondean para fabricar equivalencias. Dos vacíos en la misma métrica se tratan como el mismo estado ausente. Se agrupa **dentro de cada año**; un mismo valor en dos años no constituye redundancia de una corrida. Las comparaciones condicionales, además, fijan todos los otros parámetros exportados.

Se obtienen **12.375 resultados numéricos distintos por año acumulados**, 585 excedentes (12.960−12.375) y 719 filas dentro de grupos de tamaño>1, organizadas en 134 grupos duplicados. `Pases_Redundantes.csv` incluye las 719 filas, su representante (menor pase del grupo), tamaño, firma y flag `RedundantExtra`; al sumar ese flag se recuperan 585. 515 excedentes tienen trades>0 y 70 proceden de cero operaciones.

Las 3.240 combinaciones de parámetros son distintas. Al comparar el **perfil completo de métricas de los cuatro períodos**, quedan **3.190 perfiles distintos**, 50 combinaciones excedentes. Ni 3.190 perfiles ni 12.375 resultados equivalen a ese número de estrategias independientes o secuencias de trades distintas.''')
add(short(T,['TF','Pases','Distintos','Redundantes','Redundancia_pct'],{'TF':'Temporalidad','Distintos':'Resultados distintos','Redundantes':'Pases redundantes','Redundancia_pct':'% redundancia'}))
add('**Conciliación de la tabla:** sus excedentes suman 584, porque conserva un representante por TF y año. El total global es 585: en 2026 un grupo sin operaciones incluye 9 pases H2 y 36 H4. Al unir ambos TF queda un solo representante, añadiendo un excedente. Por la misma razón, los resultados distintos por TF suman 12.376, frente a 12.375 al agrupar todo el año.')
add(fig('05_Redundancia_Temporalidad','Redundancia de métricas por temporalidad'))
cond=read('Redundancia_Condicional').groupby('Parametro').agg(Familias=('N','size'),Pases=('N','sum'),Exceso=('Exceso_redundante','sum')).reset_index()
pairtotal=P.groupby('Parametro').agg(Pares=('Identicos','size'),Identicos=('Identicos','sum'),Cambios_signo_pct=('Cambio_signo',lambda x:100*x.mean()),Cambio_abs_mediano=('AbsDeltaProfit','median')).reset_index();pairtotal['Identicos_pct']=pairtotal.Identicos/pairtotal.Pares*100
add('### Qué variable produce repeticiones al mantener las demás constantes\n\n'+table(cond)+'\n\n'+table(pairtotal))
add('''Los excedentes condicionales no se suman entre parámetros: una fila puede ser redundante en más de una dimensión. RR produce más pares adyacentes iguales que ATR en esta malla; eso no significa que RR sea generalmente irrelevante. No hay mínimo pips exportado, así que su redundancia no se puede medir ni contrastar con ATR.

En H4, el paso ATR 2→2,25 no cambia métricas en 66/180 pares (36,67%) y 2,25→2,5 en 52/180 (28,89%). **Ninguno de esos pares tiene ≥50 trades en ambos extremos.** En H2/H4, la escasez de operaciones explica parte de la aparente suavidad; el XML no prueba que sea toda la explicación. En M1–M30 no hay pares ATR adyacentes con todas las métricas iguales, aunque sí existen métricas individuales casi constantes.

`Intervalos_Sin_Cambio.csv` contiene cada par exacto y los parámetros que se mantuvieron fijos. `Redundancia_Condicional.csv` detecta también igualdad no adyacente dentro de la familia. La identidad se refiere a la precisión del export: dos recorridos diferentes pueden acabar con las mismas métricas. Para demostrar duplicación de operaciones hacen falta secuencias de SignalID, posición/deal, entrada/salida, volumen, precios, costos y timestamps. Una firma de selección de señales por sí sola tampoco prueba igualdad de fills.''')

add('## 6. Resultados por temporalidad')
add(short(T,['TF','Pases','Rentables_pct','Profit_mediana','PF_mediana','DD_mediana','Trades_mediana','N50_pct','Redundancia_pct'],{'Rentables_pct':'% positivos','Profit_mediana':'Profit med. USD','PF_mediana':'PF med.','DD_mediana':'DD med. %','Trades_mediana':'Trades med.','N50_pct':'% N≥50','Redundancia_pct':'% redundancia'}))
annual=TY.pivot(index='TF',columns='Year',values='Rentables_pct').reindex(TF).reset_index();add('### Porcentaje positivo por período\n\n'+table(annual))
add('''**Interpretación por TF.**

- **M1:** 0 positivos de 1.620; PF mediano 0,678 y DD mediano 76,68%. Exigir más ATR recorta pérdidas y exposición, sin convertir ninguna combinación en rentable. No merece afinar esta malla comercial con estos supuestos.
- **M3:** 18 positivos (1,11%), principalmente un fenómeno local que no justifica una conclusión general. Puede conservarse un control de falsación, no una familia prioritaria.
- **M5:** hay una región de 2026 con cuerpos 90–95%, ATR 1,5–2,5 y RR aproximadamente 3–5, pero otros años no la sostienen. Conserva más trades que las temporalidades altas; la contradicción temporal debe investigarse.
- **M15:** mejor equilibrio de frecuencia que H1/H2/H4; algunos corredores ATR 1,5–2,5 con cuerpos 75–90 y RR 3,5–5 son favorables en 2025. El pase 1043 gana en tres períodos con ≥131 trades, pero no tiene una vecindad estable en 2026.
- **M30:** mayor número de pases favorables con muestra mínima (238) y varias regiones adyacentes útiles. La zona ATR 1,75–2,25/cuerpo 75–85/RR 2–3 merece pruebas dirigidas, manteniendo visible el fracaso de 2024. Existen otras mesetas de RR bajo en 2024 y 2026 que no deben confundirse con esa zona.
- **H1:** regiones de 2023 con cuerpos 80–85, ATR 1–2,25 y RR 3–4,5, y un corredor de 2025 cuerpo 80/RR 1,5/ATR 0,5–2. La preferencia de RR cambia según año; solo 56,85% de pases alcanza N≥50.
- **H2:** predomina la muestra reducida (mediana 27 trades); cuerpos 75–85 y ATR bajos merecen controles limitados. El único pase positivo en los cuatro períodos usa cuerpo 95%, pero su baja muestra lo excluye como evidencia de robustez.
- **H4:** 33,09% positivos en la malla, pero apenas 9,32% alcanza 50 trades. Una ganancia pequeña con 1–15 trades y DD pequeño no acredita superioridad. Los pocos representantes con N≥50 usan cuerpos 75–80 y ATR bajos.

Los CSV `Resumen_Anual_Temporalidad` y `Marginal_*` detallan estas comparaciones en cada año. Las medianas combinadas dan igual peso a cada pase y a cada período, no igual peso por día. No se anualiza 2026 ni se equiparan universos de trades diferentes. Las comparaciones de TF controlan los parámetros exportados y depósito, pero no pueden certificar los ajustes fijos omitidos.''')
add(fig('04_Rentables_Temporalidad','Porcentaje de configuraciones rentables por temporalidad'))

add('''## 7. Estudio principal de RangeATR

### Efectos emparejados y relaciones con las métricas

Para cada año, TF, cuerpo y RR se ordenan los nueve valores ATR. Cada diferencia compara únicamente umbrales consecutivos (paso 0,25): **1.440 pares por TF**. Las medianas siguientes son de diferencias emparejadas, no diferencias entre dos mejores pases. DD está en puntos porcentuales; Profit y Expected Payoff, en USD y USD/trade.''')
at=PS[PS.Parametro.eq('InpMinRangeATR')].set_index('TF').reindex(TF).reset_index()
add(short(at,['TF','DeltaProfit_mediana','DeltaPF_mediana','DeltaDD_mediana','DeltaTrades_mediana','DeltaEP_mediana','Cambio_signo_pct','Identicos_pct'],{'DeltaProfit_mediana':'ΔProfit med.','DeltaPF_mediana':'ΔPF med.','DeltaDD_mediana':'ΔDD pp med.','DeltaTrades_mediana':'ΔTrades med.','DeltaEP_mediana':'ΔPayoff med.','Cambio_signo_pct':'% cambio signo','Identicos_pct':'% idénticos'}))
add('''**Interpretación.** Al elevar el umbral suele subir el Profit y bajar el DD, pero también se reducen operaciones. En M1, +0,25 ATR mejora el beneficio mediano del par en 7.811,62 USD mientras PF apenas cambia y Expected Payoff empeora: fundamentalmente se deja de ejecutar parte de una actividad perdedora. M15/M30 muestran mejoras medianas simultáneas de PF y Payoff, aunque pequeñas e inestables entre años. En H4 el cambio mediano de Profit y PF es cero; eso no significa que todos los pares sean iguales: solo 18,33% tiene todas las métricas idénticas.

`Correlaciones_Condicionales.csv` contiene medianas de Spearman calculadas dentro de cada familia fija (año, TF, cuerpo, RR). Se omiten familias constantes de la correlación y se cuenta cuántas contribuyen. No se calculan p-values, porque las familias y los pases no constituyen muestras independientes. Las cinco figuras siguientes separan los períodos y conservan el conteo de trades en una figura propia.''')
for s,desc in [('Profit','Beneficio frente al mínimo ATR'),('PF','Profit Factor frente al mínimo ATR'),('DD','Drawdown frente al mínimo ATR'),('Trades','Operaciones frente al mínimo ATR'),('Payoff','Expected Payoff frente al mínimo ATR')]:add(fig('06_ATR_'+s,desc))
add('''### Sensibilidad y cambios importantes

Se llama “similar” a un par con |ΔProfit|≤500 USD (0,5% del depósito), |ΔPF|≤0,10 y |ΔDD|≤1 punto porcentual. “Cambio importante” usa |ΔProfit|≥1.000 USD (1% del depósito). Son umbrales de diagnóstico, no intervalos de confianza. Se informa también cambio de signo sin depender del tamaño monetario. Un par similar puede estar compuesto por dos pérdidas o por muestras mínimas.''')
add(short(at,['TF','AbsDeltaProfit_mediana','AbsDeltaProfit_P90','Drastico_pct','Similares_pct','Ambos_favorables50_pct','N50_ambos'],{'AbsDeltaProfit_mediana':'Mediana |ΔProfit|','AbsDeltaProfit_P90':'P90 |ΔProfit|','Drastico_pct':'% cambio ≥1.000','Similares_pct':'% similares','Ambos_favorables50_pct':'% ambos favorables','N50_ambos':'Pares ambos N≥50'}))
add('''En M30 cambia el signo del beneficio en 16,53% de los pasos ATR; en H4, 14,44%. Una meseta monetaria de pocos trades puede parecer más estable que una configuración con cientos de operaciones. Por eso la similitud no sustituye el filtro de muestra. Los detalles por intervalo, año, cuerpo, RR y pases están en `Sensibilidad_Intervalos.csv`, `Comparaciones_Vecinos.csv` y `Cambios_Importantes.csv`.

### Regiones favorables frente a mesetas similares

Se detectaron **116 tramos máximos de al menos tres valores ATR consecutivos favorables**, manteniendo año, TF, cuerpo y RR. Solo **9** cumplen además similitud sobre la extensión completa del tramo (amplitud Profit≤500, PF≤0,10, DD≤1pp). Estos tramos no son observaciones independientes. La tabla presenta todas las nueve mesetas; no se interpola entre puntos ni fuera de sus límites.''')
add(short(R[R.Similar_toda_region],['Year','TF','Body','RR','ATR_desde','ATR_hasta','Trades_min','PF_min','Profit_min','Profit_max','DD_max','Passes'],{'Year':'Año','Body':'Cuerpo','ATR_desde':'ATR desde','ATR_hasta':'ATR hasta','Trades_min':'N mín.','Profit_min':'Profit mín.','Profit_max':'Profit máx.'}))
add('''Ejemplos de corredores positivos más amplios, aunque no planos: H1/2025/cuerpo80/RR1,5 mantiene ganancias de ATR0,5 a2 con mínimo66 trades; M30/2025/cuerpo75/RR2 de ATR1 a2,25 con mínimo107; M5/2026/cuerpo90/RR3 de ATR1,5 a2,5 con mínimo109. El CSV `Regiones_ATR_Favorables` contiene los 116 tramos, incluidos sus pases, rangos de PF/Profit y DD.

**No hay evidencia de una región ATR uniformemente favorable a través de los cuatro períodos con N≥50.** La lectura útil es identificar mecanismos y contradicciones concretas, no declarar un umbral universal.''')

add('''## 8. Comparación ATR vs PIPS

**Hecho:** no se exportaron `InpRangeFilter`, `InpMinRangePips` ni `InpMaxRangePips`; no hay corridas PIPS vinculadas con un manifiesto comparable. Los presets prueban que el EA admite filtros distintos, no que esas corridas se hayan realizado. El mínimo ATR observado afecta resultados, compatible con ATR o PIPS_AND_ATR bajo el fuente local.

**Cálculo posible:** medir cuánto cambia la salida al variar ATR manteniendo año y los otros tres parámetros exportados. Resultado: 97,20% de pares adyacentes cambia alguna métrica; en M1–M30 cambia el 100%, en H1 el 99,72%, H2 el 96,25% y H4 el 81,67%.

**Conclusión no identificable:** no se pueden estimar diferencias controladas ATR−PIPS en trades, Profit, PF, DD, Expected Payoff o redundancia. Tampoco puede atribuirse una reducción respecto a V1.1, cuyos datos disponibles pertenecen a otra estrategia/validación. El ATR tiene capacidad discriminante dentro de esta malla, pero **su superioridad frente a pips permanece sin demostrar**.

**Recomendación:** contrastar PIPS, ATR, PIPS_AND_ATR y DISABLED en familias apareadas con TF/cuerpo/RR/riesgo/spread idénticos. Elegir los umbrales de cada filtro mediante cuantiles de rango de un período de desarrollo o igualando aproximadamente número de señales, nunca optimizándolos sobre el futuro conjunto reservado. Reportar tanto volumen de señales como resultados comerciales: menos trades y menor DD no son por sí solos una ventaja.''')
add(fig('09_ATR_vs_PIPS_Limitacion','Limitación de la comparación ATR frente a pips'))

add('''## 9. Porcentaje de cuerpo

Cada comparación sube 5 puntos porcentuales manteniendo año, TF, ATR y RR. Hay 1.296 pares por TF. Todos los niveles de cuerpo están presentes, pero un cuerpo de 95% puede dejar muy pocas observaciones en TF altos.''')
body=PS[PS.Parametro.eq('InpMinBodyPercent')].set_index('TF').reindex(TF).reset_index()
add(short(body,['TF','DeltaProfit_mediana','DeltaPF_mediana','DeltaTrades_mediana','DeltaEP_mediana','Cambio_signo_pct'],{'DeltaProfit_mediana':'ΔProfit med.','DeltaPF_mediana':'ΔPF med.','DeltaTrades_mediana':'ΔTrades med.','DeltaEP_mediana':'ΔPayoff med.','Cambio_signo_pct':'% cambio signo'}))
add('''Subir el cuerpo eleva la mediana del Profit emparejado en todos los TF, pero **no mejora sistemáticamente la calidad por trade**. PF mediano del cambio baja en M1, M3, M30, H2 y H4; en H2/H4 el Payoff mediano también cae. En H1 se observa una mejora mediana pequeña de PF y Payoff, con 28,01% de cambios de signo entre cuerpos vecinos. El recorte reduce operaciones, con efectos especialmente fuertes en TF pequeños.

La interacción importa: M5/2026 favorece algunas combinaciones de cuerpo90–95 y ATR altos; M30/2023/2025 favorece cuerpos75–85 alrededor de ATR1,75–2; H4/cuerpo95 genera escasez extrema. No se recomienda reemplazar 80 por 90 o95 de forma universal. Los mapas muestran medianas y trades por celda; las tablas marginales contienen N≥50 por año y nivel.''')
add(fig('07_ATR_Cuerpo','Interacción ATR por cuerpo con operaciones visibles')+fig('07b_M30_Cuerpo_Por_Periodo','M30 ATR por cuerpo separado por período')+fig('14_Cuerpo_Profit','Efectos del cuerpo por temporalidad y período'))

add('''## 10. Ratio riesgo/beneficio (RR)

Cada par cambia RR en +0,5 con año, TF, cuerpo y ATR constantes. **El número de operaciones puede cambiar al modificar RR**: el código bloquea ciertas entradas mientras hay posiciones abiertas y el TP modifica su duración. Los efectos no representan simplemente recalcular una lista fija de trades con otro TP.''')
rr=PS[PS.Parametro.eq('InpRR')].set_index('TF').reindex(TF).reset_index()
add(short(rr,['TF','DeltaProfit_mediana','DeltaPF_mediana','DeltaDD_mediana','DeltaTrades_mediana','DeltaEP_mediana','Identicos_pct'],{'DeltaProfit_mediana':'ΔProfit med.','DeltaPF_mediana':'ΔPF med.','DeltaDD_mediana':'ΔDD pp med.','DeltaTrades_mediana':'ΔTrades med.','DeltaEP_mediana':'ΔPayoff med.','Identicos_pct':'% idénticos'}))
add('''Dentro de los resultados observados, M30 tiene representantes de RR2–3 en tres períodos, pero también una meseta de RR1 en 2024. H1 exhibe RR3–4,5 favorables en 2023 y RR1,5 en 2025. M5/2026 tiene corredores RR3–5, cuya persistencia falla en años anteriores. No hay RR ganador universal.

El CSV de cruces y las diferencias emparejadas contienen todas las métricas solicitadas. Expected Payoff positivo describe la esperanza **muestral exportada**, con la salvedad contable de 46 casos. No estima por sí solo la esperanza poblacional. Los candidatos N≥50 tienen también Profit/Trades positivo.

El XML **no permite distinguir cuántas ganancias financian cada resultado** ni si RR alto depende de una sola ganadora. No se calculan win rates a partir de RR/PF/Trades. El umbral teórico de acierto 1/(1+RR) tampoco reemplaza el win rate real, porque pérdidas/ganancias efectivas, costos, redondeos y ejecución varían.''')
add(fig('08_ATR_RR','Interacción ATR por RR')+fig('08b_M30_RR_Por_Periodo','M30 ATR por RR separado por año')+fig('15_RR_Profit','RR por temporalidad y año'))

add('''## 11. Interacciones entre parámetros

Los seis cruces solicitados con variables disponibles están documentados en `Cruce_*`: TF×ATR, TF×RR, TF×cuerpo, cuerpo×ATR, ATR×RR y, adicionalmente, cuerpo×RR. **Pips×TF no es observable**. Las seis tablas existentes cubren todos sus cruces sin imputación, con N, medianas de Profit/PF/DD/Trades y conteo favorable.

Para cuantificar influencia aparente se descompuso la variación de Profit en la malla balanceada mediante medias de factores y de interacciones de segundo orden. Se incluye año como factor. Es una descomposición descriptiva exacta del espacio observado; no una ANOVA inferencial ni una medición causal.''')
add(short(E[E.Ambito.eq('Global')].sort_values('Varianza_pct',ascending=False).head(12),['Termino','Orden','Varianza_pct'],{'Termino':'Factor/interacción','Orden':'Orden','Varianza_pct':'% variación Profit'}))
add('''TF domina la variación monetaria global (74,93%); TF×ATR explica 10,54%, el efecto principal ATR 7,44% y cuerpo 1,32%. RR como efecto principal explica solo 0,33%, pero no es irrelevante: las medias globales ocultan efectos dependientes de TF y año. La gran pérdida de M1 domina esta escala. El archivo `Descomposicion_Varianza_Profit` también descompone por año×TF, donde esa dominancia desaparece. No se comparan tamaños de efecto causal entre un paso ATR0,25, cuerpo5 y RR0,5 como si fueran unidades equivalentes.

La interacción temporal es sustantiva aunque el efecto principal global de año sea pequeño: un promedio dominado por pérdidas estructurales de M1 puede ocultar que las pocas zonas rentables cambian radicalmente entre años. En M30, elevar ATR tiende a mejorar Profit/PF hasta zonas intermedias; aumentarlo más puede vaciar la muestra y destruir una ganancia. Cuerpos mayores y ATR mayores restringen conjuntamente señales, con especial pérdida de soporte en H2/H4.''')

add('''## 12. Robustez y sobreajuste

### Sensibilidad al mínimo de operaciones

“Favorable” exige Profit>0, PF>1 interpretable, Expected Payoff>0, DD≤20%, métricas finitas y trades≥N. La última columna exige además que al menos dos tercios de los vecinos axiales cumplan **el mismo N**; se evalúan cuerpo, ATR y RR, sin trasladarse a otra temporalidad.''')
add(table(V.rename(columns={'Periodo':'Período','MinTrades':'N mínimo','ConMuestra':'Pases N suficiente','Rentables_pct_condicional':'% positivos con N','Favorables_vecinos_mismo_N_ge_dos_tercios':'Favorables con ≥2/3 vecinos favorables'})))
add('''50, 100 y 200 son referencias de tamaño, no garantías de significancia. Tampoco 200 trades son 200 observaciones independientes si hay señales superpuestas, posiciones simultáneas o concentración por sesión. `Trades` es el conteo agregado de MT5, utilizado como proxy de operaciones completas; el XML no permite auditar aperturas/cierres parciales ni el cierre de todas las posiciones al límite temporal.

### Vecindad y persistencia

Se usa vecindad axial de un paso de malla: mismo año/TF, cambia solo cuerpo ±5, ATR ±0,25 o RR ±0,5. Cada pase tiene de tres a seis vecinos observados. Los extremos tienen menor cobertura y se advierten como bordes; no se crean vecinos fuera de la malla. Se reporta proporción favorable, mediana y mínimo de beneficio vecino, diferencia absoluta y lista de IDs. Un 100% con tres vecinos de borde ofrece menos cobertura que seis vecinos interiores.

De 3.240 configuraciones, **1.829 no ganan en ningún período**, 905 ganan en uno, 422 en dos, 83 en tres y una en cuatro. Solo **21** ganan en tres períodos y tienen al menos 50 trades en cada uno de los cuatro. La única con cuatro ganancias es H2/cuerpo95/ATR0,5/RR3,5 (pase1838), con 21,20,13 y16 trades. No cumple ni el umbral inicial y se excluye de candidatos.

Se examinaron también 2.304 rectángulos mínimos de 2 cuerpos vecinos ×2 umbrales ATR vecinos con TF y RR fijos, seguidos en los cuatro períodos. **Ningún rectángulo tiene sus cuatro esquinas favorables en tres o cuatro períodos**. Solo seis lo consiguen en dos períodos; 81 en uno y2.217 en ninguno. Son regiones superpuestas, no experimentos independientes.''')
add(short(B.sort_values(['Periodos4de4Favorables','Favorables_de16'],ascending=False).head(6),['TF','RR','Body_desde','Body_hasta','ATR_desde','ATR_hasta','2023_Favorables_de4','2024_Favorables_de4','2025_Favorables_de4','2026_Favorables_de4'],{'Body_desde':'Cuerpo desde','Body_hasta':'Cuerpo hasta'}))
add('''**Interpretación:** hay estabilidad local útil para diseñar pruebas, pero no una región robusta demostrada temporalmente. Ejemplo M30/cuerpo75–80/ATR1,75–2/RR2,5: 4/4 esquinas favorables en2023 y2025, 0/4 en2024 y2/4 en2026. Seleccionar solo2023/2025 exageraría la consistencia.

**Sobreajuste:** se examinaron miles de configuraciones correlacionadas. No hay corrección de selección que convierta estos datos en una prueba independiente. No se producen p-values por tratar pases como réplicas; no se calculan Deflated Sharpe, PBO, bootstrap de retornos, intervalos de confianza de win rate ni probabilidades de ruina con agregados insuficientes. Las cuatro ventanas ya se usaron en esta selección, por lo que **ninguna queda fuera de muestra**. La coincidencia entre años es evidencia descriptiva adicional, condicionada a confirmar ajustes fijos iguales.

**Riesgo agregado:** DD por pase no revela concentración de riesgo, simultaneidad ni distribución de pérdidas. El fuente permite restricciones de exposición configurables, pero sus valores no aparecen. No se reconstruye una cartera sumando ganancias anuales reiniciadas con100.000 USD ni combinando candidatos.''')
add(fig('10_Diferencias_Vecinos','Distribución de diferencias entre vecinos')+fig('12_Muestra_Estabilidad','Operaciones y estabilidad aparente'))

add('''## 13. Configuraciones candidatas

Se seleccionan **15 representantes de hipótesis**, no veinte por completar una cuota. C01–C05 tienen tres períodos positivos y mínimo50 en cada período; C06–C15 son controles de regiones locales, y pueden resultar descartados tras las siguientes pruebas. Se incluye deliberadamente RR bajo en2024 y cuerpos altos en2026 para contrastar mecanismos diferentes. Ningún candidato satisface persistencia favorable en cuatro períodos. Todos tienen perfiles de métricas de cuatro períodos distintos.

La tabla muestra un **período de referencia favorable**, elegido por proporción de vecinos favorables, luego mayor muestra y luego PF. Esto facilita localizar el pase, pero no reemplaza la evidencia de los otros años, presentada inmediatamente después. La clase de filtro es **ATR activo inferido; ATR frente a PIPS_AND_ATR no verificado** para todos. Pips mínimo/máximo, ATR máximo, período ATR, riesgo y spread quedan **no documentados**. No se generan `.set` rellenando esos faltantes con defaults.''')
add(short(S.assign(Filtro='ATR/AND*'),['Candidato','Pase','Periodo_referencia','TF','Cuerpo','Filtro','ATR_min','RR','Trades','Profit','PF','DD_pct'],{'Periodo_referencia':'Año ref.','ATR_min':'Rango mín. ATR','DD_pct':'DD %'}))
add('### Los mismos candidatos en todos los períodos\n\n'+short(S,['Candidato','2023_Profit','2024_Profit','2025_Profit','2026_Profit','Periodos_positivos','Trades_min_4periodos','PF_min_4periodos','DD_max_4periodos'],{'2023_Profit':'Profit2023','2024_Profit':'Profit2024','2025_Profit':'Profit2025','2026_Profit':'Profit2026 parcial','Periodos_positivos':'Períodos +','Trades_min_4periodos':'N mín.','PF_min_4periodos':'PF mín.','DD_max_4periodos':'DD máx. %'}))
add(fig('13_Candidatos_Periodos','Ganancias y pérdidas de los candidatos en cada período')+fig('11_Mapa_Candidatos','Mapa de candidatos con peor período visible'))
for _,r in S.iterrows():
    add(f'''### {r.Candidato} — pase {r.Pase}, {r.TF}, cuerpo {r.Cuerpo:g}%, ATR {r.ATR_min:g}, RR {r.RR:g}

**Motivo/fortaleza:** {r.Justificacion} Clase: {r.Clase}. En la referencia {r.ID_referencia}, {r.Trades:.0f} trades y {r.Vecinos_favorables_pct:.1f}% de vecinos favorables.

**Riesgo estadístico:** {r.Riesgo} Peor Profit entre períodos: {r.Profit_min_4periodos:,.2f} USD; muestra mínima: {r.Trades_min_4periodos:.0f}. Su inclusión no supera este contraejemplo.

**Vecino para contrastar estabilidad:** {r.Vecino_ID}, ATR {r.Vecino_ATR:g}, con el resto de parámetros exportados idénticos. Profit {r.Vecino_Profit:,.2f}, PF {r.Vecino_PF:.3f}, {r.Vecino_Trades:.0f} trades. Se muestra el vecino ATR de menor beneficio disponible junto a la referencia, para no ocultar fragilidad; los demás están en `Estabilidad_Vecindad.csv`.''')
add('''`Top_20_Candidatos.csv` conserva estos 15 registros, todos los parámetros activos conocidos, faltantes explícitos, métricas anuales, justificación, riesgo y vecino. `Candidatos_Todos_Periodos.csv` contiene sus60 filas originales con las métricas completas. El pase por sí solo es único dentro de su archivo; conservar siempre año/archivo y valores, incluso cuando aquí la numeración coincide entre años.''')

add('''## 14. Conclusiones y límites de la evidencia

**Hechos comprobados:** malla completa, métricas mayoritariamente negativas, incidencias de calidad acotadas y ausencia de parámetros fijos. El código disponible describe un EA de continuación con SL en extremo, sin EMA ni trailing, pero no certifica el binario de cada optimización.

**Cálculos derivados:** el ATR distingue resultados en la mayor parte de la malla; hay redundancia concentrada en TF altos; existen mesetas locales, pero no persistencia de cuatro períodos con muestra mínima. Los mayores PF provienen de muestras minúsculas, con algunas discrepancias contables.

**Interpretación:** el resultado no demuestra una ventaja general de continuación después de una vela impulsiva. La reducción de pérdidas al exigir velas más grandes puede deberse a operar menos una señal con esperanza negativa. M30 ofrece hipótesis mejor apoyadas que elegir un pico de beneficio; 2024 sigue siendo una objeción fuerte.

**Hipótesis no demostradas:** el efecto podría depender del régimen de volatilidad, costos relativos al SL, selección por spread, horario, duración y competencia entre posiciones. El XML no separa esos mecanismos. Una continuación virtual favorable no implicaría necesariamente una cartera ejecutable favorable.

### Información que no puede reconstruirse

No hay operaciones individuales, win rate, conteos de ganadoras/perdedoras, comisiones desglosadas, spread por entrada, MFE/MAE, duración, secuencia de ganancias/pérdidas, OHLC de cada gatillo, distribución observada de RangeATR, primera llegada a R, resultados por día/mes, estabilidad dentro de cada año, posiciones simultáneas exactas ni riesgo monetario agregado. No se inventó ninguna de estas estadísticas. El conteo agregado de trades no informa dependencia o exposición.

`ResearchSignals.csv` y `ResearchLevels.csv` disponibles en `examples/SYNTHETIC_RESEARCH` son ejemplos explícitamente sintéticos. No se mezclaron con los resultados EURUSD. Los CSV EMA200 del proyecto pertenecen a otra estrategia. No hay datos de MODE_RESEARCH reales vinculados a los cuatro XML que puedan complementar este estudio.''')

add('''## 15. Próximos experimentos

### A. Mejorar el diseño de la próxima optimización

1. **Recuperar la corrida exacta:** `.set` usado, configuración INI del tester, hash del EX5 y fuente, modelo de ticks, broker/contrato, divisa, spread/costos, ejecución, fechas efectivas y tipo de cuenta. Conservar los límites de exposición. Confirmar ATR vs PIPS_AND_ATR antes de interpretar cualquier diferencia como “ATR puro”.
2. **Mantener hipótesis acotadas:** priorizar M30 y contrastes M15/H1; dejar M3/M5 como controles para determinar si2026 fue excepcional. No afinar M1 sobre esta evidencia comercial. En H2/H4 exigir un horizonte con muestra suficiente y no compensar escasez aumentando combinaciones.
3. **Malla inicial informativa:** mantener pasoATR0,25 donde hubo cambios; no refinar universalmente. En M30 investigar por separado cuerpo75–85/ATR1,5–2,25/RR2–3 y las mesetas RR1 de2024 o cuerpo90–95/ATRbajo de2026. La separación de hipótesis impide describir una caja grande como si todos sus puntos fueran favorables.
4. **Refinamiento condicionado:** considerar ATR0,125 y cuerpo2,5 puntos únicamente en desarrollo y donde haya suficientes señales y contraste vecinal. No ejecutar estos refinamientos sobre el futuro holdout. Antes, usar cuantiles reales de RangeATR para comprobar que esos pasos separan señales. Evitar afinar H4 en ATR2–2,5: hay repetición elevada y ningún par con50 trades en ambos extremos.
5. **No optimizar dimensiones inactivas:** pips bajo ATR puro, ATR bajo PIPS puro, máximos desactivados, spread máximo si su filtro está apagado. Mantener riesgo y restricciones de exposición fijos y documentados para las comparaciones. No asumir que el default es ese valor fijo.
6. **Comparación factorial pequeña ATR/PIPS:** mismo TF, cuerpo, RR, período, datos y costos, incluyendo DISABLED como referencia. Informar cambios en selección, ejecución y resultados por separado. No inferir la contribución de filtros a partir de conjuntos con cuerpos/RR distintos.

### B. Validación de candidatos

Prioridad de investigación: C01/C02 (familias M30 con tres períodos positivos), C03 (M15 como contraste), y C13/C14/C15 como controles de mesetas realmente similares. C04/C05 exploran TF altos con muestras más débiles. Los demás controles locales sirven para intentar refutar explicaciones basadas solo en2026 o2025. “Prioridad” no significa autorización operativa; puede concluirse que ninguno merece una fase adicional tras auditar los costos.

### C. Fuera de muestra sin reoptimizar el conjunto reservado

1. Considerar **2023–17/10/2026 como datos de desarrollo ya inspeccionados**. No relabelar2026 ni2024 como validación independiente después de verlos. Una reconstrucción walk-forward histórica sería un diagnóstico retrospectivo, no un holdout nuevo.
2. Congelar por escrito una lista pequeña de candidatos/controles, parámetros completos, criterios de rechazo y protocolo de costos antes de mirar los resultados reservados. Guardar el manifiesto, hash de binario y nombres de pases; sin los inputs fijos faltantes, la reproducción exacta está pendiente.
3. Elegir un tramo histórico realmente no consultado (por ejemplo anterior a2023 **solo si se confirma que nunca se usó**) o un período prospectivo a partir de la primera sesión negociable posterior al17/10/2026. Fijar de antemano su fecha final o regla de duración; no detenerlo al alcanzar una ganancia. Para TF altos puede requerirse un horizonte largo. Si no se logran suficientes trades, el resultado es inconcluso, no aprobado.
4. Ejecutar **backtests individuales**, no optimización, con las configuraciones congeladas y el mismo depósito/contrato/riesgo/spread/ejecución. Separar pruebas de reproducción histórica de verdadera validación. No mezclar datos externos con distintos costos sin documentarlos.
5. Evaluar neto de todos los costos y deslizamiento; reportar Profit/Trades reconciliado, PF, DD, distribución mensual, pérdida máxima, dependencia de mayores ganadoras, duración, exposición y concentración temporal. Realizar un escenario de costos adverso previamente fijado, sin elegir después el favorable. Evaluar candidatos y controles juntos para no ocultar múltiples intentos.
6. Con trades y series temporales, estimar incertidumbre con bloques temporales que preserven dependencia; justificar longitud de bloque a partir de duración/superposición. No bootstrap de pases como si fueran independientes. No combinar candidatos sin estudiar coincidencia y riesgo agregado.
7. Tras un fracaso no modificar parámetros sobre el mismo holdout y llamarlo validación. Ese tramo pasaría a desarrollo; una nueva hipótesis requiere nueva evidencia reservada. Una validación favorable tampoco permite omitir riesgo de ejecución y exposición.

### D. Telemetría adicional

Solicitar/capturar en futuras ejecuciones autorizadas `RunMetadata.csv`, `Signals.csv`, `Trades.csv` y eventos de ejecución para corridas comerciales. Para investigación de precio, usar `ResearchSignals.csv` y `ResearchLevels.csv` reales, unidos por RunID+SignalID, con censura, primera llegada a cada nivelR, spread y ATR anterior. Agregar hashes de ticks y reglas de identificación estable. Mantener las métricas Research separadas: recorridos virtuales independientes no son beneficios de una cartera operativa.

El próximo experimento debe separar **selección de vela** de **ejecución/cartera**: para una pequeña lista congelada de familias M30 y contrastes M15/H1, comparar ATR/PIPS/DISABLED en desarrollo y después validar las hipótesis elegidas en datos reservados. Con la telemetría podrá investigarse si ATR mejora la continuación neta por operación o simplemente evita trades perdedores.

### Entregables y reproducibilidad

- `Informe_CandleMomentum_V1.2.md`: informe principal.
- `Optimizacion_Procesada.csv`:12.960 filas,14 columnas fuente exactas más trazabilidad y derivados.
- `Pases_Redundantes.csv`:719 miembros de grupos,585 marcados como excedentes.
- `Top_20_Candidatos.csv`:15 representantes con motivos, riesgos, vecinos y resultados de los cuatro períodos.
- `Resumen_Parametros.csv`:26 inputs del fuente con valores exportados o ausencia documentada.
- `Metodologia_Analisis.md`:fórmulas, reglas, limitaciones y secuencia reproducible.
- `Graficos/`:21PNG, incluyendo cinco vistas del efecto ATR y dos cruces anuales M30. El gráfico09 documenta falta de comparación PIPS; no inventa una serie inexistente.
- CSV complementarios de calidad, distribuciones, sensibilidad, cruces, regiones y candidatos; JSON de auditoría y verificación.

Los scripts son únicamente analíticos. No se modificó el EA, sus presets ni los XML, no se cambiaron parámetros del tester y no se ejecutó ninguna optimización o backtest.

### Fuentes

Fuentes primarias: los cuatro XML en `Backtest`; código local `CandleMomentum_Research_v1_2.mq5` (inputs, filtros, referenciaATR y OnTester), `INPUTS.md`, `README.md`, presets y `validation/trading.ini` usados solo para contrastar su procedencia. Los hashes completos están en `Auditoria_XML.json`.

Documentación externa consultada para interpretar MT5: [estadísticas del tester](https://www.mql5.com/en/docs/constants/environment_state/statistics), [reporte de prueba](https://www.metatrader5.com/en/terminal/help/algotrading/testing_report), [optimización y exportación](https://www.metatrader5.com/en/terminal/help/algotrading/strategy_optimization). Las definiciones generales no sustituyen las incidencias observadas de estos archivos.

## Conclusión final: respuestas concretas

1. **¿Qué aprendimos sobre la continuación de velas impulsivas?** **Hecho/cálculo:** predominan las pérdidas y ninguna configuración con50 trades por período gana en los cuatro. **Interpretación:** no hay evidencia de una ventaja general; algunos recortes muestran hipótesis locales, con fuerte dependencia del período.
2. **¿Qué temporalidades presentan regiones más favorables?** **Cálculo:** M30 reúne238 pases favorables N≥50 y varias regiones contiguas; M15 aporta212 y H1,132. **Interpretación:** M30 merece la mayor atención exploratoria, seguido de M15/H1. H4 no es superior por tener más pases positivos sin controlar muestra.
3. **¿RangeATR aporta más información que pips?** **Hecho:** cambia métricas en97,20% de paresATR vecinos controlados. **Límite:** no hay comparación PIPS identificable, así que no puede afirmarse “más que pips”. La superioridad es una **hipótesis** pendiente.
4. **¿Cuántos pases fueron redundantes?** **Cálculo:**585 excedentes (4,51%) dentro de año;719 filas integran134 grupos repetidos. Quedan12.375 resultados distintos por período acumulados y3.190 perfiles distintos de cuatro períodos. No equivalen a operaciones idénticas demostradas.
5. **¿Qué parámetros influyen más aparentemente?** **Cálculo:** en la variación monetaria global dominan TF (74,93%), TF×ATR (10,54%) y ATR (7,44%). **Interpretación:** se explica en gran medida por frecuencia y enormes pérdidas deM1; no es un ranking causal de calidad de señal. Cuerpo yRR importan de manera condicionada.
6. **¿Qué combinaciones muestran mayor estabilidad vecinal?** **Cálculo:** nueve mesetasATR similares, entre ellas M30/2024/cuerpo75/RR1/ATR1,75–2,25 y H1/2023/cuerpo85/RR4,5/ATR1–1,5. La región M30/cuerpo75–80/ATR1,75–2/RR2,5 es favorable en2023/2025 y falla en2024. **Límite:** ninguna estabilidad de cuatro períodos está demostrada conN≥50.
7. **¿Qué conviene descartar?** **Recomendación:** M1 en esta malla, selección automática por PF extremo, pases sin operaciones o con muestras mínimas, refinamiento H4 deATR alto con baja discriminación, y cualquier pico aislado presentado como robusto. El pase1838 positivo en cuatro períodos no supera la muestra mínima. Los casos locales deM3/M5 solo se conservan como controles de falsación.
8. **¿Cuáles merecen validación fuera de muestra?** **Recomendación:** priorizar familias representadas por1324,1300 y1043, junto con controles de meseta244,2661 y116; el resto de los15 representantes permite contrastar TF, cuerpo yRR. Todos tienen contraejemplos temporales y requieren recuperar inputs fijos antes de reproducirse. Ninguno está validado para real.
9. **¿Qué falta para evaluar la ventaja estadística real?** **Hecho:** faltan ajustes completos, costes, calidad de ticks, trades y secuencia, simultaneidad y riesgo agregado; también telemetría realResearch. **Recomendación:** reconciliar46 discrepancias contables y analizar dependencia, concentración y sensibilidad a costos antes de inferir incertidumbre.
10. **¿Cuál debe ser el próximo experimento cuantitativo?** **Recomendación:** congelar pocas familias y controles, recuperar su configuración completa, comparar ATR/PIPS/DISABLED con todo lo demás fijo en desarrollo y realizar backtests individuales sobre datos nunca usados en selección, con trades/telemetría y protocolo de rechazo predefinidos. **Hipótesis a refutar:** que ATR mejora la continuación neta por operación, y no solo reduce la cantidad de operaciones de una señal perdedora.''')

(O/'Informe_CandleMomentum_V1.2.md').write_text('\n\n'.join(parts)+'\n',encoding='utf-8')

method='''# Metodología del análisis — Candle Momentum V1.2

Fecha:18/10/2026. Objetivo: describir la optimización y proponer pruebas independientes, sin modificar EA/inputs ni ejecutar MT5.

## 1. Fuentes y unidad de observación

Cuatro XML SpreadsheetML completos,3.240 filas de pases cada uno. Unidad primaria: resultado de un pase en un período. Clave:`SourceFile+Pass`; clave legible:`Year:Pass`. Misma configuración en cuatro períodos se une por los cuatro parámetros exportados, verificando que coinciden los pases.2026 termina17/10. Un pase no es una observación estadísticamente independiente.

Parser:`xml.etree.ElementTree` con namespaces; se respetan índices explícitos de filas/celdas y huecos, se auditan encabezados y longitud de fila. No se interpreta el documento como un XML arbitrario ni se toma solo su parte superior. Se conserva XML_Row. Se verifican hashes antes/después. El CSV procesado conserva como texto exacto la representación original de las14 columnas, incluso Custom y PF vacío; el cálculo usa su conversión numérica. Ausentes no se convierten a cero. Los demás CSV guardan números derivados con precisión de coma flotante.

Los cuatro niveles de TF se traducen mediante el enum del código (ocho valores0–7); no se usa M5 del título como TF del pase. Se verifica malla8×5×9×9 y las3.240 combinaciones en cada año. Cobertura exhaustiva observada no certifica el algoritmo del tester.

## 2. Métricas y unidades

| Columna | Interpretación empleada | Límite |
|---|---|---|
| Pass | Identificador original del pase | Repetido entre archivos; unir con fuente/año |
| Profit | Resultado monetario neto reportado por MT5; USD según depósito | No se certifica inclusión correcta de todos los costos sin deals |
| Expected Payoff | Métrica por trade exportada, USD/trade |46 casos no coinciden conProfit/Trades |
| NetPayoffDerived | Profit/Trades si Trades>0 | Derivado separado; vacío con0trades |
| Profit Factor | Cociente de beneficio/pérdida brutos según tester | Sin sumas brutas no se recomputa; extremos de pocas operaciones no prueban ventaja |
| Recovery Factor | Cociente de beneficio respecto al drawdown monetario usado por el tester | Coincide con la fórmulaCustom ajustada, pero DD monetario no exportado |
| Sharpe Ratio | Sharpe agregado exportado | No se reconstruyen retornos, anualización ni confianza; no se usa como significancia |
| Equity DD % | Drawdown relativo porcentual de equity exportado | No permite obtener el DD monetario usado enOnTester ni exposición simultánea |
| Trades | Número de trades exportado | Proxy de operaciones completas; no auditables cierres/partials sin historial |
| Custom | Salida deOnTester compatible con el fuente local | No expresa dólares; depende de muestra yDD |
| Result | Custom redondeado a2decimales, comprobado en todas las filas | No se interpreta como beneficio |

PF operativo interpretable para resúmenes: valor finito≥0 y<1e6 conTrades>0. El límite superior solo detectaría sentinels enormes; el máximo observado340,414 no lo alcanza.72PFvacíos se excluyen de su mediana; no se excluyen PFaltos finitos por conveniencia. ConN≥50 no quedan esos extremos. PF0 conTrades>0 se conserva. Interpretable matemáticamente no equivale a fiable estadísticamente.

Custom según código: Research→−1e9; si n<N→−1e6+n/N; si n≥N→clip[P/max(1,Dmonetario)×min(1,n/(2N)),−999999,999999]. No finito→−1e9. Se verifica N50 numéricamente. Para n≥50 se contrasta contraRecoveryFactor×min(1,n/100), con error≤5e−7 por redondeo; no se deduce Dmonetario usandoDD%.

Referencias de definición:[estadísticas MT5](https://www.mql5.com/en/docs/constants/environment_state/statistics) y [reporte MT5](https://www.metatrader5.com/en/terminal/help/algotrading/testing_report). Las divergencias del origen se documentan aunque la definición general sugiera una identidad.

## 3. Calidad y filtros

- Positivo:Profit>0; negativo:Profit<0; neutro:Profit=0. Sin operaciones:Trades=0.
- Muestra insuficiente:Trades<N, N50 inicialmente; sensibilidad100y200. No se atribuye significancia a esos mínimos.
- Métrica ausente/inválida: alguna de las nueve métricas no finita o vacía.72filas por PFausente; no hay otros NaN/inf. Se informan aparte46discrepancias aritméticas.
- Discrepancia Payoff:|ExpectedPayoff−Profit/Trades|>1e−6. Resto compatible con redondeo a6decimales.46casos con1–4trades; no se inventa su explicación.
- DD elevado:>20%; severo:>50%. Son referencias analíticas. No se convierten en límites de inversión aprobados.
- Favorable_N:Profit>0, PF>1 interpretable, ExpectedPayoff>0, DD≤20%, métricas finitas yTrades≥N. Se preservan todas las filas en el procesado; los filtros solo definen subconjuntos.

## 4. Distribuciones y comparaciones

Se calculan N, media, desviación muestral(ddof1), mínimo, cuantiles0,05/0,25/0,50/0,75/0,95 y máximo, omitiendo ausentes solo en la métrica correspondiente. Cuantiles pandas con interpolación lineal. Porcentaje positivo=100×n(Profit>0)/n(pases), salvo tablas que especifican denominadorN≥umbral.

Las agregaciones de cuatro años tienen igual número de pases/año; no ponderan días. No anualizar2026 ni sumar resultados como una cartera continua. PF/DD/Sharpe no son aditivos. No calcular win rate, riesgo de ruina, duración,MFE/MAE o resultados diarios a partir de estos agregados.

Cada comparación de un parámetro se realiza dentro de familia definida por año y todos los demás parámetros exportados. Se ordenan sus valores y emparejan consecutivos. Δm=m(valor siguiente)−m(valor previo). Pasos:cuerpo5puntos,ATR0,25,RR0,5. TF tiene ocho categorías y no representa una distancia temporal uniforme. Se conserva el resto conocido; no se puede certificar la igualdad de inputs ocultos entreaños.

Spearman:correlación de rangos con empates de rango medio dentro de cada familia. Se omiten las familias de métrica constante y se informa número de correlaciones válidas. Se resumen medianas/mín/máx; no p-values. Un cambio de Profit puede reflejar frecuencia de operaciones y no mejora de esperanza por trade.

## 5. Redundancia

Vector de identidad:[Result,Profit,ExpectedPayoff,PF,RecoveryFactor,Sharpe,Custom,EquityDD%,Trades]. Se normalizan representaciones numéricas a float64 y las ausencias al tokenMISSING; no se redondea. Se calcula SHA256 de la representación hexadecimal exacta del vector. Se comprueba el mismo conteo por eliminación directa de vectores duplicados. La comparación se limita a cada año.

Para un grupo conkfilas, excedentes=k−1. Total excedentes=N−K, conKgrupos distintos. Miembros duplicados=suma de k en gruposk>1. Resultado:585excedentes,719miembros,134grupos. Representante:menorPass. El CSV incluye todos los miembros yRedundantExtra para distinguirlos.

Redundancia porTF:n−número de firmas/año distintas dentro delTF, sin deduplicar años entre sí. Redundancia condicional:primero agrupar por año y todos los otros parámetros, luego contar vectores repetidos al variar el parámetro estudiado. Los excedentes de distintas dimensiones se solapan y no se suman. Parejas idénticas consecutivas no equivalen al conteo de redundancia no adyacente.

Perfil de cuatro períodos:concatenación ordenada por año de firmas de métricas por configuración.3190perfiles distintos entre3240configuraciones. No prueba identidad de trades ni independencia. Firmas de SignalID tampoco bastan para identidad de fills.

## 6. Sensibilidad y estabilidad

Cambio importante:|ΔProfit|≥1000USD,1% del depósito100000. Similaridad de pares:|ΔProfit|≤500USD y|ΔPF|≤0,10 y|ΔDD%|≤1pp. Cambio de signo:ProfitA×ProfitB<0; los ceros no cuentan como inversión. Se reportan conteos/pct y diferencias continuas para no depender solo de cortes arbitrarios.

Vecinos axiales:un paso± en cuerpo,ATR oRR; año/TF iguales y otras variables constantes. Solo vecinos observados,3–6porcentro. No se completan bordes. NeighborFavorable50Pct=100×vecinosFavorables50/vecinos. Se guardan IDs, mediana y mínimoProfit vecino, mínimoTrades y mediana|ΔProfit|. Evaluación adicional exige≥2/3favorables con umbral50/100/200 aplicado a centro y vecinos. `Sensibilidad_Muestra.csv` conserva la versión explícitamente referida a vecinosN50; la tabla principal usa`Sensibilidad_Muestra_Vecinos.csv` con el mismoN.

CorredoresATR:tramos máximos de≥3umbrales consecutivos todosFavorables50 manteniendo año,TF,cuerpo,RR.116tramos. Meseta similar:amplitudProfit≤500,amplitudPF≤0,10,amplitudDD≤1pp en todo el tramo;9mesetas. No se exige igualdad exacta de resultados ni se infieren valores intermedios.

Rectángulos:dos cuerpos adyacentes×dosATR adyacentes,TFyRR fijos;2304rectángulos observados en los4períodos. Un período de rectángulo favorable exige4/4esquinasFavorables50. Son solapados. Ninguno logra3o4períodos completos favorables;6logran2.

## 7. Interacciones y variación explicada

Se aprovecha el diseño factorial completo. μ=mediaProfit global; efecto principal a_i=media(Profit|factor=i)−μ. Efecto de par ab_ij=media(Profit|a=i,b=j)−media(Profit|a=i)−media(Profit|b=j)+μ. SS de cada efecto=suma sobre todas las filas del cuadrado de su valor predicho; %SS=100×SS/SST. En malla balanceada son componentes ortogonales. Residuo=SST−SSprincipales−SSpares, atribuible a interacciones de orden≥3, no “ruido independiente”. Se repite en cadaaño×TF para cuerpo/ATR/RR. Sin pruebasF ni p-values. La dominancia deM1 en dólares impide interpretar el ranking como influencia causal sobre ventaja estadística.

## 8. Selección de candidatos

Selección intencional y transparente, no un score opaco ni un ranking deProfit.15representantes revisados:5familias con3períodos positivos yN≥50 en cada uno;10controles de estabilidad/regiones locales, incluyendo3mesetas similares. Se mantiene diversidad deTF,cuerpo,ATRyRR y perfiles distintos de cuatroperíodos. No se impuso una selección por cantidad fija de ganadores. Ninguno es robusto en los4períodos; se explicitan sus fallas.

Período de referencia:entre períodosFavorables50 de la configuración, ordenar por%vecinosFavorables50 descendente, luegoTrades yPF descendentes. La referencia sirve para localizar y comparar, no para ocultar pérdidas: el CSV y el informe incluyen todos losaños. Vecino explicado:vecinoATR observado de menorProfit de ese período, manteniendo restoidéntico. Se exportan fuente,Pass y parámetros conocidos; faltantes permanecenNO DOCUMENTADO. No generarSET operable con suposiciones.

## 9. Figuras y limitaciones

21PNG estáticos conMatplotlib. Histogramas incluyen todos lospases; ejeslog/symlog se etiquetan. DispersiónPF/DD conserva extremos y distingue<50trades;72PFausentes se contabilizan. CurvasATR:45pases/punto; cuerpo:81;RR:45. Escalas porTF se etiquetan. Mapas de calor incluyen medianaTrades; color divergente centrado en0. Las vistas agrupadas son descriptivas y se complementan con vistas anualesM30. En mapas anuales los extremos saturados conservan su cifra escrita. En boxplot deestabilidad solo se omiten atípicos gráficos más allá de1,5IQR; todos losdatos siguen enCSV. El gráficoATRvsPIPS representa disponibilidad, no rendimientos inventados.

No hay datos deTrades ni Research reales vinculados. No usar ejemplosSYNTHETIC_RESEARCH como mercado. No tomar p-values de pases correlacionados, ni reetiquetar ninguno de2023–2026 inspeccionados comoOOS. No asumirigualdad de configuración fija,comisiones o riesgo entreaños sinmetadatos. Las recomendaciones son diseños de prueba, no instrucciones de operar.

## 10. Reproducción y auditoría

Orden de scripts en esta carpeta:`analizar.py`, `profundizar.py`, `verificar.py`, `graficos.py`, `informe.py`. `analizar.py --inspect` solo inspeccionaXML y guarda el inventario/dataset auxiliar. Todos leen originales sin editarlos. `verificar.py` restaura las14columnas originales en elCSV por texto exacto y comprueba los15candidatos/60filas. Tras reejecutar análisis, ejecutar siempreverificar antes de generar elinforme.

Runtime de cálculo:Python empaquetado deCodex,pandas,numpy,ElementTree. Matplotlib no estaba en elruntime; se instaló en `.deps` dentro de la carpeta de análisis, sin modificar elruntime ni elproyecto delEA. Los gráficos agregan ese directorio como fallback deimportación. `Auditoria_XML.json` contiene tamaños, namespaces, metadatos, rangos ySHA256. `Verificacion_Exportaciones.json` confirma181440celdas originales,12960filas,585excedentes y losfaltantes/discrepancias deorigen. Exportación fiel no significa que losdatos originales estén libres deincidencias.

Los archivos auxiliaresPKL yscripts son reproducibilidad local. Los entregables interpretables sonMarkdown,CSV,PNG yJSON. El número original de pase y elarchivo permiten volver a la optimización; la reproducción enMT5 sigue condicionada a recuperar losinputs fijos.
'''
(O/'Metodologia_Analisis.md').write_text(method,encoding='utf-8')
import re
def polish(text):
    # Corrección editorial de espacios, preservando código, URLs e identificadores en backticks.
    chunks=re.split(r'(```[\s\S]*?```|`[^`\n]*`|!?\[[^\]]*\]\([^)]*\)|https?://[^\s)]+)',text)
    for i in range(0,len(chunks),2):
        v=chunks[i]
        v=re.sub(r'\b([A-Za-zÀ-ÿ]{2,})(?=\d)',r'\1 ',v)
        v=re.sub(r'(?<=\d)(?=[A-DF-Za-df-zÀ-ÿ])',' ',v)
        v=re.sub(r'(?<=\d)(?=[eE](?![-+]?\d))',' ',v)
        v=re.sub(r'(?<=\d)([yo])(?=\d)',r' \1 ',v)
        v=re.sub(r'\b(de|en|a|por|el|los)(?=(?:M1|M3|M5|M15|M30|H1|H2|H4)\b)',r'\1 ',v)
        v=re.sub(r',(?=[A-Za-zÀ-ÿ])',', ',v)
        v=re.sub(r':(?=[A-Za-zÀ-ÿ])',': ',v)
        v=re.sub(r'\.(?=[A-ZÁÉÍÓÚ])','. ',v)
        for a,b in {'los4':'los 4','alos':'a los','cuerpo/ATR/RR':'cuerpo/ATR/RR','delTF':'del TF','cadaaño':'cada año','deProfit':'de Profit','nohay':'no hay','conN':'con N','losCSV':'los CSV','sinmetadatos':'sin metadatos','delaño':'del año','losdatos':'los datos','conMatplotlib':'con Matplotlib','porcentro':'por centro','TFyRR':'TF y RR','TFy':'TF y','RFy':'RF y','yRR':'y RR','año/TF':'año/TF','los15':'los 15','cuatroperíodos':'cuatro períodos','delos':'de los','elruntime':'el runtime','elproyecto':'el proyecto','fallback deimportación':'fallback de importación','losfaltantes':'los faltantes','deorigen':'de origen','deincidencias':'de incidencias','scripts sonreproducibilidad':'scripts son reproducibilidad','solo inspeccionaXML':'solo inspecciona XML','siempreverificar':'siempre verificar','elinforme':'el informe','deTrades':'de Trades','niResearch':'ni Research','deTicks':'de Ticks','de cuatroperíodos':'de cuatro períodos','índicesexplícitos':'índices explícitos','código(ocho':'código (ocho','Tradeactual':'Trade actual','los4períodos':'los 4 períodos','N50':'N50','deM':'de M','enM':'en M','deH':'de H','enH':'en H','de1':'de 1','vecinosFavorables':'vecinos Favorables','períodosFavorables':'períodos Favorables','periodosFavorables':'periodos Favorables','esquinasFavorables':'esquinas Favorables','todosFavorables':'todos Favorables','métricaCustom':'métrica Custom','por PFausente':'por PF ausente','72PF':'72 PF','0trades':'0 trades','conTrades':'con Trades','cuerpos/RR':'cuerpos/RR','casos con1':'casos con 1','tresvalores':'tres valores','deATR':'de ATR','deRR':'de RR','deTF':'de TF','TF,cuerpo':'TF, cuerpo','deDD':'de DD','amplitudProfit':'amplitud Profit','amplitudPF':'amplitud PF','amplitudDD':'amplitud DD','SSTglobal':'SST global','SSprincipales':'SS principales','SSpares':'SS pares','globales':'globales','nofinitos':'no finitos','ramaCustom':'rama Custom','delEA':'del EA','deOnTester':'de OnTester','laoptimización':'la optimización','delfuente':'del fuente','otraTF':'otra TF','losXML':'los XML','dePases':'de Pases','operaciones deuna':'operaciones de una','lafigura':'la figura','depases':'de pases','elarchivo':'el archivo','losinputs':'los inputs','deTrades':'de Trades','las14':'las 14','loscuatro':'los cuatro','enCSV':'en CSV','segúnMT5':'según MT5','lista deSignals':'lista de Signals','elCSV':'el CSV','porTF':'por TF','por año×TF':'por año × TF','de cuatroperíodos':'de cuatro períodos','de3':'de 3','alcódigo':'al código','numéricasafloat':'numéricas a float','tradespor':'trades por','no sepuede':'no se puede','del mismoN':'del mismo N','ventanasResearch':'ventanas Research','de cadaaño':'de cada año','por períodoacumulados':'por período acumulados','cuatro niveles de TF':'ocho valores de TF'}.items():
            v=v.replace(a,b)
        chunks[i]=v
        # Restaurar notación técnica y separar las pocas construcciones compactas restantes.
        for a,b in {'MT 5':'MT5','SHA 256':'SHA-256','float 64':'float64','M 1':'M1','M 3':'M3','M 5':'M5','M 15':'M15','M 30':'M30','H 1':'H1','H 2':'H2','H 4':'H4','interv a los':'intervalos','mo de los':'modelos','a2023':'a 2023','y1043':'y 1043','y116':'y 116','y3.190':'y 3.190','paresATR':'pares ATR','mesetasATR':'mesetas ATR','realResearch':'real Research','referenciaATR':'referencia ATR','nivelR':'nivel R','H1,132':'H1, 132'}.items():
            chunks[i]=chunks[i].replace(a,b)
        chunks[i]=re.sub(r'(?<=[;:])(?=\d)',' ',chunks[i])
    return ''.join(chunks)
for name in ['Informe_CandleMomentum_V1.2.md']:
    f=O/name;f.write_text(polish(f.read_text(encoding='utf-8')),encoding='utf-8')
(O/'Metodologia_Analisis.md').write_text((O/'metodologia_base.md').read_text(encoding='utf-8'),encoding='utf-8')
print('Report words',len(('\n\n'.join(parts)).split()),'method words',len(method.split()))
