# Informe Candle Momentum Research V1.2 — EURUSD

**Fecha del análisis:** 18 de octubre de 2026. **Universo:** cuatro exportaciones completas de MT5, 2023–2026. **Estado:** exploración retrospectiva; ninguna configuración validada para operar en real.

## 1. Resumen ejecutivo

**Hechos comprobados.** Hay **12.960 pases**, 3.240 por archivo, con una malla balanceada de 8 temporalidades, 5 cuerpos, 9 mínimos ATR y 9 RR. Las mismas 3.240 configuraciones aparecen en cada período. El encabezado M5 es el gráfico del tester, no la temporalidad de señal de cada pase. 2026 termina el **17/10/2026**, por lo que no representa un año completo.

**Cálculos derivados.** 2,002 pases (15.45%) tienen Profit positivo; 10,886 negativo y 72 no operan. Solo **830** cumplen simultáneamente Profit>0, PF>1, Expected Payoff>0, DD≤20% y al menos 50 trades. Son **424** con 100 y **119** con 200. Ninguna configuración gana en los cuatro períodos y alcanza 50 trades en cada uno. La única positiva en los cuatro, pase 1838, tiene 13–21 trades por período.

**Cálculos derivados.** Hay **585 pases excedentes redundantes (4,51%)** y **719 filas pertenecientes a grupos duplicados (5,55%)**. Son conceptos diferentes. H4 concentra 392 excedentes y H2 178. No hay duplicados de métricas en M1, M3, M5 ni M15. El ATR cambia las métricas en 11.198 de 11.520 comparaciones adyacentes controladas (97,20%); por sí solo esto no demuestra mejores señales ni ventaja sobre pips.

**Interpretación.** La evidencia más interesante aparece en **M30** y algunas regiones de **M15/H1**, pero depende fuertemente del período. La región M30 de cuerpo 75–85%, ATR aproximadamente 1,75–2,25 y RR 2–3 contiene familias prometedoras; no es favorable en todo ese rectángulo ni en todos los años. **2024 contradice buena parte de esa hipótesis.** H4 parece mejor si se cuenta cualquier ganancia, pero su mediana es apenas 15 trades. M1 pierde en sus 1.620 pases observados.

**Limitaciones comprobadas.** Se exportaron únicamente `InpSignalTimeframe`, `InpMinBodyPercent`, `InpMinRangeATR` e `InpRR`. Faltan el modo de filtro y los valores fijos del run. Hay 72 PF vacíos en pases sin operaciones y **46 discrepancias entre Expected Payoff y Profit/Trades**, todas con 1–4 trades. No hay telemetría real vinculada a estas optimizaciones. Los CSV de ejemplo Research son sintéticos y se excluyeron.

**Recomendación.** Se proponen **15 representantes**, cinco con tres períodos positivos y diez controles de hipótesis locales. No son un ranking de ganancias ni 15 estrategias aprobadas. Primero recuperar la configuración exacta y reconciliar operaciones/costos; después ejecutar un protocolo previamente fijado en datos no utilizados para seleccionar parámetros.

Convención numérica: las tablas usan punto decimal y coma de miles. Los CSV usan coma como separador, punto decimal, UTF-8 con BOM y preservan el número original de pase. `Año:Pase` identifica un resultado sin ambigüedad.

## 2. Validación del archivo

### Estructura y cobertura

Se leyó cada archivo completo con un parser XML consciente de SpreadsheetML. La raíz es `Workbook` del namespace `urn:schemas-microsoft-com:office:spreadsheet`. Se respetan los namespaces `o`, `x`, `ss` y `html`; el namespace por defecto cambia localmente a `office` dentro de DocumentProperties y vuelve al de spreadsheet fuera de él. Cada archivo tiene una hoja **Tester Optimizator Results**, una `Table`, una fila de encabezados y 3.240 filas de datos: **3.241 filas de hoja**. No hay filas truncadas ni columnas desplazadas. Las métricas son `Number`, salvo las celdas PF vacías exportadas como `String` en 2024 y 2026.

Los pases cubren 0–3239, sin repeticiones dentro de cada año. Se verificó el producto cartesiano íntegro y la correspondencia del mismo pase con los mismos cuatro parámetros en los cuatro archivos. Por tanto, **la cobertura observada es exhaustiva de esta malla**. Esto aporta evidencia fuerte a favor de una búsqueda completa, pero el archivo no registra el selector del algoritmo: no se afirma que se haya confirmado “Slow complete” frente a genética. `Condition=0` se conserva sin asignarle un significado no verificado.

### Metadatos

| Archivo | Período declarado | Depósito | Apalancamiento | Pases |
| --- | --- | --- | --- | --- |
| ReportOptimizer-2023.xml | 2023.01.01-2023.12.31 | 100000 USD | 1: 100 | 3240 |
| ReportOptimizer-2024.xml | 2024.01.01-2024.12.31 | 100000 USD | 1: 100 | 3240 |
| ReportOptimizer-2025.xml | 2025.01.01-2025.12.31 | 100000 USD | 1: 100 | 3240 |
| ReportOptimizer-2026.xml | 2026.01.01-2026.10.17 | 100000 USD | 1: 100 | 3240 |

Instrumento EURUSD; EA `CandleMomentum_Research_v1_2`; gráfico del tester M5; servidor `FivePercentOnline-Real`. Se conserva el nombre de servidor, pero **no demuestra que estos resultados procedan de una cuenta real operativa**. No se exportan número de cuenta, modo hedging/netting, modelo de ticks, calidad del histórico, latencia, comisiones ni configuración completa. `Version=500` y `Build=64` son campos del XML; no se usan para certificar el build del terminal. Las fechas declaradas no prueban cobertura de ticks hasta el último segundo ni excluyen un desplazamiento del inicio por falta de histórico.

Los presets `Original_Pips.set`, `RangeATR.set` y `Research.set` son ejemplos generales. Los INI de `validation` corresponden a pruebas del 12–13/10/2026, no a las cuatro optimizaciones. No se trasladan sus valores a estas corridas.

### Columnas originales

`Pass`, `Result`, `Profit`, `Expected Payoff`, `Profit Factor`, `Recovery Factor`, `Sharpe Ratio`, `Custom`, `Equity DD %`, `Trades`, `InpSignalTimeframe`, `InpMinBodyPercent`, `InpMinRangeATR`, `InpRR`.

### Integridad y conciliación

Los hashes SHA-256 anteriores y posteriores coinciden en los cuatro XML. Se releen las exportaciones y se comparan **181.440 celdas originales (12.960 × 14) por texto exacto**, incluidos decimales y vacíos. `Optimizacion_Procesada.csv` conserva estas representaciones y agrega columnas derivadas, fuente y fila XML. Se verificaron los 15 candidatos y sus 60 registros de los cuatro períodos contra el origen. Los controles están en `Verificacion_Exportaciones.json` y el inventario en `Auditoria_XML.json`.

Hay **72 celdas ausentes**, todas PF: 27 en 2024 y 45 en 2026. No hay valores numéricos no finitos ni negativos imposibles en trades/DD; los DD quedan entre 0 y 100. Los 72 pases sin trades no son evidencia de rentabilidad ni se rellenan con PF=0.

La identidad Expected Payoff=Profit/Trades se cumple dentro del redondeo de seis decimales en 12.842 de los 12.888 pases con trades. **Falla en 46**: 41 H4/2024 con un trade y 5 H2/2025 con 1–4 trades. Ejemplo: `2024:3119`, Profit=434,45, Trades=1, Expected Payoff=435,73, PF=340,414062. Diferencia=1,28 USD/trade. Es compatible con diferencias de imputación contable, pero su causa no está demostrada. Se preserva la métrica original y se añade `NetPayoffDerived=Profit/Trades`, sin corregir silenciosamente. Ver `Discrepancias_ExpectedPayoff.csv`. Estos pases no llegan al filtro mínimo de 50 trades.

## 3. Descripción de parámetros y criterio de optimización

### Parámetros efectivamente variados

| Parametro | Valores observados | Mínimo | Máximo | Valores distintos |
| --- | --- | --- | --- | --- |
| InpSignalTimeframe | 0 / 1 / 2 / 3 / 4 / 5 / 6 / 7 | 0 | 7 | 8 |
| InpMinBodyPercent | 75 / 80 / 85 / 90 / 95 | 75 | 95 | 5 |
| InpMinRangeATR | 0.5 / 0.75 / 1.0 / 1.25 / 1.5 / 1.75 / 2.0 / 2.25 / 2.5 | 0.500 | 2.500 | 9 |
| InpRR | 1.0 / 1.5 / 2.0 / 2.5 / 3.0 / 3.5 / 4.0 / 4.5 / 5.0 | 1 | 5 | 9 |

El enum del código local mapea 0=M1, 1=M3, 2=M5, 3=M15, 4=M30, 5=H1, 6=H2 y 7=H4. No son los enteros de `ENUM_TIMEFRAMES` estándar. La malla usa cuerpo 75–95 en pasos de 5 puntos porcentuales; ATR 0,5–2,5 en pasos de 0,25; RR 1–5 en pasos de 0,5. Cada TF tiene 405 pases por año, cada celda TF×ATR 45, TF×cuerpo 81 y TF×RR 45. Los cruces originales están equilibrados; los subconjuntos N≥50/100/200 dejan de estarlo.

### Qué documenta el código y qué no documentan las corridas

En el fuente disponible, cuerpo = 100·|Close−Open|/(High−Low). La vela gatillo es la cerrada `shift=1`; RangeATR=(High−Low)/ATR, con ATR anterior `shift=2` en la misma temporalidad de señal. El período ATR es configurable y no está exportado. Los umbrales son inclusivos con tolerancia numérica. El SL es el extremo de la vela y el TP usa el RR solicitado, redondeado al tick. No hay EMA ni trailing. Las restricciones de posiciones simultáneas, dirección, margen, spread y ejecución pueden cambiar qué señales llegan a ser trades.

**Riesgo monetario:** el EA contiene `InpRiskPercent`, un porcentaje del balance anterior a la operación; no un importe fijo por trade. El importe efectivo depende del balance, SL, tamaño de contrato y redondeo de volumen. Su valor usado aquí no consta. El default 1% no se trata como valor confirmado.

| Filtro del código | Parámetros de rango activos | Parámetros de rango irrelevantes |
|---|---|---|
| PIPS | Mínimo/máximo pips | Mínimo/máximo ATR para selección |
| ATR | Mínimo/máximo ATR y período ATR | Mínimo/máximo pips |
| PIPS_AND_ATR | Ambos conjuntos, período ATR | Ninguno de esos filtros |
| DISABLED | Ningún umbral de rango | Mínimos y máximos pips/ATR |

Máximo cero desactiva el límite en el código, pero **no se sabe si los máximos eran cero en estas corridas**. Spread máximo es irrelevante si su filtro está apagado; los inputs Research son ajenos a la selección comercial en MODE_TRADING. El período ATR también puede afectar disponibilidad de datos aunque no se aplique el umbral ATR. El inventario completo de los 26 inputs, con defaults etiquetados como referencia y nunca como ajustes del run, está en `Resumen_Parametros.csv`.

**Inferencia sustentada:** el comportamiento es MODE_TRADING bajo el código disponible: hay operaciones y el score no es el sentinel Research de −1.000.000.000. Además, al variar únicamente ATR en el espacio exportado cambian resultados, por lo que el filtro ATR parece activo: ATR o PIPS_AND_ATR. No puede distinguirse cuál. Esto presupone que el binario ejecutado corresponde al fuente local y que los ajustes no exportados se mantuvieron fijos dentro de cada optimización. No hay hash del binario ni metadatos de ejecución que cierren esa comprobación.

### Result y Custom

**Comprobado en los datos:** `Result=round(Custom,2)` en los 12.960 pases. Result no es Profit. El código de `OnTester()` usa n=STAT_TRADES, P=STAT_PROFIT, D=STAT_EQUITY_DD monetario y N=InpMinTradesForScore:

```text
Si MODE_RESEARCH: −1.000.000.000
Si n < N: −1.000.000 + n/N
En otro caso: clip[P/max(1,D) × min(1,n/(2N)), −999.999, 999.999]
Si resultado no finito: −1.000.000.000
```

**Validación derivada:** N=50 reproduce exactamente la rama de penalización; en los demás casos `Recovery Factor × min(1,n/100)` coincide con Custom con error máximo inferior a 5·10⁻⁷, consistente con el redondeo exportado de Recovery Factor. El DD monetario no está exportado, por lo que no se puede recomputar D independientemente a partir del DD porcentual. No se confunden ambos.

La evidencia identifica Result como la salida Custom del EA, consistente con “Custom max”. No certifica el selector original del tester. El score favorece retorno frente a DD y reduce peso entre 50 y 99 trades; no evalúa estabilidad de vecinos ni persistencia anual. Para N<50, los valores cercanos a −1.000.000 son penalizaciones, no pérdidas monetarias. La mediana global del score y su media mezclan ramas distintas, por lo que no se interpretan como retorno.

Referencia técnica: [MT5 — tipos y criterios de optimización](https://www.metatrader5.com/en/terminal/help/algotrading/optimization_types). La fórmula concreta procede del fuente local `OnTester()`, no de una fórmula universal de MT5.

## 4. Estadísticas globales

| Período | Pases | Positivos | Negativos | Sin_trades | % positivos | Profit med. USD | PF med. | DD med. % | Trades med. |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 2023 | 3,240 | 399 | 2,841 | 0 | 12.31 | -2,204.12 | 0.778 | 3.801 | 213 |
| 2024 | 3,240 | 264 | 2,949 | 27 | 8.148 | -3,193.24 | 0.704 | 4.126 | 160 |
| 2025 | 3,240 | 743 | 2,497 | 0 | 22.93 | -1,468.11 | 0.778 | 2.671 | 124.50 |
| 2026 | 3,240 | 596 | 2,599 | 45 | 18.40 | -1,590.81 | 0.788 | 3.063 | 147 |

Globalmente hay 3,828 pases con menos de 50 trades (incluidos 72 sin trades), 5,467 con menos de 100 y 6,972 con menos de 200. Son 3,153 con DD>20% y 1,646 con DD>50%. El umbral 20% es una convención exploratoria explícita, no un límite de riesgo aprobado por el usuario. Los conteos pueden superponerse.

Hay 72 pases con alguna métrica ausente, cero valores no finitos adicionales y 46 incidencias aritméticas de Expected Payoff separadas de esos faltantes. PF no interpretable por ausencia/sin operaciones: 72. Los PF finitos extremos no se anulan por ser altos, pero se separan por muestra: el máximo observado, 340,414062, procede de un único trade. Con ≥50 trades, el PF máximo es 1.974328. No hay conteos de ganadoras/perdedoras para explicar esos cocientes.

| Métrica | N numérico | Min | P25 | Mediana | P75 | P95 | Max |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Result | 12960 | -1,000,000 | -999,999.24 | -0.970 | -0.700 | 0.120 | 3.840 |
| Profit | 12960 | -93,284.06 | -17,673.85 | -2,145.54 | -353.54 | 696.29 | 4,829.08 |
| Expected Payoff | 12960 | -133.02 | -24.46 | -15.34 | -7.410 | 21.52 | 435.73 |
| Profit Factor | 12888 | 0 | 0.673 | 0.758 | 0.897 | 1.313 | 340.41 |
| Recovery Factor | 12960 | -1 | -0.952 | -0.766 | -0.325 | 0.788 | 5.128 |
| Sharpe Ratio | 12960 | -5 | -5 | -2.186 | -0.436 | 0.849 | 7.940 |
| Custom | 12960 | -1,000,000 | -999,999.24 | -0.966 | -0.701 | 0.120 | 3.841 |
| Equity DD % | 12960 | 0 | 1.350 | 3.386 | 18.87 | 85.38 | 93.46 |
| Trades | 12960 | 0 | 38 | 157 | 925.75 | 6,518.80 | 13,158 |

Las medias, desvíos, percentiles 5/25/50/75/95 y extremos de cada año están en `Distribuciones_Metricas.csv`. Estas distribuciones describen la malla de configuraciones, no una distribución de retornos independientes ni de probabilidades de éxito. No se suman los beneficios de estrategias alternativas ni se promedian PF para producir un PF de cartera. PF=0 con operaciones se conserva como resultado numéricamente posible; PF vacío queda ausente. Un Sharpe alto en pocos trades no prueba significancia ni se usa para seleccionar candidatos.

![Distribución de beneficio de todos los pases](Graficos/01_Distribucion_Profit.png)

![Beneficio y número de operaciones](Graficos/02_Profit_Trades.png)

![Profit Factor y drawdown con muestra visible](Graficos/03_PF_Drawdown.png)

## 5. Redundancia de optimizaciones

### Definiciones y conteos

La firma usa exactamente las nueve métricas exportadas: Result, Profit, Expected Payoff, PF, Recovery Factor, Sharpe, Custom, DD% y Trades. No se redondean para fabricar equivalencias. Dos vacíos en la misma métrica se tratan como el mismo estado ausente. Se agrupa **dentro de cada año**; un mismo valor en dos años no constituye redundancia de una corrida. Las comparaciones condicionales, además, fijan todos los otros parámetros exportados.

Se obtienen **12.375 resultados numéricos distintos por año acumulados**, 585 excedentes (12.960−12.375) y 719 filas dentro de grupos de tamaño>1, organizadas en 134 grupos duplicados. `Pases_Redundantes.csv` incluye las 719 filas, su representante (menor pase del grupo), tamaño, firma y flag `RedundantExtra`; al sumar ese flag se recuperan 585. 515 excedentes tienen trades>0 y 70 proceden de cero operaciones.

Las 3.240 combinaciones de parámetros son distintas. Al comparar el **perfil completo de métricas de los cuatro períodos**, quedan **3.190 perfiles distintos**, 50 combinaciones excedentes. Ni 3.190 perfiles ni 12.375 resultados equivalen a ese número de estrategias independientes o secuencias de trades distintas.

| Temporalidad | Pases | Resultados distintos | Pases redundantes | % redundancia |
| --- | --- | --- | --- | --- |
| M1 | 1,620 | 1,620 | 0 | 0 |
| M3 | 1,620 | 1,620 | 0 | 0 |
| M5 | 1,620 | 1,620 | 0 | 0 |
| M15 | 1,620 | 1,620 | 0 | 0 |
| M30 | 1,620 | 1,610 | 10 | 0.617 |
| H1 | 1,620 | 1,616 | 4 | 0.247 |
| H2 | 1,620 | 1,442 | 178 | 10.99 |
| H4 | 1,620 | 1,228 | 392 | 24.20 |

**Conciliación de la tabla:** sus excedentes suman 584, porque conserva un representante por TF y año. El total global es 585: en 2026 un grupo sin operaciones incluye 9 pases H2 y 36 H4. Al unir ambos TF queda un solo representante, añadiendo un excedente. Por la misma razón, los resultados distintos por TF suman 12.376, frente a 12.375 al agrupar todo el año.

![Redundancia de métricas por temporalidad](Graficos/05_Redundancia_Temporalidad.png)

### Qué variable produce repeticiones al mantener las demás constantes

| Parametro | Familias | Pases | Exceso |
| --- | --- | --- | --- |
| InpMinBodyPercent | 2592 | 12960 | 9 |
| InpMinRangeATR | 1440 | 12960 | 322 |
| InpRR | 1440 | 12960 | 429 |
| InpSignalTimeframe | 1620 | 12960 | 9 |

| Parametro | Pares | Identicos | Cambios_signo_pct | Cambio_abs_mediano | Identicos_pct |
| --- | --- | --- | --- | --- | --- |
| InpMinBodyPercent | 10368 | 9 | 14.78 | 1,129.84 | 0.087 |
| InpMinRangeATR | 11520 | 322 | 9.479 | 889.91 | 2.795 |
| InpRR | 11520 | 429 | 8.924 | 599.68 | 3.724 |
| InpSignalTimeframe | 11340 | 9 | 21.83 | 2,628.87 | 0.079 |

Los excedentes condicionales no se suman entre parámetros: una fila puede ser redundante en más de una dimensión. RR produce más pares adyacentes iguales que ATR en esta malla; eso no significa que RR sea generalmente irrelevante. No hay mínimo pips exportado, así que su redundancia no se puede medir ni contrastar con ATR.

En H4, el paso ATR 2→2,25 no cambia métricas en 66/180 pares (36,67%) y 2,25→2,5 en 52/180 (28,89%). **Ninguno de esos pares tiene ≥50 trades en ambos extremos.** En H2/H4, la escasez de operaciones explica parte de la aparente suavidad; el XML no prueba que sea toda la explicación. En M1–M30 no hay pares ATR adyacentes con todas las métricas iguales, aunque sí existen métricas individuales casi constantes.

`Intervalos_Sin_Cambio.csv` contiene cada par exacto y los parámetros que se mantuvieron fijos. `Redundancia_Condicional.csv` detecta también igualdad no adyacente dentro de la familia. La identidad se refiere a la precisión del export: dos recorridos diferentes pueden acabar con las mismas métricas. Para demostrar duplicación de operaciones hacen falta secuencias de SignalID, posición/deal, entrada/salida, volumen, precios, costos y timestamps. Una firma de selección de señales por sí sola tampoco prueba igualdad de fills.

## 6. Resultados por temporalidad

| TF | Pases | % positivos | Profit med. USD | PF med. | DD med. % | Trades med. | % N≥50 | % redundancia |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| M1 | 1,620 | 0 | -76,329.39 | 0.678 | 76.68 | 4,690 | 100 | 0 |
| M3 | 1,620 | 1.111 | -26,394.00 | 0.729 | 27.28 | 1,290 | 99.88 | 0 |
| M5 | 1,620 | 6.667 | -10,936.02 | 0.788 | 12.82 | 707.50 | 98.89 | 0 |
| M15 | 1,620 | 15.99 | -2,893.17 | 0.828 | 4.387 | 228 | 91.54 | 0 |
| M30 | 1,620 | 20.93 | -1,209.82 | 0.846 | 2.490 | 113 | 79.14 | 0.617 |
| H1 | 1,620 | 22.65 | -843.61 | 0.803 | 1.772 | 59 | 56.85 | 0.247 |
| H2 | 1,620 | 23.15 | -489.02 | 0.740 | 1.195 | 27 | 28.09 | 10.99 |
| H4 | 1,620 | 33.09 | -199.55 | 0.813 | 0.765 | 15 | 9.321 | 24.20 |

### Porcentaje positivo por período

| TF | 2023 | 2024 | 2025 | 2026 |
| --- | --- | --- | --- | --- |
| M1 | 0 | 0 | 0 | 0 |
| M3 | 0 | 0 | 0 | 4.444 |
| M5 | 6.667 | 3.210 | 0.988 | 15.80 |
| M15 | 11.85 | 10.62 | 34.57 | 6.914 |
| M30 | 29.14 | 0.988 | 18.02 | 35.56 |
| H1 | 23.70 | 8.395 | 27.16 | 31.36 |
| H2 | 12.59 | 6.173 | 55.56 | 18.27 |
| H4 | 14.57 | 35.80 | 47.16 | 34.81 |

**Interpretación por TF.**

- **M1:** 0 positivos de 1.620; PF mediano 0,678 y DD mediano 76,68%. Exigir más ATR recorta pérdidas y exposición, sin convertir ninguna combinación en rentable. No merece afinar esta malla comercial con estos supuestos.
- **M3:** 18 positivos (1,11%), principalmente un fenómeno local que no justifica una conclusión general. Puede conservarse un control de falsación, no una familia prioritaria.
- **M5:** hay una región de 2026 con cuerpos 90–95%, ATR 1,5–2,5 y RR aproximadamente 3–5, pero otros años no la sostienen. Conserva más trades que las temporalidades altas; la contradicción temporal debe investigarse.
- **M15:** mejor equilibrio de frecuencia que H1/H2/H4; algunos corredores ATR 1,5–2,5 con cuerpos 75–90 y RR 3,5–5 son favorables en 2025. El pase 1043 gana en tres períodos con ≥131 trades, pero no tiene una vecindad estable en 2026.
- **M30:** mayor número de pases favorables con muestra mínima (238) y varias regiones adyacentes útiles. La zona ATR 1,75–2,25/cuerpo 75–85/RR 2–3 merece pruebas dirigidas, manteniendo visible el fracaso de 2024. Existen otras mesetas de RR bajo en 2024 y 2026 que no deben confundirse con esa zona.
- **H1:** regiones de 2023 con cuerpos 80–85, ATR 1–2,25 y RR 3–4,5, y un corredor de 2025 cuerpo 80/RR 1,5/ATR 0,5–2. La preferencia de RR cambia según año; solo 56,85% de pases alcanza N≥50.
- **H2:** predomina la muestra reducida (mediana 27 trades); cuerpos 75–85 y ATR bajos merecen controles limitados. El único pase positivo en los cuatro períodos usa cuerpo 95%, pero su baja muestra lo excluye como evidencia de robustez.
- **H4:** 33,09% positivos en la malla, pero apenas 9,32% alcanza 50 trades. Una ganancia pequeña con 1–15 trades y DD pequeño no acredita superioridad. Los pocos representantes con N≥50 usan cuerpos 75–80 y ATR bajos.

Los CSV `Resumen_Anual_Temporalidad` y `Marginal_*` detallan estas comparaciones en cada año. Las medianas combinadas dan igual peso a cada pase y a cada período, no igual peso por día. No se anualiza 2026 ni se equiparan universos de trades diferentes. Las comparaciones de TF controlan los parámetros exportados y depósito, pero no pueden certificar los ajustes fijos omitidos.

![Porcentaje de configuraciones rentables por temporalidad](Graficos/04_Rentables_Temporalidad.png)

## 7. Estudio principal de RangeATR

### Efectos emparejados y relaciones con las métricas

Para cada año, TF, cuerpo y RR se ordenan los nueve valores ATR. Cada diferencia compara únicamente umbrales consecutivos (paso 0,25): **1.440 pares por TF**. Las medianas siguientes son de diferencias emparejadas, no diferencias entre dos mejores pases. DD está en puntos porcentuales; Profit y Expected Payoff, en USD y USD/trade.

| TF | ΔProfit med. | ΔPF med. | ΔDD pp med. | ΔTrades med. | ΔPayoff med. | % cambio signo | % idénticos |
| --- | --- | --- | --- | --- | --- | --- | --- |
| M1 | 7,811.62 | -0.000 | -7.631 | -784.50 | -1.821 | 0 | 0 |
| M3 | 6,361.81 | 0.006 | -5.973 | -341 | -0.551 | 1.250 | 0 |
| M5 | 3,666.43 | 0.014 | -3.529 | -186 | 0.543 | 4.792 | 0 |
| M15 | 1,006.83 | 0.015 | -0.947 | -56 | 1.083 | 11.88 | 0 |
| M30 | 418.57 | 0.010 | -0.394 | -27 | 0.822 | 16.53 | 0 |
| H1 | 169.20 | 0.006 | -0.204 | -11 | 0.593 | 12.57 | 0.278 |
| H2 | 101.87 | 0 | -0.151 | -6 | 0 | 14.37 | 3.750 |
| H4 | 0 | 0 | -0.048 | -3 | 0 | 14.44 | 18.33 |

**Interpretación.** Al elevar el umbral suele subir el Profit y bajar el DD, pero también se reducen operaciones. En M1, +0,25 ATR mejora el beneficio mediano del par en 7.811,62 USD mientras PF apenas cambia y Expected Payoff empeora: fundamentalmente se deja de ejecutar parte de una actividad perdedora. M15/M30 muestran mejoras medianas simultáneas de PF y Payoff, aunque pequeñas e inestables entre años. En H4 el cambio mediano de Profit y PF es cero; eso no significa que todos los pares sean iguales: solo 18,33% tiene todas las métricas idénticas.

`Correlaciones_Condicionales.csv` contiene medianas de Spearman calculadas dentro de cada familia fija (año, TF, cuerpo, RR). Se omiten familias constantes de la correlación y se cuenta cuántas contribuyen. No se calculan p-values, porque las familias y los pases no constituyen muestras independientes. Las cinco figuras siguientes separan los períodos y conservan el conteo de trades en una figura propia.

![Beneficio frente al mínimo ATR](Graficos/06_ATR_Profit.png)

![Profit Factor frente al mínimo ATR](Graficos/06_ATR_PF.png)

![Drawdown frente al mínimo ATR](Graficos/06_ATR_DD.png)

![Operaciones frente al mínimo ATR](Graficos/06_ATR_Trades.png)

![Expected Payoff frente al mínimo ATR](Graficos/06_ATR_Payoff.png)

### Sensibilidad y cambios importantes

Se llama “similar” a un par con |ΔProfit|≤500 USD (0,5% del depósito), |ΔPF|≤0,10 y |ΔDD|≤1 punto porcentual. “Cambio importante” usa |ΔProfit|≥1.000 USD (1% del depósito). Son umbrales de diagnóstico, no interva los de confianza. Se informa también cambio de signo sin depender del tamaño monetario. Un par similar puede estar compuesto por dos pérdidas o por muestras mínimas.

| TF | Mediana |ΔProfit| | P90 |ΔProfit| | % cambio ≥1.000 | % similares | % ambos favorables | Pares ambos N≥50 |
| --- | --- | --- | --- | --- | --- | --- |
| M1 | 7,811.62 | 14,878.71 | 79.72 | 19.10 | 0 | 1,440 |
| M3 | 6,394.11 | 12,682.84 | 95.42 | 0.694 | 0 | 1,438 |
| M5 | 3,756.35 | 9,127.61 | 85.56 | 5.278 | 3.403 | 1,422 |
| M15 | 1,170.73 | 3,484.38 | 55.69 | 18.61 | 7.500 | 1,303 |
| M30 | 811.89 | 2,168.75 | 38.61 | 27.85 | 8.958 | 1,102 |
| H1 | 414.23 | 1,265.43 | 16.18 | 39.03 | 5.486 | 771 |
| H2 | 306.60 | 859.27 | 6.042 | 38.47 | 2.569 | 329 |
| H4 | 178.81 | 616.15 | 1.806 | 43.26 | 1.389 | 94 |

En M30 cambia el signo del beneficio en 16,53% de los pasos ATR; en H4, 14,44%. Una meseta monetaria de pocos trades puede parecer más estable que una configuración con cientos de operaciones. Por eso la similitud no sustituye el filtro de muestra. Los detalles por intervalo, año, cuerpo, RR y pases están en `Sensibilidad_Intervalos.csv`, `Comparaciones_Vecinos.csv` y `Cambios_Importantes.csv`.

### Regiones favorables frente a mesetas similares

Se detectaron **116 tramos máximos de al menos tres valores ATR consecutivos favorables**, manteniendo año, TF, cuerpo y RR. Solo **9** cumplen además similitud sobre la extensión completa del tramo (amplitud Profit≤500, PF≤0,10, DD≤1 pp). Estos tramos no son observaciones independientes. La tabla presenta todas las nueve mesetas; no se interpola entre puntos ni fuera de sus límites.

| Año | TF | Cuerpo | RR | ATR desde | ATR hasta | N mín. | PF_min | Profit mín. | Profit máx. | DD_max | Passes |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 2023 | H1 | 85 | 4.500 | 1 | 1.500 | 66 | 1.087 | 561.97 | 814.70 | 2.537 | 2621 / 2661 / 2701 |
| 2023 | H2 | 75 | 4 | 1 | 1.500 | 57 | 1.009 | 44.94 | 476.87 | 2.236 | 2246 / 2286 / 2326 |
| 2023 | M30 | 90 | 2.500 | 1.750 | 2.250 | 50 | 1.035 | 125.70 | 323.84 | 2.105 | 1308 / 1348 / 1388 |
| 2024 | M30 | 75 | 1 | 1.750 | 2.250 | 186 | 1.015 | 258.78 | 571.60 | 1.520 | 204 / 244 / 284 |
| 2025 | M15 | 80 | 3.500 | 1.750 | 2.250 | 87 | 1.027 | 393.12 | 573.17 | 2.720 | 2011 / 2051 / 2091 |
| 2026 | M30 | 90 | 2.500 | 0.750 | 1.250 | 114 | 1.066 | 545.81 | 1,010.94 | 2.788 | 1148 / 1188 / 1228 |
| 2026 | M30 | 95 | 1 | 0.500 | 1.250 | 52 | 1.118 | 442.61 | 683.08 | 1.061 | 36 / 76 / 116 / 156 |
| 2026 | M30 | 95 | 1.500 | 0.500 | 1 | 61 | 1.178 | 697.29 | 1,101.90 | 1.038 | 396 / 436 / 476 |
| 2026 | M30 | 95 | 2 | 0.500 | 1 | 56 | 1.046 | 172.32 | 389.76 | 1.492 | 756 / 796 / 836 |

Ejemplos de corredores positivos más amplios, aunque no planos: H1/2025/cuerpo 80/RR 1,5 mantiene ganancias de ATR 0,5 a2 con mínimo 66 trades; M30/2025/cuerpo 75/RR 2 de ATR 1 a2,25 con mínimo 107; M5/2026/cuerpo 90/RR 3 de ATR 1,5 a2,5 con mínimo 109. El CSV `Regiones_ATR_Favorables` contiene los 116 tramos, incluidos sus pases, rangos de PF/Profit y DD.

**No hay evidencia de una región ATR uniformemente favorable a través de los cuatro períodos con N≥50.** La lectura útil es identificar mecanismos y contradicciones concretas, no declarar un umbral universal.

## 8. Comparación ATR vs PIPS

**Hecho:** no se exportaron `InpRangeFilter`, `InpMinRangePips` ni `InpMaxRangePips`; no hay corridas PIPS vinculadas con un manifiesto comparable. Los presets prueban que el EA admite filtros distintos, no que esas corridas se hayan realizado. El mínimo ATR observado afecta resultados, compatible con ATR o PIPS_AND_ATR bajo el fuente local.

**Cálculo posible:** medir cuánto cambia la salida al variar ATR manteniendo año y los otros tres parámetros exportados. Resultado: 97,20% de pares adyacentes cambia alguna métrica; en M1–M30 cambia el 100%, en H1 el 99,72%, H2 el 96,25% y H4 el 81,67%.

**Conclusión no identificable:** no se pueden estimar diferencias controladas ATR−PIPS en trades, Profit, PF, DD, Expected Payoff o redundancia. Tampoco puede atribuirse una reducción respecto a V1.1, cuyos datos disponibles pertenecen a otra estrategia/validación. El ATR tiene capacidad discriminante dentro de esta malla, pero **su superioridad frente a pips permanece sin demostrar**.

**Recomendación:** contrastar PIPS, ATR, PIPS_AND_ATR y DISABLED en familias apareadas con TF/cuerpo/RR/riesgo/spread idénticos. Elegir los umbrales de cada filtro mediante cuantiles de rango de un período de desarrollo o igualando aproximadamente número de señales, nunca optimizándolos sobre el futuro conjunto reservado. Reportar tanto volumen de señales como resultados comerciales: menos trades y menor DD no son por sí solos una ventaja.

![Limitación de la comparación ATR frente a pips](Graficos/09_ATR_vs_PIPS_Limitacion.png)

## 9. Porcentaje de cuerpo

Cada comparación sube 5 puntos porcentuales manteniendo año, TF, ATR y RR. Hay 1.296 pares por TF. Todos los niveles de cuerpo están presentes, pero un cuerpo de 95% puede dejar muy pocas observaciones en TF altos.

| TF | ΔProfit med. | ΔPF med. | ΔTrades med. | ΔPayoff med. | % cambio signo |
| --- | --- | --- | --- | --- | --- |
| M1 | 4,163.62 | -0.001 | -512 | -1.170 | 0 |
| M3 | 4,354.53 | -0.008 | -270.50 | -1.387 | 1.003 |
| M5 | 2,581.24 | 0.002 | -156.50 | -0.279 | 7.022 |
| M15 | 945.34 | 0.002 | -72 | -0.029 | 15.90 |
| M30 | 308.80 | -0.019 | -39 | -1.552 | 15.66 |
| H1 | 420.10 | 0.019 | -21 | 1.469 | 28.01 |
| H2 | 175.01 | -0.040 | -11 | -3.524 | 20.91 |
| H4 | 50.02 | -0.055 | -6 | -4.467 | 29.71 |

Subir el cuerpo eleva la mediana del Profit emparejado en todos los TF, pero **no mejora sistemáticamente la calidad por trade**. PF mediano del cambio baja en M1, M3, M30, H2 y H4; en H2/H4 el Payoff mediano también cae. En H1 se observa una mejora mediana pequeña de PF y Payoff, con 28,01% de cambios de signo entre cuerpos vecinos. El recorte reduce operaciones, con efectos especialmente fuertes en TF pequeños.

La interacción importa: M5/2026 favorece algunas combinaciones de cuerpo 90–95 y ATR altos; M30/2023/2025 favorece cuerpos 75–85 alrededor de ATR 1,75–2; H4/cuerpo 95 genera escasez extrema. No se recomienda reemplazar 80 por 90 o95 de forma universal. Los mapas muestran medianas y trades por celda; las tablas marginales contienen N≥50 por año y nivel.

![Interacción ATR por cuerpo con operaciones visibles](Graficos/07_ATR_Cuerpo.png)

![M30 ATR por cuerpo separado por período](Graficos/07b_M30_Cuerpo_Por_Periodo.png)

![Efectos del cuerpo por temporalidad y período](Graficos/14_Cuerpo_Profit.png)

## 10. Ratio riesgo/beneficio (RR)

Cada par cambia RR en +0,5 con año, TF, cuerpo y ATR constantes. **El número de operaciones puede cambiar al modificar RR**: el código bloquea ciertas entradas mientras hay posiciones abiertas y el TP modifica su duración. Los efectos no representan simplemente recalcular una lista fija de trades con otro TP.

| TF | ΔProfit med. | ΔPF med. | ΔDD pp med. | ΔTrades med. | ΔPayoff med. | % idénticos |
| --- | --- | --- | --- | --- | --- | --- |
| M1 | 617.53 | 0.003 | -0.595 | -324 | -0.957 | 0 |
| M3 | 1,213.25 | 0.004 | -0.984 | -109 | -1.106 | 0 |
| M5 | 569.65 | 0.003 | -0.238 | -48 | -0.853 | 0 |
| M15 | 141.44 | 0.002 | 0 | -14 | -0.589 | 0 |
| M30 | 29.64 | 0 | 0.003 | -6 | -0.544 | 0.694 |
| H1 | 134.68 | 0.036 | -0.001 | -3 | 2.277 | 0 |
| H2 | 19.26 | 0 | 0 | -1 | 0 | 10.21 |
| H4 | 5.530 | 0.023 | 0 | 0 | 0.107 | 18.89 |

Dentro de los resultados observados, M30 tiene representantes de RR 2–3 en tres períodos, pero también una meseta de RR 1 en 2024. H1 exhibe RR 3–4,5 favorables en 2023 y RR 1,5 en 2025. M5/2026 tiene corredores RR 3–5, cuya persistencia falla en años anteriores. No hay RR ganador universal.

El CSV de cruces y las diferencias emparejadas contienen todas las métricas solicitadas. Expected Payoff positivo describe la esperanza **muestral exportada**, con la salvedad contable de 46 casos. No estima por sí solo la esperanza poblacional. Los candidatos N≥50 tienen también Profit/Trades positivo.

El XML **no permite distinguir cuántas ganancias financian cada resultado** ni si RR alto depende de una sola ganadora. No se calculan win rates a partir de RR/PF/Trades. El umbral teórico de acierto 1/(1+RR) tampoco reemplaza el win rate real, porque pérdidas/ganancias efectivas, costos, redondeos y ejecución varían.

![Interacción ATR por RR](Graficos/08_ATR_RR.png)

![M30 ATR por RR separado por año](Graficos/08b_M30_RR_Por_Periodo.png)

![RR por temporalidad y año](Graficos/15_RR_Profit.png)

## 11. Interacciones entre parámetros

Los seis cruces solicitados con variables disponibles están documentados en `Cruce_*`: TF×ATR, TF×RR, TF×cuerpo, cuerpo×ATR, ATR×RR y, adicionalmente, cuerpo×RR. **Pips×TF no es observable**. Las seis tablas existentes cubren todos sus cruces sin imputación, con N, medianas de Profit/PF/DD/Trades y conteo favorable.

Para cuantificar influencia aparente se descompuso la variación de Profit en la malla balanceada mediante medias de factores y de interacciones de segundo orden. Se incluye año como factor. Es una descomposición descriptiva exacta del espacio observado; no una ANOVA inferencial ni una medición causal.

| Factor/interacción | Orden | % variación Profit |
| --- | --- | --- |
| InpSignalTimeframe | 1 | 74.93 |
| InpSignalTimeframe × InpMinRangeATR | 2 | 10.54 |
| InpMinRangeATR | 1 | 7.438 |
| Interacciones de orden >=3 | 3 | 2.219 |
| InpSignalTimeframe × InpMinBodyPercent | 2 | 1.464 |
| InpMinBodyPercent | 1 | 1.317 |
| InpSignalTimeframe × InpRR | 2 | 0.557 |
| Year × InpSignalTimeframe | 2 | 0.540 |
| InpRR | 1 | 0.334 |
| Year | 1 | 0.281 |
| InpMinRangeATR × InpRR | 2 | 0.110 |
| InpMinBodyPercent × InpMinRangeATR | 2 | 0.107 |

TF domina la variación monetaria global (74,93%); TF×ATR explica 10,54%, el efecto principal ATR 7,44% y cuerpo 1,32%. RR como efecto principal explica solo 0,33%, pero no es irrelevante: las medias globales ocultan efectos dependientes de TF y año. La gran pérdida de M1 domina esta escala. El archivo `Descomposicion_Varianza_Profit` también descompone por año × TF, donde esa dominancia desaparece. No se comparan tamaños de efecto causal entre un paso ATR 0,25, cuerpo 5 y RR 0,5 como si fueran unidades equivalentes.

La interacción temporal es sustantiva aunque el efecto principal global de año sea pequeño: un promedio dominado por pérdidas estructurales de M1 puede ocultar que las pocas zonas rentables cambian radicalmente entre años. En M30, elevar ATR tiende a mejorar Profit/PF hasta zonas intermedias; aumentarlo más puede vaciar la muestra y destruir una ganancia. Cuerpos mayores y ATR mayores restringen conjuntamente señales, con especial pérdida de soporte en H2/H4.

## 12. Robustez y sobreajuste

### Sensibilidad al mínimo de operaciones

“Favorable” exige Profit>0, PF>1 interpretable, Expected Payoff>0, DD≤20%, métricas finitas y trades≥N. La última columna exige además que al menos dos tercios de los vecinos axiales cumplan **el mismo N**; se evalúan cuerpo, ATR y RR, sin trasladarse a otra temporalidad.

| Período | N mínimo | Pases N suficiente | Favorables | % positivos con N | Favorables con ≥2/3 vecinos favorables |
| --- | --- | --- | --- | --- | --- |
| TODOS | 50 | 9132 | 830 | 9.089 | 295 |
| 2023 | 50 | 2428 | 275 | 11.33 | 111 |
| 2024 | 50 | 2349 | 66 | 2.810 | 15 |
| 2025 | 50 | 2150 | 247 | 11.49 | 90 |
| 2026 | 50 | 2205 | 242 | 10.98 | 79 |
| TODOS | 100 | 7493 | 424 | 5.659 | 115 |
| 2023 | 100 | 2019 | 144 | 7.132 | 44 |
| 2024 | 100 | 1900 | 35 | 1.842 | 4 |
| 2025 | 100 | 1750 | 119 | 6.800 | 30 |
| 2026 | 100 | 1824 | 126 | 6.908 | 37 |
| TODOS | 200 | 5988 | 119 | 1.987 | 12 |
| 2023 | 200 | 1652 | 17 | 1.029 | 0 |
| 2024 | 200 | 1495 | 8 | 0.535 | 0 |
| 2025 | 200 | 1390 | 45 | 3.237 | 3 |
| 2026 | 200 | 1451 | 49 | 3.377 | 9 |

50, 100 y 200 son referencias de tamaño, no garantías de significancia. Tampoco 200 trades son 200 observaciones independientes si hay señales superpuestas, posiciones simultáneas o concentración por sesión. `Trades` es el conteo agregado de MT5, utilizado como proxy de operaciones completas; el XML no permite auditar aperturas/cierres parciales ni el cierre de todas las posiciones al límite temporal.

### Vecindad y persistencia

Se usa vecindad axial de un paso de malla: mismo año/TF, cambia solo cuerpo ±5, ATR ±0,25 o RR ±0,5. Cada pase tiene de tres a seis vecinos observados. Los extremos tienen menor cobertura y se advierten como bordes; no se crean vecinos fuera de la malla. Se reporta proporción favorable, mediana y mínimo de beneficio vecino, diferencia absoluta y lista de IDs. Un 100% con tres vecinos de borde ofrece menos cobertura que seis vecinos interiores.

De 3.240 configuraciones, **1.829 no ganan en ningún período**, 905 ganan en uno, 422 en dos, 83 en tres y una en cuatro. Solo **21** ganan en tres períodos y tienen al menos 50 trades en cada uno de los cuatro. La única con cuatro ganancias es H2/cuerpo 95/ATR 0,5/RR 3,5 (pase 1838), con 21,20,13 y16 trades. No cumple ni el umbral inicial y se excluye de candidatos.

Se examinaron también 2.304 rectángulos mínimos de 2 cuerpos vecinos ×2 umbrales ATR vecinos con TF y RR fijos, seguidos en los cuatro períodos. **Ningún rectángulo tiene sus cuatro esquinas favorables en tres o cuatro períodos**. Solo seis lo consiguen en dos períodos; 81 en uno y2.217 en ninguno. Son regiones superpuestas, no experimentos independientes.

| TF | RR | Cuerpo desde | Cuerpo hasta | ATR_desde | ATR_hasta | 2023_Favorables_de4 | 2024_Favorables_de4 | 2025_Favorables_de4 | 2026_Favorables_de4 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| M30 | 2.500 | 75 | 80 | 1.750 | 2 | 4 | 0 | 4 | 2 |
| M30 | 3 | 75 | 80 | 1.750 | 2 | 4 | 0 | 4 | 2 |
| M30 | 4.500 | 80 | 85 | 1.750 | 2 | 4 | 0 | 2 | 4 |
| M30 | 3.500 | 75 | 80 | 1.750 | 2 | 4 | 0 | 4 | 1 |
| M30 | 1.500 | 75 | 80 | 1.500 | 1.750 | 0 | 0 | 4 | 4 |
| H1 | 4 | 75 | 80 | 1.250 | 1.500 | 4 | 0 | 4 | 0 |

**Interpretación:** hay estabilidad local útil para diseñar pruebas, pero no una región robusta demostrada temporalmente. Ejemplo M30/cuerpo 75–80/ATR 1,75–2/RR 2,5: 4/4 esquinas favorables en 2023 y2025, 0/4 en 2024 y2/4 en 2026. Seleccionar solo 2023/2025 exageraría la consistencia.

**Sobreajuste:** se examinaron miles de configuraciones correlacionadas. No hay corrección de selección que convierta estos datos en una prueba independiente. No se producen p-values por tratar pases como réplicas; no se calculan Deflated Sharpe, PBO, bootstrap de retornos, interva los de confianza de win rate ni probabilidades de ruina con agregados insuficientes. Las cuatro ventanas ya se usaron en esta selección, por lo que **ninguna queda fuera de muestra**. La coincidencia entre años es evidencia descriptiva adicional, condicionada a confirmar ajustes fijos iguales.

**Riesgo agregado:** DD por pase no revela concentración de riesgo, simultaneidad ni distribución de pérdidas. El fuente permite restricciones de exposición configurables, pero sus valores no aparecen. No se reconstruye una cartera sumando ganancias anuales reiniciadas con 100.000 USD ni combinando candidatos.

![Distribución de diferencias entre vecinos](Graficos/10_Diferencias_Vecinos.png)

![Operaciones y estabilidad aparente](Graficos/12_Muestra_Estabilidad.png)

## 13. Configuraciones candidatas

Se seleccionan **15 representantes de hipótesis**, no veinte por completar una cuota. C01–C05 tienen tres períodos positivos y mínimo 50 en cada período; C06–C15 son controles de regiones locales, y pueden resultar descartados tras las siguientes pruebas. Se incluye deliberadamente RR bajo en 2024 y cuerpos altos en 2026 para contrastar mecanismos diferentes. Ningún candidato satisface persistencia favorable en cuatro períodos. Todos tienen perfiles de métricas de cuatro períodos distintos.

La tabla muestra un **período de referencia favorable**, elegido por proporción de vecinos favorables, luego mayor muestra y luego PF. Esto facilita localizar el pase, pero no reemplaza la evidencia de los otros años, presentada inmediatamente después. La clase de filtro es **ATR activo inferido; ATR frente a PIPS_AND_ATR no verificado** para todos. Pips mínimo/máximo, ATR máximo, período ATR, riesgo y spread quedan **no documentados**. No se generan `.set` rellenando esos faltantes con defaults.

| Candidato | Pase | Año ref. | TF | Cuerpo | Filtro | Rango mín. ATR | RR | Trades | Profit | PF | DD % |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| C01 | 1324 | 2023 | M30 | 75 | ATR/AND* | 2 | 2.500 | 196 | 1,601.44 | 1.115 | 1.971 |
| C02 | 1300 | 2023 | M30 | 85 | ATR/AND* | 1.750 | 2.500 | 157 | 737.22 | 1.065 | 2.139 |
| C03 | 1043 | 2025 | M15 | 75 | ATR/AND* | 2.500 | 2 | 138 | 765.95 | 1.082 | 1.381 |
| C04 | 2542 | 2023 | H2 | 85 | ATR/AND* | 0.500 | 4.500 | 82 | 547.02 | 1.080 | 2.386 |
| C05 | 1095 | 2026 | H4 | 80 | ATR/AND* | 0.500 | 2.500 | 59 | 296.85 | 1.070 | 0.707 |
| C06 | 1933 | 2023 | H1 | 80 | ATR/AND* | 1.250 | 3.500 | 106 | 2,715.61 | 1.347 | 1.756 |
| C07 | 2003 | 2025 | M15 | 75 | ATR/AND* | 1.750 | 3.500 | 208 | 2,083.87 | 1.126 | 2.313 |
| C08 | 1634 | 2026 | M5 | 95 | ATR/AND* | 1.500 | 3 | 240 | 2,689.21 | 1.137 | 2.113 |
| C09 | 2137 | 2026 | M3 | 85 | ATR/AND* | 2.500 | 3.500 | 266 | 3,240.30 | 1.141 | 3.767 |
| C10 | 367 | 2026 | H4 | 75 | ATR/AND* | 0.500 | 1.500 | 78 | 1,212.90 | 1.285 | 0.841 |
| C11 | 2166 | 2025 | H2 | 75 | ATR/AND* | 0.500 | 4 | 76 | 2,299.96 | 1.390 | 1.591 |
| C12 | 884 | 2025 | M30 | 75 | ATR/AND* | 1.500 | 2 | 266 | 1,545.70 | 1.085 | 1.484 |
| C13 | 244 | 2024 | M30 | 75 | ATR/AND* | 2 | 1 | 246 | 571.60 | 1.046 | 1.191 |
| C14 | 2661 | 2023 | H1 | 85 | ATR/AND* | 1.250 | 4.500 | 76 | 561.97 | 1.087 | 2.041 |
| C15 | 116 | 2026 | M30 | 95 | ATR/AND* | 1 | 1 | 64 | 574.16 | 1.190 | 0.952 |

### Los mismos candidatos en todos los períodos

| Candidato | Profit 2023 | Profit 2024 | Profit 2025 | Profit 2026 parcial | Períodos + | N mín. | PF mín. | DD máx. % |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| C01 | 1,601.44 | -1,675.82 | 1,486.30 | 1,568.29 | 3 | 134 | 0.841 | 2.507 |
| C02 | 737.22 | -654.94 | 251.86 | 365.85 | 3 | 100 | 0.926 | 2.139 |
| C03 | 411.67 | 1,437 | 765.95 | -2,085.30 | 3 | 131 | 0.784 | 3.506 |
| C04 | 547.02 | -1,826.18 | 1,230.47 | 1,624.82 | 3 | 55 | 0.696 | 2.386 |
| C05 | -1,303.27 | 59.17 | 330.68 | 296.85 | 3 | 53 | 0.766 | 2.358 |
| C06 | 2,715.61 | -3,084.49 | -166.68 | -1,726.72 | 1 | 77 | 0.609 | 3.740 |
| C07 | -2,206.21 | -4,294.44 | 2,083.87 | -6,190.23 | 1 | 208 | 0.743 | 7.553 |
| C08 | -2,405.74 | -10,820.74 | -7,673.91 | 2,689.21 | 1 | 240 | 0.663 | 12.52 |
| C09 | -4,676.94 | -10,487.05 | -10,253.78 | 3,240.30 | 1 | 266 | 0.609 | 10.89 |
| C10 | -437.12 | -1,901.72 | -220.65 | 1,212.90 | 1 | 78 | 0.706 | 2.333 |
| C11 | -811.04 | -1,980.62 | 2,299.96 | -1,168.12 | 1 | 76 | 0.770 | 2.469 |
| C12 | -3,101.09 | -3,128.42 | 1,545.70 | -235.29 | 1 | 263 | 0.855 | 5.621 |
| C13 | -427.31 | 571.60 | -640.08 | -1,394.62 | 1 | 169 | 0.850 | 2.330 |
| C14 | 561.97 | -1,713.85 | -1,834.41 | 120.81 | 2 | 58 | 0.706 | 2.706 |
| C15 | -1,964.14 | -1,738.95 | -417.64 | 574.16 | 1 | 64 | 0.642 | 2.373 |

![Ganancias y pérdidas de los candidatos en cada período](Graficos/13_Candidatos_Periodos.png)

![Mapa de candidatos con peor período visible](Graficos/11_Mapa_Candidatos.png)

### C01 — pase 1324, M30, cuerpo 75%, ATR 2, RR 2.5

**Motivo/fortaleza:** M30, cuerpo 75%, ATR 2 y RR 2.5: centro de una región favorable en tres períodos. Clase: A. Repetición en 3 períodos. En la referencia 2023: 1324, 196 trades y 100.0% de vecinos favorables.

**Riesgo estadístico:** Falla en 2024; no supera persistencia temporal. Peor Profit entre períodos: -1,675.82 USD; muestra mínima: 134. Su inclusión no supera este contraejemplo.

**Vecino para contrastar estabilidad:** 2023: 1284, ATR 1.75, con el resto de parámetros exportados idénticos. Profit 234.18, PF 1.013, 244 trades. Se muestra el vecino ATR de menor beneficio disponible junto a la referencia, para no ocultar fragilidad; los demás están en `Estabilidad_Vecindad.csv`.

### C02 — pase 1300, M30, cuerpo 85%, ATR 1.75, RR 2.5

**Motivo/fortaleza:** M30 con cuerpo 85% representa un recorte distinto y al menos 100 trades por período. Clase: A. Repetición en 3 períodos. En la referencia 2023: 1300, 157 trades y 83.3% de vecinos favorables.

**Riesgo estadístico:** PF cercano a 1 y vecinos menos consistentes; costos pueden absorber la ventaja. Peor Profit entre períodos: -654.94 USD; muestra mínima: 100. Su inclusión no supera este contraejemplo.

**Vecino para contrastar estabilidad:** 2023: 1260, ATR 1.5, con el resto de parámetros exportados idénticos. Profit -1,649.18, PF 0.897, 213 trades. Se muestra el vecino ATR de menor beneficio disponible junto a la referencia, para no ocultar fragilidad; los demás están en `Estabilidad_Vecindad.csv`.

### C03 — pase 1043, M15, cuerpo 75%, ATR 2.5, RR 2

**Motivo/fortaleza:** M15 ofrece 131 o más trades por período y ganancias en 2023–2025. Clase: A. Repetición en 3 períodos. En la referencia 2025: 1043, 138 trades y 75.0% de vecinos favorables.

**Riesgo estadístico:** Pierde en 2026 y ATR 2.5 está en el borde de la malla. Peor Profit entre períodos: -2,085.30 USD; muestra mínima: 131. Su inclusión no supera este contraejemplo.

**Vecino para contrastar estabilidad:** 2025: 1003, ATR 2.25, con el resto de parámetros exportados idénticos. Profit 302.36, PF 1.024, 182 trades. Se muestra el vecino ATR de menor beneficio disponible junto a la referencia, para no ocultar fragilidad; los demás están en `Estabilidad_Vecindad.csv`.

### C04 — pase 2542, H2, cuerpo 85%, ATR 0.5, RR 4.5

**Motivo/fortaleza:** H2 con RR 4.5 diversifica temporalidad y objetivo; gana en tres períodos. Clase: A. Repetición en 3 períodos. En la referencia 2023: 2542, 82 trades y 40.0% de vecinos favorables.

**Riesgo estadístico:** Muestra mínima de 55 y vecindad débil; pierde en 2024. Peor Profit entre períodos: -1,826.18 USD; muestra mínima: 55. Su inclusión no supera este contraejemplo.

**Vecino para contrastar estabilidad:** 2023: 2582, ATR 0.75, con el resto de parámetros exportados idénticos. Profit -663.21, PF 0.901, 78 trades. Se muestra el vecino ATR de menor beneficio disponible junto a la referencia, para no ocultar fragilidad; los demás están en `Estabilidad_Vecindad.csv`.

### C05 — pase 1095, H4, cuerpo 80%, ATR 0.5, RR 2.5

**Motivo/fortaleza:** H4 de cuerpo 80% mantiene 53 o más trades por período. Clase: A. Repetición en 3 períodos. En la referencia 2026: 1095, 59 trades y 60.0% de vecinos favorables.

**Riesgo estadístico:** Pierde en 2023; ganancias pequeñas y muestras al límite. Peor Profit entre períodos: -1,303.27 USD; muestra mínima: 53. Su inclusión no supera este contraejemplo.

**Vecino para contrastar estabilidad:** 2026: 1135, ATR 0.75, con el resto de parámetros exportados idénticos. Profit 324.02, PF 1.087, 52 trades. Se muestra el vecino ATR de menor beneficio disponible junto a la referencia, para no ocultar fragilidad; los demás están en `Estabilidad_Vecindad.csv`.

### C06 — pase 1933, H1, cuerpo 80%, ATR 1.25, RR 3.5

**Motivo/fortaleza:** H1: vecindad completamente favorable en un período, con muestra superior a 100. Clase: B. Control de estabilidad local. En la referencia 2023: 1933, 106 trades y 100.0% de vecinos favorables.

**Riesgo estadístico:** La estabilidad local de 2023 no se mantiene entre períodos. Peor Profit entre períodos: -3,084.49 USD; muestra mínima: 77. Su inclusión no supera este contraejemplo.

**Vecino para contrastar estabilidad:** 2023: 1973, ATR 1.5, con el resto de parámetros exportados idénticos. Profit 1,724.27, PF 1.268, 85 trades. Se muestra el vecino ATR de menor beneficio disponible junto a la referencia, para no ocultar fragilidad; los demás están en `Estabilidad_Vecindad.csv`.

### C07 — pase 2003, M15, cuerpo 75%, ATR 1.75, RR 3.5

**Motivo/fortaleza:** M15 con ATR 1.75 y RR 3.5 representa una región más amplia de 2025. Clase: B. Control de estabilidad local. En la referencia 2025: 2003, 208 trades y 100.0% de vecinos favorables.

**Riesgo estadístico:** El resultado depende del período; no cumple tres períodos favorables. Peor Profit entre períodos: -6,190.23 USD; muestra mínima: 208. Su inclusión no supera este contraejemplo.

**Vecino para contrastar estabilidad:** 2025: 1963, ATR 1.5, con el resto de parámetros exportados idénticos. Profit 1,323.16, PF 1.060, 275 trades. Se muestra el vecino ATR de menor beneficio disponible junto a la referencia, para no ocultar fragilidad; los demás están en `Estabilidad_Vecindad.csv`.

### C08 — pase 1634, M5, cuerpo 95%, ATR 1.5, RR 3

**Motivo/fortaleza:** M5 de cuerpo 95% y RR 3 tiene vecinos favorables y 240 trades en 2026. Clase: B. Control de estabilidad local. En la referencia 2026: 1634, 240 trades y 100.0% de vecinos favorables.

**Riesgo estadístico:** Cuerpo en borde superior; otros años contradicen la señal favorable. Peor Profit entre períodos: -10,820.74 USD; muestra mínima: 240. Su inclusión no supera este contraejemplo.

**Vecino para contrastar estabilidad:** 2026: 1594, ATR 1.25, con el resto de parámetros exportados idénticos. Profit 146.40, PF 1.005, 357 trades. Se muestra el vecino ATR de menor beneficio disponible junto a la referencia, para no ocultar fragilidad; los demás están en `Estabilidad_Vecindad.csv`.

### C09 — pase 2137, M3, cuerpo 85%, ATR 2.5, RR 3.5

**Motivo/fortaleza:** M3 permite contrastar si el patrón de 2026 persiste con 266 trades. Clase: B. Control de estabilidad local. En la referencia 2026: 2137, 266 trades y 80.0% de vecinos favorables.

**Riesgo estadístico:** ATR en borde superior y fuerte deterioro en otros años. Peor Profit entre períodos: -10,487.05 USD; muestra mínima: 266. Su inclusión no supera este contraejemplo.

**Vecino para contrastar estabilidad:** 2026: 2097, ATR 2.25, con el resto de parámetros exportados idénticos. Profit -5,144.22, PF 0.849, 382 trades. Se muestra el vecino ATR de menor beneficio disponible junto a la referencia, para no ocultar fragilidad; los demás están en `Estabilidad_Vecindad.csv`.

### C10 — pase 367, H4, cuerpo 75%, ATR 0.5, RR 1.5

**Motivo/fortaleza:** H4, cuerpo 75% y RR 1.5 contrasta objetivos bajos con una zona local favorable en 2026. Clase: B. Control de estabilidad local. En la referencia 2026: 367, 78 trades y 100.0% de vecinos favorables.

**Riesgo estadístico:** ATR en borde inferior y apenas 78 trades en el período de referencia. Peor Profit entre períodos: -1,901.72 USD; muestra mínima: 78. Su inclusión no supera este contraejemplo.

**Vecino para contrastar estabilidad:** 2026: 407, ATR 0.75, con el resto de parámetros exportados idénticos. Profit 1,138.49, PF 1.305, 69 trades. Se muestra el vecino ATR de menor beneficio disponible junto a la referencia, para no ocultar fragilidad; los demás están en `Estabilidad_Vecindad.csv`.

### C11 — pase 2166, H2, cuerpo 75%, ATR 0.5, RR 4

**Motivo/fortaleza:** H2 con cuerpo 75% permite contrastar un universo más amplio que el candidato 2542. Clase: B. Control de estabilidad local. En la referencia 2025: 2166, 76 trades y 100.0% de vecinos favorables.

**Riesgo estadístico:** Muestra pequeña y dependencia del año; vecindad favorable solo local. Peor Profit entre períodos: -1,980.62 USD; muestra mínima: 76. Su inclusión no supera este contraejemplo.

**Vecino para contrastar estabilidad:** 2025: 2206, ATR 0.75, con el resto de parámetros exportados idénticos. Profit 2,285.77, PF 1.534, 57 trades. Se muestra el vecino ATR de menor beneficio disponible junto a la referencia, para no ocultar fragilidad; los demás están en `Estabilidad_Vecindad.csv`.

### C12 — pase 884, M30, cuerpo 75%, ATR 1.5, RR 2

**Motivo/fortaleza:** M30, ATR 1.5 y RR 2 representa mayor frecuencia que el centro ATR 2. Clase: B. Control de estabilidad local. En la referencia 2025: 884, 266 trades y 100.0% de vecinos favorables.

**Riesgo estadístico:** Ganancia y vecindad de 2025 no bastan para persistencia temporal. Peor Profit entre períodos: -3,128.42 USD; muestra mínima: 263. Su inclusión no supera este contraejemplo.

**Vecino para contrastar estabilidad:** 2025: 844, ATR 1.25, con el resto de parámetros exportados idénticos. Profit 371.02, PF 1.015, 354 trades. Se muestra el vecino ATR de menor beneficio disponible junto a la referencia, para no ocultar fragilidad; los demás están en `Estabilidad_Vecindad.csv`.

### C13 — pase 244, M30, cuerpo 75%, ATR 2, RR 1

**Motivo/fortaleza:** M30 con RR 1 representa la meseta ATR 1.75–2.25 observada en 2024, con al menos 186 trades en sus tres puntos. Clase: B. Control de estabilidad local. En la referencia 2024: 244, 246 trades y 50.0% de vecinos favorables.

**Riesgo estadístico:** Meseta de un solo período; el pequeño beneficio puede ser sensible a costos. Peor Profit entre períodos: -1,394.62 USD; muestra mínima: 169. Su inclusión no supera este contraejemplo.

**Vecino para contrastar estabilidad:** 2024: 204, ATR 1.75, con el resto de parámetros exportados idénticos. Profit 258.78, PF 1.015, 342 trades. Se muestra el vecino ATR de menor beneficio disponible junto a la referencia, para no ocultar fragilidad; los demás están en `Estabilidad_Vecindad.csv`.

### C14 — pase 2661, H1, cuerpo 85%, ATR 1.25, RR 4.5

**Motivo/fortaleza:** H1, cuerpo 85% y RR 4.5 representa una meseta de ATR 1–1.5 en 2023. Clase: B. Control de estabilidad local. En la referencia 2023: 2661, 76 trades y 83.3% de vecinos favorables.

**Riesgo estadístico:** Muestra moderada y falta de persistencia temporal; no confundir suavidad con ventaja. Peor Profit entre períodos: -1,834.41 USD; muestra mínima: 58. Su inclusión no supera este contraejemplo.

**Vecino para contrastar estabilidad:** 2023: 2701, ATR 1.5, con el resto de parámetros exportados idénticos. Profit 631.25, PF 1.115, 66 trades. Se muestra el vecino ATR de menor beneficio disponible junto a la referencia, para no ocultar fragilidad; los demás están en `Estabilidad_Vecindad.csv`.

### C15 — pase 116, M30, cuerpo 95%, ATR 1, RR 1

**Motivo/fortaleza:** M30, cuerpo 95% y RR 1 representa la meseta ATR 0.5–1.25 de 2026. Clase: B. Control de estabilidad local. En la referencia 2026: 116, 64 trades y 100.0% de vecinos favorables.

**Riesgo estadístico:** Cuerpo extremo y meseta local; varios puntos quedan cerca de la muestra mínima. Peor Profit entre períodos: -1,964.14 USD; muestra mínima: 64. Su inclusión no supera este contraejemplo.

**Vecino para contrastar estabilidad:** 2026: 156, ATR 1.25, con el resto de parámetros exportados idénticos. Profit 442.61, PF 1.180, 52 trades. Se muestra el vecino ATR de menor beneficio disponible junto a la referencia, para no ocultar fragilidad; los demás están en `Estabilidad_Vecindad.csv`.

`Top_20_Candidatos.csv` conserva estos 15 registros, todos los parámetros activos conocidos, faltantes explícitos, métricas anuales, justificación, riesgo y vecino. `Candidatos_Todos_Periodos.csv` contiene sus 60 filas originales con las métricas completas. El pase por sí solo es único dentro de su archivo; conservar siempre año/archivo y valores, incluso cuando aquí la numeración coincide entre años.

## 14. Conclusiones y límites de la evidencia

**Hechos comprobados:** malla completa, métricas mayoritariamente negativas, incidencias de calidad acotadas y ausencia de parámetros fijos. El código disponible describe un EA de continuación con SL en extremo, sin EMA ni trailing, pero no certifica el binario de cada optimización.

**Cálculos derivados:** el ATR distingue resultados en la mayor parte de la malla; hay redundancia concentrada en TF altos; existen mesetas locales, pero no persistencia de cuatro períodos con muestra mínima. Los mayores PF provienen de muestras minúsculas, con algunas discrepancias contables.

**Interpretación:** el resultado no demuestra una ventaja general de continuación después de una vela impulsiva. La reducción de pérdidas al exigir velas más grandes puede deberse a operar menos una señal con esperanza negativa. M30 ofrece hipótesis mejor apoyadas que elegir un pico de beneficio; 2024 sigue siendo una objeción fuerte.

**Hipótesis no demostradas:** el efecto podría depender del régimen de volatilidad, costos relativos al SL, selección por spread, horario, duración y competencia entre posiciones. El XML no separa esos mecanismos. Una continuación virtual favorable no implicaría necesariamente una cartera ejecutable favorable.

### Información que no puede reconstruirse

No hay operaciones individuales, win rate, conteos de ganadoras/perdedoras, comisiones desglosadas, spread por entrada, MFE/MAE, duración, secuencia de ganancias/pérdidas, OHLC de cada gatillo, distribución observada de RangeATR, primera llegada a R, resultados por día/mes, estabilidad dentro de cada año, posiciones simultáneas exactas ni riesgo monetario agregado. No se inventó ninguna de estas estadísticas. El conteo agregado de trades no informa dependencia o exposición.

`ResearchSignals.csv` y `ResearchLevels.csv` disponibles en `examples/SYNTHETIC_RESEARCH` son ejemplos explícitamente sintéticos. No se mezclaron con los resultados EURUSD. Los CSV EMA 200 del proyecto pertenecen a otra estrategia. No hay datos de MODE_RESEARCH reales vinculados a los cuatro XML que puedan complementar este estudio.

## 15. Próximos experimentos

### A. Mejorar el diseño de la próxima optimización

1. **Recuperar la corrida exacta:** `.set` usado, configuración INI del tester, hash del EX 5 y fuente, modelo de ticks, broker/contrato, divisa, spread/costos, ejecución, fechas efectivas y tipo de cuenta. Conservar los límites de exposición. Confirmar ATR vs PIPS_AND_ATR antes de interpretar cualquier diferencia como “ATR puro”.
2. **Mantener hipótesis acotadas:** priorizar M30 y contrastes M15/H1; dejar M3/M5 como controles para determinar si 2026 fue excepcional. No afinar M1 sobre esta evidencia comercial. En H2/H4 exigir un horizonte con muestra suficiente y no compensar escasez aumentando combinaciones.
3. **Malla inicial informativa:** mantener paso ATR 0,25 donde hubo cambios; no refinar universalmente. En M30 investigar por separado cuerpo 75–85/ATR 1,5–2,25/RR 2–3 y las mesetas RR 1 de 2024 o cuerpo 90–95/ATR bajo de 2026. La separación de hipótesis impide describir una caja grande como si todos sus puntos fueran favorables.
4. **Refinamiento condicionado:** considerar ATR 0,125 y cuerpo 2,5 puntos únicamente en desarrollo y donde haya suficientes señales y contraste vecinal. No ejecutar estos refinamientos sobre el futuro holdout. Antes, usar cuantiles reales de RangeATR para comprobar que esos pasos separan señales. Evitar afinar H4 en ATR 2–2,5: hay repetición elevada y ningún par con 50 trades en ambos extremos.
5. **No optimizar dimensiones inactivas:** pips bajo ATR puro, ATR bajo PIPS puro, máximos desactivados, spread máximo si su filtro está apagado. Mantener riesgo y restricciones de exposición fijos y documentados para las comparaciones. No asumir que el default es ese valor fijo.
6. **Comparación factorial pequeña ATR/PIPS:** mismo TF, cuerpo, RR, período, datos y costos, incluyendo DISABLED como referencia. Informar cambios en selección, ejecución y resultados por separado. No inferir la contribución de filtros a partir de conjuntos con cuerpos/RR distintos.

### B. Validación de candidatos

Prioridad de investigación: C01/C02 (familias M30 con tres períodos positivos), C03 (M15 como contraste), y C13/C14/C15 como controles de mesetas realmente similares. C04/C05 exploran TF altos con muestras más débiles. Los demás controles locales sirven para intentar refutar explicaciones basadas solo en 2026 o2025. “Prioridad” no significa autorización operativa; puede concluirse que ninguno merece una fase adicional tras auditar los costos.

### C. Fuera de muestra sin reoptimizar el conjunto reservado

1. Considerar **2023–17/10/2026 como datos de desarrollo ya inspeccionados**. No relabelar 2026 ni 2024 como validación independiente después de verlos. Una reconstrucción walk-forward histórica sería un diagnóstico retrospectivo, no un holdout nuevo.
2. Congelar por escrito una lista pequeña de candidatos/controles, parámetros completos, criterios de rechazo y protocolo de costos antes de mirar los resultados reservados. Guardar el manifiesto, hash de binario y nombres de pases; sin los inputs fijos faltantes, la reproducción exacta está pendiente.
3. Elegir un tramo histórico realmente no consultado (por ejemplo anterior a 2023 **solo si se confirma que nunca se usó**) o un período prospectivo a partir de la primera sesión negociable posterior al 17/10/2026. Fijar de antemano su fecha final o regla de duración; no detenerlo al alcanzar una ganancia. Para TF altos puede requerirse un horizonte largo. Si no se logran suficientes trades, el resultado es inconcluso, no aprobado.
4. Ejecutar **backtests individuales**, no optimización, con las configuraciones congeladas y el mismo depósito/contrato/riesgo/spread/ejecución. Separar pruebas de reproducción histórica de verdadera validación. No mezclar datos externos con distintos costos sin documentarlos.
5. Evaluar neto de todos los costos y deslizamiento; reportar Profit/Trades reconciliado, PF, DD, distribución mensual, pérdida máxima, dependencia de mayores ganadoras, duración, exposición y concentración temporal. Realizar un escenario de costos adverso previamente fijado, sin elegir después el favorable. Evaluar candidatos y controles juntos para no ocultar múltiples intentos.
6. Con trades y series temporales, estimar incertidumbre con bloques temporales que preserven dependencia; justificar longitud de bloque a partir de duración/superposición. No bootstrap de pases como si fueran independientes. No combinar candidatos sin estudiar coincidencia y riesgo agregado.
7. Tras un fracaso no modificar parámetros sobre el mismo holdout y llamarlo validación. Ese tramo pasaría a desarrollo; una nueva hipótesis requiere nueva evidencia reservada. Una validación favorable tampoco permite omitir riesgo de ejecución y exposición.

### D. Telemetría adicional

Solicitar/capturar en futuras ejecuciones autorizadas `RunMetadata.csv`, `Signals.csv`, `Trades.csv` y eventos de ejecución para corridas comerciales. Para investigación de precio, usar `ResearchSignals.csv` y `ResearchLevels.csv` reales, unidos por RunID+SignalID, con censura, primera llegada a cada nivel R, spread y ATR anterior. Agregar hashes de ticks y reglas de identificación estable. Mantener las métricas Research separadas: recorridos virtuales independientes no son beneficios de una cartera operativa.

El próximo experimento debe separar **selección de vela** de **ejecución/cartera**: para una pequeña lista congelada de familias M30 y contrastes M15/H1, comparar ATR/PIPS/DISABLED en desarrollo y después validar las hipótesis elegidas en datos reservados. Con la telemetría podrá investigarse si ATR mejora la continuación neta por operación o simplemente evita trades perdedores.

### Entregables y reproducibilidad

- `Informe_CandleMomentum_V1.2.md`: informe principal.
- `Optimizacion_Procesada.csv`: 12.960 filas,14 columnas fuente exactas más trazabilidad y derivados.
- `Pases_Redundantes.csv`: 719 miembros de grupos,585 marcados como excedentes.
- `Top_20_Candidatos.csv`: 15 representantes con motivos, riesgos, vecinos y resultados de los cuatro períodos.
- `Resumen_Parametros.csv`: 26 inputs del fuente con valores exportados o ausencia documentada.
- `Metodologia_Analisis.md`: fórmulas, reglas, limitaciones y secuencia reproducible.
- `Graficos/`: 21 PNG, incluyendo cinco vistas del efecto ATR y dos cruces anuales M30. El gráfico 09 documenta falta de comparación PIPS; no inventa una serie inexistente.
- CSV complementarios de calidad, distribuciones, sensibilidad, cruces, regiones y candidatos; JSON de auditoría y verificación.

Los scripts son únicamente analíticos. No se modificó el EA, sus presets ni los XML, no se cambiaron parámetros del tester y no se ejecutó ninguna optimización o backtest.

### Fuentes

Fuentes primarias: los cuatro XML en `Backtest`; código local `CandleMomentum_Research_v1_2.mq5` (inputs, filtros, referencia ATR y OnTester), `INPUTS.md`, `README.md`, presets y `validation/trading.ini` usados solo para contrastar su procedencia. Los hashes completos están en `Auditoria_XML.json`.

Documentación externa consultada para interpretar MT5: [estadísticas del tester](https://www.mql5.com/en/docs/constants/environment_state/statistics), [reporte de prueba](https://www.metatrader5.com/en/terminal/help/algotrading/testing_report), [optimización y exportación](https://www.metatrader5.com/en/terminal/help/algotrading/strategy_optimization). Las definiciones generales no sustituyen las incidencias observadas de estos archivos.

## Conclusión final: respuestas concretas

1. **¿Qué aprendimos sobre la continuación de velas impulsivas?** **Hecho/cálculo:** predominan las pérdidas y ninguna configuración con 50 trades por período gana en los cuatro. **Interpretación:** no hay evidencia de una ventaja general; algunos recortes muestran hipótesis locales, con fuerte dependencia del período.
2. **¿Qué temporalidades presentan regiones más favorables?** **Cálculo:** M30 reúne 238 pases favorables N≥50 y varias regiones contiguas; M15 aporta 212 y H1, 132. **Interpretación:** M30 merece la mayor atención exploratoria, seguido de M15/H1. H4 no es superior por tener más pases positivos sin controlar muestra.
3. **¿RangeATR aporta más información que pips?** **Hecho:** cambia métricas en 97,20% de pares ATR vecinos controlados. **Límite:** no hay comparación PIPS identificable, así que no puede afirmarse “más que pips”. La superioridad es una **hipótesis** pendiente.
4. **¿Cuántos pases fueron redundantes?** **Cálculo:**585 excedentes (4,51%) dentro de año; 719 filas integran 134 grupos repetidos. Quedan 12.375 resultados distintos por período acumulados y 3.190 perfiles distintos de cuatro períodos. No equivalen a operaciones idénticas demostradas.
5. **¿Qué parámetros influyen más aparentemente?** **Cálculo:** en la variación monetaria global dominan TF (74,93%), TF×ATR (10,54%) y ATR (7,44%). **Interpretación:** se explica en gran medida por frecuencia y enormes pérdidas de M1; no es un ranking causal de calidad de señal. Cuerpo y RR importan de manera condicionada.
6. **¿Qué combinaciones muestran mayor estabilidad vecinal?** **Cálculo:** nueve mesetas ATR similares, entre ellas M30/2024/cuerpo 75/RR 1/ATR 1,75–2,25 y H1/2023/cuerpo 85/RR 4,5/ATR 1–1,5. La región M30/cuerpo 75–80/ATR 1,75–2/RR 2,5 es favorable en 2023/2025 y falla en 2024. **Límite:** ninguna estabilidad de cuatro períodos está demostrada con N≥50.
7. **¿Qué conviene descartar?** **Recomendación:** M1 en esta malla, selección automática por PF extremo, pases sin operaciones o con muestras mínimas, refinamiento H4 de ATR alto con baja discriminación, y cualquier pico aislado presentado como robusto. El pase 1838 positivo en cuatro períodos no supera la muestra mínima. Los casos locales de M3/M5 solo se conservan como controles de falsación.
8. **¿Cuáles merecen validación fuera de muestra?** **Recomendación:** priorizar familias representadas por 1324,1300 y 1043, junto con controles de meseta 244,2661 y 116; el resto de los 15 representantes permite contrastar TF, cuerpo y RR. Todos tienen contraejemplos temporales y requieren recuperar inputs fijos antes de reproducirse. Ninguno está validado para real.
9. **¿Qué falta para evaluar la ventaja estadística real?** **Hecho:** faltan ajustes completos, costes, calidad de ticks, trades y secuencia, simultaneidad y riesgo agregado; también telemetría real Research. **Recomendación:** reconciliar 46 discrepancias contables y analizar dependencia, concentración y sensibilidad a costos antes de inferir incertidumbre.
10. **¿Cuál debe ser el próximo experimento cuantitativo?** **Recomendación:** congelar pocas familias y controles, recuperar su configuración completa, comparar ATR/PIPS/DISABLED con todo lo demás fijo en desarrollo y realizar backtests individuales sobre datos nunca usados en selección, con trades/telemetría y protocolo de rechazo predefinidos. **Hipótesis a refutar:** que ATR mejora la continuación neta por operación, y no solo reduce la cantidad de operaciones de una señal perdedora.
