from pathlib import Path
import pandas as pd
import numpy as np
import itertools,json
O=Path(__file__).resolve().parent
D=pd.read_pickle(O/'datos.pkl');C=pd.read_pickle(O/'configuraciones.pkl')
P=pd.read_csv(O/'Comparaciones_Vecinos.csv')
TF=['M1','M3','M5','M15','M30','H1','H2','H4']
PARAMS=['InpSignalTimeframe','InpMinBodyPercent','InpMinRangeATR','InpRR']
def csv(x,name): x.to_csv(O/(name+'.csv'),index=False,encoding='utf-8-sig')
print('ATR\n',pd.read_csv(O/'Sensibilidad_Parametro_TF.csv').loc[lambda x:x.Parametro.eq('InpMinRangeATR')].to_string(index=False))
print('BODY\n',pd.read_csv(O/'Sensibilidad_Parametro_TF.csv').loc[lambda x:x.Parametro.eq('InpMinBodyPercent')].to_string(index=False))

# Efectos ortogonales descriptivos en una malla balanceada, sin inferencia causal.
effects=[]
for scope,g,params in [('Global',D,['Year']+PARAMS)]+[(str(y)+'_'+tf,g,PARAMS[1:]) for (y,tf),g in D.groupby(['Year','TF'])]:
    y=g.Profit;mu=y.mean();ss=((y-mu)**2).sum(); mains={}
    for p in params:
        mains[p]=g.groupby(p).Profit.mean()
        pred=g[p].map(mains[p])-mu
        effects.append({'Ambito':scope,'Termino':p,'Orden':1,'SS':float((pred**2).sum()),'Varianza_pct':100*(pred**2).sum()/ss})
    for a,b in itertools.combinations(params,2):
        joint=g.groupby([a,b]).Profit.transform('mean')
        effect=joint-g[a].map(mains[a])-g[b].map(mains[b])+mu
        effects.append({'Ambito':scope,'Termino':a+' × '+b,'Orden':2,'SS':float((effect**2).sum()),'Varianza_pct':100*(effect**2).sum()/ss})
    explained=sum(e['SS'] for e in effects if e['Ambito']==scope)
    effects.append({'Ambito':scope,'Termino':'Interacciones de orden >=3','Orden':3,'SS':ss-explained,'Varianza_pct':100*(ss-explained)/ss})
E=pd.DataFrame(effects);csv(E,'Descomposicion_Varianza_Profit')

# Regiones ATR contiguas favorables: conserva año, TF, cuerpo y RR.
regions=[]
for key,g in D.groupby(['Year','TF','InpMinBodyPercent','InpRR']):
    rows=list(g.sort_values('InpMinRangeATR').to_dict('records'));run=[]
    def add(run):
        if len(run)>=3:
            h=pd.DataFrame(run)
            regions.append(dict(zip(['Year','TF','Body','RR'],key))|{'ATR_desde':h.InpMinRangeATR.min(),'ATR_hasta':h.InpMinRangeATR.max(),'N_valores':len(h),'Trades_min':int(h.Trades.min()),'PF_min':h['Profit Factor'].min(),'Profit_min':h.Profit.min(),'Profit_max':h.Profit.max(),'Profit_mediana':h.Profit.median(),'DD_max':h['Equity DD %'].max(),'Passes':'|'.join(h.Pass.astype(str)),'Similar_toda_region':h.Profit.max()-h.Profit.min()<=500 and h['Profit Factor'].max()-h['Profit Factor'].min()<=.1 and h['Equity DD %'].max()-h['Equity DD %'].min()<=1})
    for r in rows:
        if r['Favorable50']:run.append(r)
        else:add(run);run=[]
    add(run)
R=pd.DataFrame(regions);csv(R,'Regiones_ATR_Favorables')
# Todos los rectángulos mínimos 2x2, RR fijo, cuatro años: comprueba persistencia sin imputar.
boxes=[]
body=sorted(D.InpMinBodyPercent.unique());atr=sorted(D.InpMinRangeATR.unique())
for tf in TF:
    for rr in sorted(D.InpRR.unique()):
        for b0,b1 in zip(body,body[1:]):
            for a0,a1 in zip(atr,atr[1:]):
                g=D[(D.TF==tf)&(D.InpRR==rr)&D.InpMinBodyPercent.isin([b0,b1])&D.InpMinRangeATR.isin([a0,a1])]
                assert len(g)==16
                per=g.groupby('Year').Favorable50.sum()
                boxes.append({'TF':tf,'RR':rr,'Body_desde':b0,'Body_hasta':b1,'ATR_desde':a0,'ATR_hasta':a1,'Periodos4de4Favorables':int(per.eq(4).sum()),'Favorables_de16':int(g.Favorable50.sum()),'Profit_min':g.Profit.min(),'Trades_min':g.Trades.min(),**{str(k)+'_Favorables_de4':v for k,v in per.items()}})
B=pd.DataFrame(boxes);csv(B,'Regiones_Rectangulares')

# Selección intencional de representantes, revisable, no ranking de beneficios.
specs=[
(1324,'A. Repetición en 3 períodos','M30, cuerpo 75%, ATR 2 y RR 2.5: centro de una región favorable en tres períodos.','Falla en 2024; no supera persistencia temporal.'),
(1300,'A. Repetición en 3 períodos','M30 con cuerpo 85% representa un recorte distinto y al menos 100 trades por período.','PF cercano a 1 y vecinos menos consistentes; costos pueden absorber la ventaja.'),
(1043,'A. Repetición en 3 períodos','M15 ofrece 131 o más trades por período y ganancias en 2023–2025.','Pierde en 2026 y ATR 2.5 está en el borde de la malla.'),
(2542,'A. Repetición en 3 períodos','H2 con RR 4.5 diversifica temporalidad y objetivo; gana en tres períodos.','Muestra mínima de 55 y vecindad débil; pierde en 2024.'),
(1095,'A. Repetición en 3 períodos','H4 de cuerpo 80% mantiene 53 o más trades por período.','Pierde en 2023; ganancias pequeñas y muestras al límite.'),
(1933,'B. Control de estabilidad local','H1: vecindad completamente favorable en un período, con muestra superior a 100.','La estabilidad local de 2023 no se mantiene entre períodos.'),
(2003,'B. Control de estabilidad local','M15 con ATR 1.75 y RR 3.5 representa una región más amplia de 2025.','El resultado depende del período; no cumple tres períodos favorables.'),
(1634,'B. Control de estabilidad local','M5 de cuerpo 95% y RR 3 tiene vecinos favorables y 240 trades en 2026.','Cuerpo en borde superior; otros años contradicen la señal favorable.'),
(2137,'B. Control de estabilidad local','M3 permite contrastar si el patrón de 2026 persiste con 266 trades.','ATR en borde superior y fuerte deterioro en otros años.'),
(367,'B. Control de estabilidad local','H4, cuerpo 75% y RR 1.5 contrasta objetivos bajos con una zona local favorable en 2026.','ATR en borde inferior y apenas 78 trades en el período de referencia.'),
(2166,'B. Control de estabilidad local','H2 con cuerpo 75% permite contrastar un universo más amplio que el candidato 2542.','Muestra pequeña y dependencia del año; vecindad favorable solo local.'),
(884,'B. Control de estabilidad local','M30, ATR 1.5 y RR 2 representa mayor frecuencia que el centro ATR 2.','Ganancia y vecindad de 2025 no bastan para persistencia temporal.'),
(244,'B. Control de estabilidad local','M30 con RR 1 representa la meseta ATR 1.75–2.25 observada en 2024, con al menos 186 trades en sus tres puntos.','Meseta de un solo período; el pequeño beneficio puede ser sensible a costos.'),
(2661,'B. Control de estabilidad local','H1, cuerpo 85% y RR 4.5 representa una meseta de ATR 1–1.5 en 2023.','Muestra moderada y falta de persistencia temporal; no confundir suavidad con ventaja.'),
(116,'B. Control de estabilidad local','M30, cuerpo 95% y RR 1 representa la meseta ATR 0.5–1.25 de 2026.','Cuerpo extremo y meseta local; varios puntos quedan cerca de la muestra mínima.')]
selected=[]
for order,(pas,tier,reason,risk) in enumerate(specs,1):
    cfg=C[C.Pass==pas].iloc[0]
    eligible=D[(D.Pass==pas)&D.Favorable50]
    anchor=eligible.sort_values(['NeighborFavorable50Pct','Trades','Profit Factor'],ascending=False).iloc[0]
    q=P[(P.Parametro=='InpMinRangeATR')&((P.ID_A==anchor.ID)|(P.ID_B==anchor.ID))].copy()
    # Mostrar el vecino ATR con peor beneficio ayuda a exponer fragilidad.
    q['NeighborID']=np.where(q.ID_A==anchor.ID,q.ID_B,q.ID_A)
    n=D.set_index('ID').loc[q.NeighborID].sort_values('Profit').iloc[0]
    rec={'Candidato':'C'+str(order).zfill(2),'Clase':tier,'Pase':pas,'Periodo_referencia':int(anchor.Year),'ID_referencia':anchor.ID,'TF':anchor.TF,'Cuerpo':anchor.InpMinBodyPercent,'Filtro':'ATR activo inferido; ATR/AND sin verificar','Rango_min_pips':'NO DOCUMENTADO','ATR_min':anchor.InpMinRangeATR,'ATR_max':'NO DOCUMENTADO','Pips_max':'NO DOCUMENTADO','ATR_periodo':'NO DOCUMENTADO','RR':anchor.InpRR,'Trades':anchor.Trades,'Profit':anchor.Profit,'PF':anchor['Profit Factor'],'DD_pct':anchor['Equity DD %'],'Expected_Payoff':anchor['Expected Payoff'],'Vecinos_favorables_pct':anchor.NeighborFavorable50Pct,'Periodos_positivos':cfg.PeriodosPositivos,'Periodos_favorables50':cfg.PeriodosFavorables50,'Trades_min_4periodos':cfg.TradesMin,'Profit_min_4periodos':cfg.ProfitMin,'DD_max_4periodos':cfg.DDmax,'PF_min_4periodos':cfg.PFmin,'Vecino_ID':n.name,'Vecino_ATR':n.InpMinRangeATR,'Vecino_Profit':n.Profit,'Vecino_PF':n['Profit Factor'],'Vecino_Trades':n.Trades,'Justificacion':reason,'Riesgo':risk}
    for year in [2023,2024,2025,2026]:
        for col in ['Profit','Profit Factor','Trades','Equity DD %','Expected Payoff','NeighborFavorable50Pct']:
            rec[str(year)+'_'+col]=cfg[str(year)+'_'+col]
    selected.append(rec)
S=pd.DataFrame(selected);assert len(S)<=20 and S.Pase.is_unique
assert C[C.Pass.isin(S.Pase)].Profile.nunique()==len(S)
csv(S,'Top_20_Candidatos')
csv(D[D.Pass.isin(S.Pase)].sort_values(['Pass','Year']),'Candidatos_Todos_Periodos')

# Inventario completo de inputs: valores exportados y referencia sin atribuir defaults al run.
source=(O.parent.parent/'CandleMomentum_Research_v1_2/CandleMomentum_Research_v1_2.mq5').read_text(encoding='utf-8-sig')
import re
inv=[]
for typ,name,default in re.findall(r'^input\s+(\w+)\s+(\w+)\s*=([^;]+);',source,re.M):
    inv.append({'Parametro':name,'Tipo':typ,'Presente_XML':name in PARAMS,'Valores_XML':'|'.join(map(str,sorted(D[name].unique()))) if name in PARAMS else '', 'Min_XML':D[name].min() if name in PARAMS else np.nan,'Max_XML':D[name].max() if name in PARAMS else np.nan,'N_valores_XML':D[name].nunique() if name in PARAMS else 0,'Default_fuente_NO_valor_del_run':default,'Estado':'Exportado y variado' if name in PARAMS else 'Valor de corrida no documentado','Fuente':'XML cuatro años' if name in PARAMS else 'Fuente EA y presets de ejemplo sin vínculo a estas corridas'})
csv(pd.DataFrame(inv),'Resumen_Parametros')
print('VARIANCE\n',E[E.Ambito=='Global'].sort_values('Varianza_pct',ascending=False).head(12).to_string(index=False))
print('REGIONS',len(R),'similar',R.Similar_toda_region.sum());print(R.sort_values(['N_valores','Trades_min'],ascending=False).head(20).to_string(index=False))
print('BOX',B.groupby('Periodos4de4Favorables').size().to_string());print(B.sort_values(['Periodos4de4Favorables','Favorables_de16'],ascending=False).head(10).to_string(index=False))
print('SELECTED\n',S[['Candidato','Pase','Periodo_referencia','TF','Cuerpo','ATR_min','RR','Trades','Profit','PF','DD_pct','Periodos_positivos','Trades_min_4periodos','Profit_min_4periodos']].to_string(index=False))
