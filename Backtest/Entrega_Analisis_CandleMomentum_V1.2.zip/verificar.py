from pathlib import Path
import xml.etree.ElementTree as ET
import hashlib,json,re
import pandas as pd,numpy as np
O=Path(__file__).resolve().parent
D=pd.read_pickle(O/'datos.pkl')
D['NetPayoffDerived']=D.Profit/D.Trades.replace(0,np.nan)
D['PayoffDifference']=D['Expected Payoff']-D.NetPayoffDerived
D['PayoffMismatch']=D.PayoffDifference.abs().gt(.000001)
D[D.PayoffMismatch].to_csv(O/'Discrepancias_ExpectedPayoff.csv',index=False,encoding='utf-8-sig')
D.to_pickle(O/'datos.pkl')
meta=json.loads((O/'Auditoria_XML.json').read_text(encoding='utf-8'))
ns={'s':'urn:schemas-microsoft-com:office:spreadsheet'}
original={};checks=[]
for m in meta:
    f=O.parent/m['file'];raw=f.read_bytes();assert hashlib.sha256(raw).hexdigest()==m['sha256']
    root=ET.fromstring(raw);rows=root.findall('s:Worksheet/s:Table/s:Row',ns)
    vals=[[(''.join(c.itertext()) if c is not None else '') for c in row.findall('s:Cell/s:Data',ns)] for row in rows]
    header=vals[0];year=int(re.search(r'20\d{2}',f.name).group())
    for row in vals[1:]:original[f.name+':'+row[0]]=dict(zip(header,row))
    checks.append({'File':f.name,'SHA256':m['sha256'],'Rows':len(vals)-1,'OriginalUnchanged':True})
# Conservar además la representación textual exacta de todas las columnas originales.
export=D.copy()
for idx,row in export.iterrows():
    record=original[row.SourceFile+':'+str(int(row.Pass))]
    for col in header:
        if export[col].dtype!=object:export[col]=export[col].astype(object)
        export.at[idx,col]=record[col]
export=export.sort_values(['Year','XML_Row'])
export.to_csv(O/'Optimizacion_Procesada.csv',index=False,encoding='utf-8-sig')
reread=pd.read_csv(O/'Optimizacion_Procesada.csv',dtype=str,keep_default_na=False,encoding='utf-8-sig')
cells=0
for _,row in reread.iterrows():
    record=original[row.SourceFile+':'+row.Pass]
    for col in header:
        assert row[col]==record[col],(row.ID,col,row[col],record[col]);cells+=1
assert len(reread)==12960
assert set(reread.ID)==set(D.ID)
err=(D['Expected Payoff']-D.Profit/D.Trades.replace(0,np.nan)).abs()
assert int(D.PayoffMismatch.sum())==46
assert D.loc[D.PayoffMismatch,'Trades'].between(1,4).all()
assert err.loc[~D.PayoffMismatch].max()<=.00000051
assert ((D.Trades>=0)&(D.Trades%1==0)).all()
assert D['Equity DD %'].between(0,100).all()
assert (D.loc[D.PF_interpretable,'Profit Factor']>=0).all()
assert (D.Trades.eq(0)==D['Profit Factor'].isna()).all()
assert D.groupby('Year').Pass.nunique().eq(3240).all()
assert not D.duplicated(['Year','InpSignalTimeframe','InpMinBodyPercent','InpMinRangeATR','InpRR']).any()
S=pd.read_csv(O/'Top_20_Candidatos.csv');assert len(S)<=20 and S.Pase.is_unique
indexed=D.set_index('ID')
for _,s in S.iterrows():
    r=indexed.loc[s.ID_referencia]
    assert r.Pass==s.Pase and r.TF==s.TF and r.InpMinBodyPercent==s.Cuerpo and r.InpMinRangeATR==s.ATR_min and r.InpRR==s.RR
    assert np.allclose([r.Profit,r['Profit Factor'],r['Equity DD %'],r.Trades],[s.Profit,s.PF,s.DD_pct,s.Trades],rtol=1e-12,atol=1e-9)
    assert r.Favorable50
    for year in [2023,2024,2025,2026]:
        rr=indexed.loc[str(year)+':'+str(s.Pase)]
        for col in ['Profit','Profit Factor','Trades','Equity DD %','Expected Payoff','NeighborFavorable50Pct']:
            assert np.isclose(s[str(year)+'_'+col],rr[col],rtol=1e-12,atol=1e-9)
rep=pd.read_csv(O/'Pases_Redundantes.csv')
assert len(rep)==D.MetricGroupSize.gt(1).sum()
assert int(rep.RedundantExtra.sum())==585
assert D.groupby('Year').apply(lambda g:len(g)-g[header[1:10]].drop_duplicates().shape[0],include_groups=False).sum()==585

# Umbrales de muestra aplicados tanto a centros como a vecinos.
sens=[]
for threshold in [50,100,200]:
    flags=D.Favorable50&D.Trades.ge(threshold);mapping=dict(zip(D.ID,flags))
    fraction=D.NeighborIDs.apply(lambda ids:sum(mapping[x] for x in ids.split('|'))/len(ids.split('|')))
    for year in ['TODOS',2023,2024,2025,2026]:
        scope=np.ones(len(D),dtype=bool) if year=='TODOS' else D.Year.eq(year)
        enough=scope&D.Trades.ge(threshold);favorable=scope&flags
        sens.append({'Periodo':year,'MinTrades':threshold,'ConMuestra':int(enough.sum()),'Favorables':int(favorable.sum()),'Rentables_pct_condicional':100*D.loc[enough].Profit.gt(0).mean(),'Favorables_vecinos_mismo_N_ge_dos_tercios':int((favorable&fraction.ge(2/3)).sum())})
pd.DataFrame(sens).to_csv(O/'Sensibilidad_Muestra_Vecinos.csv',index=False,encoding='utf-8-sig')
legacy=[]
base_neighbors=D.NeighborFavorable50Pct.ge(200/3-1e-9)
for year in ['TODOS',2023,2024,2025,2026]:
    scope=np.ones(len(D),dtype=bool) if year=='TODOS' else D.Year.eq(year)
    for threshold in [50,100,200]:
        enough=scope&D.Trades.ge(threshold);fav=enough&D.Favorable50
        legacy.append({'Periodo':year,'MinTrades':threshold,'ConMuestra':int(enough.sum()),'Positivos':int((enough&D.Profit.gt(0)).sum()),'Favorables':int(fav.sum()),'Rentables_pct_condicional':100*D.loc[enough].Profit.gt(0).mean(),'Favorables_vecindad50_ge_dos_tercios':int((fav&base_neighbors).sum())})
pd.DataFrame(legacy).to_csv(O/'Sensibilidad_Muestra.csv',index=False,encoding='utf-8-sig')
assert legacy[0]['Favorables_vecindad50_ge_dos_tercios']==sens[0]['Favorables_vecinos_mismo_N_ge_dos_tercios']
audit={'status':'EXPORTACION_VERIFICADA_CON_INCIDENCIAS_DEL_ORIGEN_DOCUMENTADAS','source_files':checks,'rows':len(D),'original_cells_verified_text_exact':cells,'candidate_count':len(S),'candidate_rows_four_periods':len(S)*4,'payoff_max_difference':err.max(),'payoff_mismatch_rows':int(D.PayoffMismatch.sum()),'duplicate_excess':585,'duplicate_members':len(rep),'missing_pf':int(D['Profit Factor'].isna().sum()),'no_original_xml_changes':True}
(O/'Verificacion_Exportaciones.json').write_text(json.dumps(audit,indent=2),encoding='utf-8')
print(json.dumps(audit,indent=2))
