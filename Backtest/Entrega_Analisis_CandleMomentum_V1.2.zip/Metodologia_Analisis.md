# Metodología del análisis — Candle Momentum V1.2

Fecha: 18/10/2026. Objetivo: describir la optimización y proponer pruebas independientes, sin modificar el EA ni ejecutar MT5.

## 1. Fuentes y unidad de observación

Se procesaron completos los cuatro XML SpreadsheetML: 3.240 pases por archivo. La unidad primaria es un pase en un período. Su clave es `SourceFile+Pass`; la versión legible es `Year:Pass`. Se unen configuraciones entre períodos mediante los cuatro parámetros exportados, comprobando además que la numeración coincide. El período 2026 termina el 17/10. Los pases comparten datos y operaciones: no son observaciones estadísticamente independientes.

El parser `xml.etree.ElementTree` distingue los namespaces y respeta índices explícitos de filas/celdas y huecos. Audita encabezados, longitud de filas y tipos. Guarda `XML_Row`. Se comprueba la malla completa de 8 × 5 × 9 × 9 y los hashes SHA-256 de los archivos antes y después. El enum del fuente traduce los ocho valores 0–7 a M1/M3/M5/M15/M30/H1/H2/H4; no se usa el M5 del título como temporalidad del pase.

El CSV procesado conserva por texto exacto las 14 columnas originales, incluso todos los decimales y vacíos. El cálculo utiliza su conversión numérica; los valores ausentes nunca se convierten a cero. Los demás CSV guardan números derivados con precisión de coma flotante. No se atribuyen los defaults del fuente ni los presets generales a las corridas.

## 2. Métricas y unidades

| Columna | Interpretación empleada | Límite |
|---|---|---|
| Pass | Identificador original | Unir siempre con archivo/año |
| Profit | Resultado monetario neto reportado por MT5, USD según depósito | Sin deals no se certifican todos los costos |
| Expected Payoff | Métrica por trade exportada, USD/trade | En 46 casos no coincide con Profit/Trades |
| NetPayoffDerived | Profit/Trades cuando Trades>0 | Se guarda separado; vacío con cero trades |
| Profit Factor | Cociente de beneficio/pérdida brutos del tester | Sin componentes brutos no se reconstruye |
| Recovery Factor | Beneficio relativo al drawdown monetario empleado por el tester | DD monetario no exportado; solo se comprueba compatibilidad con Custom |
| Sharpe Ratio | Sharpe agregado exportado | No permite reconstruir retornos ni significancia |
| Equity DD % | Drawdown relativo porcentual de equity | No equivale al DD monetario utilizado en OnTester |
| Trades | Conteo agregado de MT5 | Proxy de operaciones completas; cierres parciales y posiciones finales no auditables |
| Custom | Salida de OnTester compatible con el código disponible | No expresa dólares |
| Result | Custom redondeado a dos decimales en todos los pases | No se interpreta como beneficio |

PF interpretable para resúmenes: finito, ≥0 y <1e6, con Trades>0. El techo solo detectaría sentinels enormes; ningún PF observado lo alcanza. Los 72 PF vacíos se omiten de su mediana. PF=0 con operaciones se conserva. Los PF altos finitos no se eliminan por conveniencia, pero se distingue su muestra. El máximo observado (340,414062) procede de un trade. “Interpretable” no equivale a fiable estadísticamente.

Custom según el código:

```text
Si MODE_RESEARCH: −1e9
Si n < N: −1e6 + n/N
Si n ≥ N: clip[P/max(1,D) × min(1,n/(2N)), −999999, 999999]
Si el resultado no es finito: −1e9
```

Aquí n es Trades, P es Profit y D es el drawdown monetario de equity. N=50 reproduce la rama de penalización. Para n≥50 se compara con `Recovery Factor × min(1,n/100)`; el error máximo es inferior a 5e-7, compatible con el redondeo exportado. Esta concordancia no sustituye una reconstrucción independiente de D ni certifica el binario ejecutado.

Fuentes técnicas: [estadísticas MT5](https://www.mql5.com/en/docs/constants/environment_state/statistics), [reporte MT5](https://www.metatrader5.com/en/terminal/help/algotrading/testing_report) y el fuente local del EA. Las discrepancias observadas se documentan aunque una definición general sugiera una identidad.

## 3. Calidad y filtros

- Positivo: Profit>0. Negativo: Profit<0. Neutro: Profit=0. Sin operaciones: Trades=0.
- Muestra insuficiente: Trades<N. Se evalúan N=50, 100 y 200 sin atribuir significancia a esos umbrales.
- Métrica ausente/inválida: alguna de las nueve métricas vacía o no finita. Hay 72 filas, todas por PF vacío; no existen otros NaN/inf de origen.
- Discrepancia Payoff: `abs(Expected Payoff − Profit/Trades)>1e-6`. Hay 46 casos con 1–4 trades. Los restantes son compatibles con redondeo a seis decimales. No se corrigen ni se inventa su explicación.
- DD elevado: >20%. DD severo: >50%. Son referencias exploratorias, no límites de inversión aprobados.
- Favorable_N: Profit>0, PF>1 interpretable, Expected Payoff>0, DD≤20%, métricas finitas y Trades≥N. Se conserva el universo completo en el procesado; los filtros solo definen subconjuntos.

## 4. Distribuciones y comparaciones controladas

Se calculan conteo, media, desviación muestral (ddof=1), mínimo, cuantiles 5/25/50/75/95 y máximo. Los cuantiles usan interpolación lineal de pandas. Solo se omiten ausentes de la métrica correspondiente. Porcentaje positivo = 100 × número de pases con Profit>0 / número de pases; las tablas filtradas indican explícitamente el denominador de muestra suficiente.

Al combinar períodos, cada uno aporta el mismo número de pases. No se ponderan días, no se anualiza 2026 y no se suman beneficios como si fueran una cartera continua. PF, DD y Sharpe no son aditivos.

Para estudiar un parámetro se agrupa primero por año y todos los demás parámetros exportados. Dentro de esa familia se ordenan sus valores y comparan consecutivos: Δm = m(siguiente) − m(previo). Pasos: cuerpo +5 puntos porcentuales, ATR +0,25 y RR +0,5. Los TF son categorías; sus pasos no representan distancias temporales uniformes. No se certifica igualdad de inputs ocultos entre años.

Spearman se calcula como correlación de rangos con empates de rango medio dentro de cada familia fija. Las familias constantes se excluyen de esa correlación, informando el número válido. Se resumen mediana y extremos; no se producen p-values de familias dependientes. Mejorar Profit al operar menos no implica mejorar la esperanza por trade.

## 5. Redundancia

El vector de identidad contiene las nueve métricas originales, incluido Custom de máxima precisión. Los números se normalizan a float64 y los vacíos a un token único; no se redondean. Se calcula SHA-256 de su representación hexadecimal y se valida el conteo mediante eliminación directa de vectores duplicados. Los grupos se mantienen separados por año.

Para un grupo de k filas, excedentes = k−1. Total excedentes = N−K, donde K es el número de vectores distintos. Miembros duplicados = suma de k en grupos con k>1. Resultado global: 585 excedentes y 719 miembros en 134 grupos. El representante es el menor Pass. El CSV incluye todos los miembros y `RedundantExtra`.

Por TF se calcula la misma medida dentro de cada TF/año. Esas filas suman 584 excedentes; aparece uno adicional al unir el grupo sin trades de H2 y H4 de 2026. No es una inconsistencia de exportación: cambia la restricción de agrupación.

La redundancia condicional fija año y todos los otros parámetros antes de contar repeticiones. Los resultados de distintas dimensiones se solapan y no se suman. El conteo de pares idénticos consecutivos tampoco equivale al conteo de excedentes, que puede incluir coincidencias no adyacentes.

El perfil de cuatro períodos concatena sus firmas ordenadas por año. Hay 3.190 perfiles distintos entre 3.240 configuraciones. Ningún conteo demuestra igualdad de operaciones, fills o independencia. Tampoco una firma de SignalID basta para probar iguales ejecuciones.

## 6. Sensibilidad y estabilidad

Se define un cambio importante por |ΔProfit|≥1.000 USD (1% del depósito). Un par es similar si simultáneamente |ΔProfit|≤500 USD, |ΔPF|≤0,10 y |ΔDD|≤1 punto porcentual. Cambio de signo significa ProfitA×ProfitB<0; los ceros no cuentan como inversión. Se exportan también las diferencias continuas para no depender únicamente de estos cortes arbitrarios.

La vecindad axial cambia un paso en cuerpo, ATR o RR, conservando año/TF y las otras variables. Solo se usan los 3–6 vecinos observados; no se completan bordes. `NeighborFavorable50Pct` = 100 × vecinos favorables con N=50 / vecinos disponibles. Se guardan IDs, mediana y mínimo de Profit vecino, mínimo de Trades y mediana de |ΔProfit|.

La sensibilidad principal aplica el mismo N=50/100/200 al centro y a sus vecinos, y cuenta centros favorables con al menos dos tercios de vecinos favorables. Se usa tolerancia numérica cuando se compara un porcentaje flotante con 2/3. `Sensibilidad_Muestra_Vecinos.csv` contiene esa versión. `Sensibilidad_Muestra.csv` mantiene la variante de centros con diferentes N pero vecinos siempre evaluados con N=50; su encabezado lo explicita.

Corredores ATR: tramos máximos de al menos tres valores consecutivos favorables con año/TF/cuerpo/RR fijos. Hay 116. Una meseta además exige que la amplitud de Profit en todo el tramo sea ≤500 USD, la de PF ≤0,10 y la de DD ≤1 punto. Hay nueve. No se infieren valores intermedios.

Rectángulos: dos cuerpos vecinos × dos umbrales ATR vecinos, con TF y RR fijos. Se examinan 2.304 rectángulos en los cuatro períodos. Para considerar favorable un período se exigen cuatro esquinas favorables. Ninguno alcanza tres o cuatro períodos completos favorables; seis alcanzan dos. Estas regiones se solapan.

## 7. Interacciones y variación explicada

En la malla balanceada, μ es la media global de Profit. El efecto principal de un nivel es su media menos μ. El efecto de un par de factores es:

```text
efecto(a,b) = media(Profit|a,b) − media(Profit|a) − media(Profit|b) + μ
SS_efecto = suma del cuadrado del efecto asignado a cada fila
% variación = 100 × SS_efecto / SST
```

Los componentes son ortogonales en el diseño completo. El residuo tras efectos principales y pares contiene interacciones de orden ≥3; no se interpreta como ruido independiente. Se incluye año como factor global y se repite la descomposición en cada año×TF para cuerpo/ATR/RR. No hay pruebas F ni p-values. Las pérdidas monetarias de M1 dominan la escala global; el ranking no representa causalidad ni calidad intrínseca de señal.

## 8. Selección de candidatos

Se eligen intencionalmente 15 representantes, no mediante un score opaco ni por máximo Profit. Cinco familias ganan en tres períodos y conservan N≥50 en cada uno; diez controles representan regiones locales, incluidas tres mesetas similares. Se exige diversidad de TF/cuerpo/ATR/RR y perfiles distintos. Todos tienen fallas temporales explícitas; ninguno supera cuatro períodos favorables.

El período de referencia se elige entre los favorables de esa configuración ordenando primero porcentaje de vecinos favorables, luego Trades y PF, de mayor a menor. Sirve para localizar el pase; la tabla inmediata y el CSV muestran también los otros períodos. El vecino explicado es el adyacente ATR de menor beneficio en esa referencia, con los otros parámetros exportados idénticos. Los inputs fijos faltantes quedan como “NO DOCUMENTADO”; no se crean SET operables suponiendo defaults.

## 9. Figuras y límites inferenciales

Se generan 21 PNG estáticos con Matplotlib. Los histogramas incluyen todos los pases; se etiquetan ejes log/symlog. La dispersión PF/DD conserva los extremos, distingue muestras <50 y contabiliza los 72 PF ausentes. Cada punto de curvas ATR contiene 45 pases; cuerpo, 81; RR, 45. Se indican escalas por TF.

Los mapas de calor incluyen trades medianos y colores divergentes centrados en cero. Las vistas agrupadas se complementan con vistas anuales M30. Cuando el color anual se satura en extremos, las cifras completas siguen escritas. El boxplot de estabilidad omite gráficamente los atípicos más allá de 1,5 IQR; todos permanecen en CSV. La figura ATR/PIPS muestra disponibilidad de evidencia, no rendimientos inexistentes.

No hay trades ni telemetría Research real vinculados. Los ejemplos sintéticos se excluyen. No se inventan win rate, MFE/MAE, duración, riesgo de ruina, secuencias o resultados diarios. No se aplica bootstrap a pases como si fueran independientes ni se presenta ninguno de los períodos inspeccionados como OOS. Los recorridos virtuales Research no son beneficios de una cartera.

## 10. Reproducción y auditoría

Orden de ejecución: `analizar.py`, `profundizar.py`, `verificar.py`, `graficos.py`, `informe.py`. Todos son scripts analíticos y no invocan MT5. `analizar.py --inspect` inspecciona los XML completos y guarda inventario y dataset auxiliar. Después de recalcular debe ejecutarse siempre `verificar.py`, que restaura las representaciones originales en el CSV procesado y concilia candidatos y tablas.

El cálculo usa Python empaquetado de Codex, pandas, numpy y ElementTree. Matplotlib no estaba disponible y se instaló en `.deps`, dentro de la carpeta de análisis, sin modificar el runtime ni el EA. El script de gráficos agrega ese directorio como fallback de importación.

`Auditoria_XML.json` conserva tamaño, namespaces, metadatos, rangos y hashes. `Verificacion_Exportaciones.json` verifica 181.440 celdas originales, 12.960 filas, 15 candidatos con 60 filas anuales y los conteos de redundancia. Documenta también los 72 faltantes y 46 discrepancias del origen. Exportación fiel no significa datos originales sin incidencias.

Los CSV usan UTF-8 con BOM, coma como separador y punto decimal. Los PKL y scripts son auxiliares de reproducción local. La reproducción exacta en MT5 queda pendiente de recuperar los inputs fijos de las optimizaciones.
