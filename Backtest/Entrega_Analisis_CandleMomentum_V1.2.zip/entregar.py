from pathlib import Path
import re,json,hashlib,zipfile,sys
import pandas as pd,numpy as np
from PIL import Image
O=Path(__file__).resolve().parent
# Pequeñas correcciones editoriales sin cambiar cifras ni fuentes.
f=O/'Informe_CandleMomentum_V1.2.md';t=f.read_text(encoding='utf-8')
for a,b in {'pasoATR':'paso ATR','ATRbajo':'ATR bajo','corredoresATR':'corredores ATR','la fórmulaCustom':'la fórmula Custom','todo el tramo;9':'todo el tramo; 9','sinmetadatos':'sin metadatos'}.items():t=t.replace(a,b)
f.write_text(t,encoding='utf-8')
for doc in [f,O/'Metodologia_Analisis.md']:
    txt=doc.read_text(encoding='utf-8');assert '\ufffd' not in txt
    for target in re.findall(r'!?\[[^\]]*\]\(([^)]+)\)',txt):
        if not target.startswith(('http://','https://','#')):assert (O/target).exists(),target
assert t.count('## Conclusión final: respuestas concretas')==1
conclusion=t.split('## Conclusión final: respuestas concretas')[1]
assert len(re.findall(r'^\d+\. ',conclusion,re.M))==10
assert len(list((O/'Graficos').glob('*.png')))==21
for image in (O/'Graficos').glob('*.png'):
    with Image.open(image) as im:assert im.width>=1000 and im.height>=500;im.verify()
for name,count in [('Optimizacion_Procesada',12960),('Pases_Redundantes',719),('Top_20_Candidatos',15),('Resumen_Parametros',26),('Candidatos_Todos_Periodos',60),('Incidencias_Calidad',72),('Discrepancias_ExpectedPayoff',46)]:
    assert len(pd.read_csv(O/(name+'.csv')))==count,(name,count)
audit=json.loads((O/'Auditoria_XML.json').read_text(encoding='utf-8'))
for m in audit:assert hashlib.sha256((O.parent/m['file']).read_bytes()).hexdigest()==m['sha256']
files=sorted([x for x in O.iterdir() if x.suffix in ['.md','.csv','.json','.py'] and x.name not in ['Manifest_Entregables.json']]+list((O/'Graficos').glob('*.png')))
manifest={'fecha':'2026-10-18','python':sys.version,'pandas':pd.__version__,'numpy':np.__version__,'files':[{'path':str(x.relative_to(O)).replace('\\','/'),'bytes':x.stat().st_size,'sha256':hashlib.sha256(x.read_bytes()).hexdigest()} for x in files],'checks':'Archivos originales intactos; filas, celdas fuente, candidatos, enlaces y PNG verificados.'}
(O/'Manifest_Entregables.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
files.append(O/'Manifest_Entregables.json')
zpath=O/'Entrega_Analisis_CandleMomentum_V1.2.zip'
with zipfile.ZipFile(zpath,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for p in files:z.write(p,arcname=str(p.relative_to(O)))
with zipfile.ZipFile(zpath) as z:assert z.testzip() is None
print(json.dumps({'status':'verificado','files':len(files),'png':21,'zip_bytes':zpath.stat().st_size,'report_bytes':f.stat().st_size},ensure_ascii=False))
