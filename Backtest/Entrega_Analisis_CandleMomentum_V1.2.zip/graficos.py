from pathlib import Path
import sys,os
O=Path(__file__).resolve().parent
sys.path.append(str(O/'.deps'))
os.environ['MPLCONFIGDIR']=str(O/'.mplconfig')
import numpy as np,pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import SymLogNorm,TwoSlopeNorm
from matplotlib.ticker import FuncFormatter
from PIL import Image,ImageOps,ImageDraw
G=O/'Graficos';G.mkdir(exist_ok=True)
D=pd.read_pickle(O/'datos.pkl');P=pd.read_csv(O/'Comparaciones_Vecinos.csv');S=pd.read_csv(O/'Top_20_Candidatos.csv');C=pd.read_pickle(O/'configuraciones.pkl')
TF=['M1','M3','M5','M15','M30','H1','H2','H4'];years=[2023,2024,2025,2026]
colors=['#3366a6','#d55e00','#009e73','#8b54a2']
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.titlesize':12,'axes.labelsize':10,'figure.facecolor':'white','axes.spines.top':False,'axes.spines.right':False,'savefig.dpi':150})
def save(fig,name,title,note):
    fig.suptitle(title,fontsize=16,y=.995,fontweight='bold')
    fig.text(.02,.01,note,fontsize=9,color='#424b54',va='bottom')
    fig.tight_layout(rect=[0,.055,1,.96]);fig.savefig(G/(name+'.png'),bbox_inches='tight');plt.close(fig)
def money(ax):ax.yaxis.set_major_formatter(FuncFormatter(lambda x,p:f'{x:,.0f}'))

fig,axs=plt.subplots(2,2,figsize=(13,8))
for ax,y,col in zip(axs.flat,years,colors):
    g=D[D.Year==y];ax.hist(g.Profit,bins=80,color=col,alpha=.85);ax.axvline(0,color='black',lw=1)
    ax.set(title=f'{y} | n={len(g):,} pases; mediana {g.Profit.median():,.0f} USD',xlabel='Profit (USD)',ylabel='Pases');ax.set_yscale('log');ax.grid(alpha=.18)
save(fig,'01_Distribucion_Profit','Beneficios de todos los pases, separados por período','Observado. Escala vertical logarítmica; sin recorte de pérdidas. 2026 termina el 17/10. Cada pase comparte datos con otros.')

fig,axs=plt.subplots(2,2,figsize=(13,9))
for ax,y in zip(axs.flat,years):
    g=D[D.Year==y]
    for ok,col,label in [(False,'#e09b5c','<50 trades'),(True,'#3366a6','≥50 trades')]:
        h=g[g.Trades.ge(50)==ok];ax.scatter(h.Trades,h.Profit,s=9,alpha=.35,color=col,label=f'{label}, n={len(h)}')
    ax.axhline(0,color='black',lw=.8);ax.set_xscale('symlog',linthresh=10);ax.set(title=str(y),xlabel='Trades (escala symlog)',ylabel='Profit (USD)');ax.legend(fontsize=8);money(ax)
save(fig,'02_Profit_Trades','Más operaciones no implicaron mayor rentabilidad','Todos los 12.960 pases observados. Colores distinguen suficiencia exploratoria; 50 trades no prueba significancia.')

fig,axs=plt.subplots(2,2,figsize=(13,9))
for ax,y in zip(axs.flat,years):
    g=D[(D.Year==y)&D.PF_interpretable]
    for ok,col,label in [(False,'#d55e00','<50 trades'),(True,'#3366a6','≥50 trades')]:
        h=g[g.Trades.ge(50)==ok];ax.scatter(h['Equity DD %'],h['Profit Factor'],s=10,alpha=.4,color=col,label=f'{label}: {len(h)}')
    ax.set_xscale('symlog',linthresh=1);ax.set_yscale('symlog',linthresh=1);ax.axhline(1,color='black',lw=.7);ax.axvline(20,color='gray',lw=.7,ls='--');ax.set(title=f'{y} | PF ausente: {3240-len(g)}',xlabel='Equity DD % (symlog)',ylabel='Profit Factor (symlog)');ax.legend(fontsize=8)
save(fig,'03_PF_Drawdown','PF alto con pocas operaciones: una señal frágil','Se muestran PF finitos con trades >0, incluidos PF=0. No se recortan valores extremos; falta desglose de pérdidas y costos.')

fig,axs=plt.subplots(2,2,figsize=(14,9))
for ax,y in zip(axs.flat,years):
    g=D[D.Year==y];a=g.groupby('TF').Profit.apply(lambda x:100*x.gt(0).mean()).reindex(TF);h=g[g.Trades>=50];b=h.groupby('TF').Profit.apply(lambda x:100*x.gt(0).mean()).reindex(TF);n=h.groupby('TF').size().reindex(TF)
    x=np.arange(8);ax.bar(x-.19,a,.38,label='Todos (405 por TF)',color='#9eabb9');ax.bar(x+.19,b,.38,label='Solo ≥50 trades',color='#3366a6')
    for xx,v,nn in zip(x,b,n):ax.text(xx+.19,v+.7,f'n={nn}',ha='center',va='bottom',fontsize=7,rotation=90)
    ax.set(xticks=x,xticklabels=TF,ylim=(0,60),ylabel='% de pases positivos',title=str(y));ax.legend(fontsize=8)
save(fig,'04_Rentables_Temporalidad','Frecuencia descriptiva de ganancias en la malla','Los denominadores de la serie azul se indican sobre cada barra. No son probabilidades de rentabilidad futura.')

fig,ax=plt.subplots(figsize=(12,6))
summ=pd.read_csv(O/'Resumen_Temporalidad.csv').set_index('TF').loc[TF]
ax.bar(TF,summ.Redundancia_pct,color='#77558f')
for i,r in enumerate(summ.itertuples()):ax.text(i,r.Redundancia_pct+.5,f'{int(r.Redundantes)}/{int(r.Pases)}',ha='center')
ax.set(ylabel='% redundancia = (pases − resultados distintos) / pases',ylim=(0,29));ax.grid(axis='y',alpha=.2)
save(fig,'05_Redundancia_Temporalidad','Redundancia: 584 dentro de TF; 585 en el total','584 excedentes dentro de TF + 1 al unir H2/H4 sin trades en 2026. 12.960 pases; 719 miembros de grupos. No prueba igualdad de operaciones.')

for metric,label,suffix in [('Profit','Profit mediano (USD)','Profit'),('PF_interpretable_value','PF mediano interpretable','PF'),('Equity DD %','Equity DD mediano (%)','DD'),('Trades','Trades medianos','Trades'),('Expected Payoff','Expected Payoff mediano (USD/trade)','Payoff')]:
    fig,axs=plt.subplots(2,4,figsize=(17,9))
    for ax,tf in zip(axs.flat,TF):
        for y,col in zip(years,colors):
            h=D[(D.TF==tf)&(D.Year==y)].groupby('InpMinRangeATR')[metric].median()
            ax.plot(h.index,h.values,'o-',ms=3,lw=1.4,color=col,label=str(y))
        if metric=='Profit' or metric=='Expected Payoff':ax.axhline(0,color='black',lw=.6)
        if metric=='PF_interpretable_value':ax.axhline(1,color='black',lw=.6)
        ax.set(title=tf,xlabel='Mínimo RangeATR',ylabel=label);ax.grid(alpha=.2);ax.legend(fontsize=7)
    save(fig,'06_ATR_'+suffix,'RangeATR: '+label,'Observado: 45 pases por punto (5 cuerpos × 9 RR), salvo PF ausentes. Escalas verticales por TF; no es un efecto causal ni un ajuste lineal.')

def heatgrid(other,filename):
    fig,axs=plt.subplots(2,4,figsize=(21,11))
    norm=SymLogNorm(linthresh=1000,vmin=-95000,vmax=95000)
    for ax,tf in zip(axs.flat,TF):
        h=D[D.TF==tf];agg=h.groupby([other,'InpMinRangeATR']).agg(Profit=('Profit','median'),Trades=('Trades','median'),N=('ID','size'))
        mat=agg.Profit.unstack();tr=agg.Trades.unstack();im=ax.imshow(mat,aspect='auto',origin='lower',cmap='RdBu',norm=norm)
        ax.set(title=tf,xticks=range(len(mat.columns)),xticklabels=[f'{x:g}' for x in mat.columns],yticks=range(len(mat.index)),yticklabels=mat.index,xlabel='RangeATR mínimo',ylabel='Cuerpo mínimo (%)' if other=='InpMinBodyPercent' else 'RR')
        for i in range(len(mat)):
            for j in range(len(mat.columns)):
                v=mat.iloc[i,j];ax.text(j,i,f'{v/1000:.1f}\n{tr.iloc[i,j]:.0f}t',ha='center',va='center',fontsize=6.5,color='white' if abs(v)>14000 else 'black')
        ax.tick_params(labelsize=8)
    cax=fig.add_axes([.905,.18,.013,.65]);cb=fig.colorbar(im,cax=cax);cb.set_label('Profit mediano USD (color symlog)')
    # Manual margins preserve shared colorbar.
    fig.suptitle('Interacción '+('cuerpo × ATR' if other=='InpMinBodyPercent' else 'RR × ATR')+' por temporalidad',fontsize=18,y=.99)
    fig.text(.02,.01,'Cada celda: Profit mediano en miles USD / trades medianos (t). 4 períodos agrupados; '+('36' if other=='InpMinBodyPercent' else '20')+' pases por celda. No prueba persistencia anual.',fontsize=10)
    fig.subplots_adjust(left=.05,bottom=.09,top=.93,right=.87,wspace=.34,hspace=.35);fig.savefig(G/(filename+'.png'),bbox_inches='tight');plt.close(fig)
heatgrid('InpMinBodyPercent','07_ATR_Cuerpo');heatgrid('InpRR','08_ATR_RR')

for other,filename in [('InpMinBodyPercent','07b_M30_Cuerpo_Por_Periodo'),('InpRR','08b_M30_RR_Por_Periodo')]:
    fig,axs=plt.subplots(2,2,figsize=(14,10));norm=TwoSlopeNorm(vmin=-10000,vcenter=0,vmax=3500)
    for ax,y in zip(axs.flat,years):
        h=D[(D.TF=='M30')&(D.Year==y)];agg=h.groupby([other,'InpMinRangeATR']).agg(Profit=('Profit','median'),Trades=('Trades','median'));mat=agg.Profit.unstack();tr=agg.Trades.unstack()
        im=ax.imshow(mat,aspect='auto',origin='lower',cmap='RdBu',norm=norm)
        ax.set(title=str(y),xticks=range(len(mat.columns)),xticklabels=mat.columns,yticks=range(len(mat.index)),yticklabels=mat.index,xlabel='RangeATR mínimo',ylabel='Cuerpo (%)' if other=='InpMinBodyPercent' else 'RR')
        for i in range(len(mat)):
            for j in range(len(mat.columns)):
                v=mat.iloc[i,j];ax.text(j,i,f'{v:.0f}\n{tr.iloc[i,j]:.0f}t',ha='center',va='center',fontsize=7,color='white' if v < -6000 or v>2200 else 'black')
    fig.suptitle('M30: cambia el período, cambia la región favorable',fontsize=16,y=.99)
    fig.text(.02,.01,'Celdas: beneficio mediano (USD) / trades medianos. '+('9 RR' if other=='InpMinBodyPercent' else '5 cuerpos')+' por celda. Color común; extremos saturados, valores completos escritos.',fontsize=10)
    fig.subplots_adjust(left=.07,right=.86,bottom=.09,top=.93,hspace=.35,wspace=.25);cb=fig.colorbar(im,ax=axs.ravel().tolist(),fraction=.03,pad=.04);cb.set_label('Profit mediano USD');fig.savefig(G/(filename+'.png'),bbox_inches='tight');plt.close(fig)

fig,ax=plt.subplots(figsize=(11,5));ax.axis('off')
ax.text(.02,.86,'Comparación ATR vs PIPS: no identificable',fontsize=20,weight='bold')
lines=['12.960 pases con InpMinRangeATR exportado y variado.','0 pases identificables como controles PIPS con ajustes fijos documentados.','0 pares controlados ATR–PIPS que puedan verificarse.','El efecto de ATR se observa al mantener año, TF, cuerpo y RR.','Falta InpRangeFilter: no se distingue ATR puro de PIPS_AND_ATR.']
for i,l in enumerate(lines):ax.text(.03,.66-i*.12,l,fontsize=13,color='#263849')
save(fig,'09_ATR_vs_PIPS_Limitacion','Disponibilidad de evidencia, no comparación de rendimientos','No se fabricaron resultados PIPS ni se atribuyeron los presets a estas optimizaciones.')

fig,axs=plt.subplots(1,3,figsize=(16,5))
for ax,p,label in zip(axs,['InpMinRangeATR','InpMinBodyPercent','InpRR'],['ATR +0,25','Cuerpo +5 puntos','RR +0,5']):
    h=P[P.Parametro==p]
    for ok,col,lab in [(True,'#3366a6','Ambos ≥50 trades'),(False,'#d55e00','Alguno <50')]:
        v=h.loc[h.Trades_min.ge(50)==ok,'Delta_Profit'];ax.hist(v,bins=65,alpha=.5,color=col,label=f'{lab}: {len(v)}')
    ax.set_yscale('log');ax.axvline(0,color='black',lw=.7);ax.set(title=label,xlabel='Profit siguiente − previo (USD)',ylabel='Pares (log)');ax.legend(fontsize=8)
save(fig,'10_Diferencias_Vecinos','Diferencias emparejadas entre parámetros vecinos','Se conserva año, TF y todos los otros parámetros exportados. El número de pares no equivale a observaciones independientes.')

fig,axs=plt.subplots(1,2,figsize=(14,6))
for ax in axs:ax.grid(alpha=.2)
for _,r in S.iterrows():
    col='#3366a6' if r.Clase.startswith('A') else '#d55e00';size=25+min(r.Trades_min_4periodos,300)*.45
    offset=[(7,10),(7,-13),(-24,10),(-24,-13)][int(r.Candidato[1:])%4]
    off0={'C10':(-42,-5),'C14':(-35,22),'C04':(12,7)}.get(r.Candidato,offset)
    off1={'C04':(14,3),'C05':(-24,-20),'C14':(-25,24),'C15':(15,-25),'C10':(0,28),'C11':(16,-12)}.get(r.Candidato,offset)
    axs[0].scatter(r.Profit_min_4periodos,r.PF_min_4periodos,s=size,color=col,alpha=.75);axs[0].annotate(r.Candidato,(r.Profit_min_4periodos,r.PF_min_4periodos),xytext=off0,textcoords='offset points',fontsize=8,arrowprops={'arrowstyle':'-','color':'gray','lw':.5})
    axs[1].scatter(r.Trades_min_4periodos,r.DD_max_4periodos,s=size,color=col,alpha=.75);axs[1].annotate(r.Candidato,(r.Trades_min_4periodos,r.DD_max_4periodos),xytext=off1,textcoords='offset points',fontsize=8,arrowprops={'arrowstyle':'-','color':'gray','lw':.5})
axs[0].axhline(1,color='gray',ls='--');axs[0].axvline(0,color='gray',ls='--');axs[0].set(xlabel='Peor Profit entre 4 períodos (USD)',ylabel='Peor PF entre 4 períodos')
axs[1].set(xlabel='Mínimo trades entre períodos',ylabel='Mayor DD entre períodos (%)')
axs[1].set_ylim(bottom=0)
save(fig,'11_Mapa_Candidatos','Candidatos para investigar: todos fallan en algún período','Azul: 3 períodos positivos. Naranja: controles locales (1–2 positivos). Tamaño aumenta con trades mínimos; no son carteras validadas.')

fig,axs=plt.subplots(1,2,figsize=(14,6));bins=[0,50,100,200,500,20000];labels=['0–49','50–99','100–199','200–499','≥500']
D['SampleBin']=pd.cut(D.Trades,bins=bins,right=False,labels=labels)
groups=[D[D.SampleBin==s] for s in labels]
axs[0].boxplot([g.NeighborAbsDeltaProfitMedian for g in groups],tick_labels=[f'{s}\nn={len(g)}' for s,g in zip(labels,groups)],showfliers=False)
axs[0].set_yscale('symlog',linthresh=100);axs[0].set(xlabel='Trades del pase central',ylabel='Mediana |ΔProfit| a sus vecinos (USD)',title='Menor exposición puede parecer estabilidad')
for good,col,label in [(False,'#9eabb9','Todos'),(True,'#3366a6','Solo centros favorables')]:
    vals=[g.loc[g.Favorable50 if good else np.ones(len(g),dtype=bool),'NeighborFavorable50Pct'].median() for g in groups]
    axs[1].plot(labels,vals,'o-',color=col,label=label)
axs[1].set(xlabel='Trades del pase central',ylabel='Mediana % vecinos favorables',ylim=(-3,103));axs[1].legend(fontsize=9)
save(fig,'12_Muestra_Estabilidad','Estabilidad aparente y tamaño de la muestra','Vecinos axiales en cuerpo, ATR y RR, mismo TF/año. Izquierda: cajas 25–75%, bigotes 1,5 IQR, atípicos omitidos solo aquí. Sin inferencia estadística.')

fig,ax=plt.subplots(figsize=(10,8));mat=S.set_index('Candidato')[[str(y)+'_Profit' for y in years]];im=ax.imshow(mat,cmap='RdBu',norm=TwoSlopeNorm(vmin=-11000,vcenter=0,vmax=4000),aspect='auto')
ax.set(xticks=range(4),xticklabels=years,yticks=range(len(S)),yticklabels=[r.Candidato+' · '+r.TF+' · pase '+str(r.Pase) for r in S.itertuples()])
for i,r in enumerate(S.itertuples()):
    for j,y in enumerate(years):
        v=S.iloc[i][str(y)+'_Profit'];n=S.iloc[i][str(y)+'_Trades'];ax.text(j,i,f'{v:,.0f} USD | {n:.0f}t',ha='center',va='center',fontsize=9,color='white' if v<-7000 or v>2500 else 'black')
fig.colorbar(im,ax=ax,label='Profit USD')
save(fig,'13_Candidatos_Periodos','El período favorable no representa toda la evidencia','Misma configuración exportada en cuatro períodos. 2026 parcial. No se suman beneficios, PF ni DD para fabricar una curva conjunta.')

fig,axs=plt.subplots(2,4,figsize=(17,9))
for ax,tf in zip(axs.flat,TF):
    for y,col in zip(years,colors):
        h=D[(D.TF==tf)&(D.Year==y)].groupby('InpMinBodyPercent').agg(P=('Profit','median'),N=('Trades','median'))
        ax.plot(h.index,h.P,'o-',label=str(y),color=col,ms=3)
    ax.axhline(0,color='black',lw=.6);ax.set(title=tf,xlabel='Cuerpo mínimo (%)',ylabel='Profit mediano USD');ax.legend(fontsize=7);ax.grid(alpha=.2)
save(fig,'14_Cuerpo_Profit','Subir el cuerpo reduce exposición; no asegura ventaja','81 pases por punto (9 ATR × 9 RR). Ver Trades y efectos emparejados en las tablas; las curvas incluyen todas las muestras.')

fig,axs=plt.subplots(2,4,figsize=(17,9))
for ax,tf in zip(axs.flat,TF):
    for y,col in zip(years,colors):
        h=D[(D.TF==tf)&(D.Year==y)].groupby('InpRR').Profit.median();ax.plot(h.index,h,'o-',label=str(y),color=col,ms=3)
    ax.axhline(0,color='black',lw=.6);ax.set(title=tf,xlabel='RR solicitado',ylabel='Profit mediano USD');ax.legend(fontsize=7);ax.grid(alpha=.2)
save(fig,'15_RR_Profit','RR: efectos observados por año y temporalidad','45 pases por punto (5 cuerpos × 9 ATR). El XML no permite reconstruir aciertos ni ganadores que expliquen el resultado.')

# Hoja de contacto solo para QA; no reemplaza inspección individual de mapas densos.
files=sorted(G.glob('*.png'));w=480;h=300;contact=Image.new('RGB',(w*4,h*((len(files)+3)//4)),'white');draw=ImageDraw.Draw(contact)
for i,f in enumerate(files):
    im=Image.open(f);im.thumbnail((w-12,h-28));x=i%4*w;y=i//4*h;contact.paste(im,(x+(w-im.width)//2,y+25));draw.text((x+8,y+5),f.stem,fill='black')
contact.save(O/'QA_Graficos.png')
print('PNG',len(files))
