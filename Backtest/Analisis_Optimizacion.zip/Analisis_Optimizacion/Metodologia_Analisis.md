# Metodología Cuantitativa de Análisis de Optimización MT5
## `CandleMomentumATR_EA` — EURUSD (`ReportOptimizer-ATR.xml`)

---

## 1. Procesamiento del Archivo XML (SpreadsheetML)

El archivo de origen (`g:\Candle Behavior Research\Backtest\ReportOptimizer-ATR.xml`) utiliza el estándar **Microsoft Office SpreadsheetML** con el espacio de nombres principal `urn:schemas-microsoft-com:office:spreadsheet` (`ss:`), complementado por `urn:schemas-microsoft-com:office:office` (`o:`), `urn:schemas-microsoft-com:office:excel` (`x:`) y `http://www.w3.org/TR/REC-html40` (`html:`).

El análisis se ejecutó mediante un parser estructurado (`xml.etree.ElementTree`) respetando:
1. **Metadatos del nodo `<o:DocumentProperties>`:** extracción de `Title`, `Server`, `Deposit`, `Leverage`, `Created`, `Version`, `Build` y `Condition`.
2. **Hoja `<ss:Worksheet ss:Name="Tester Optimizator Results">`:** lectura de la tabla `<ss:Table>` con validación explícita del atributo `ss:Index` (en caso de celdas dispersas) y tipado fuerte según `ss:Type="Number"` o `ss:Type="String"`.
3. **Integridad:** preservación inalterada del archivo XML original y del identificador `Pass` asignado por MetaTrader 5 a cada combinación de parámetros.

---

## 2. Reconstrucción de la Grilla Exhaustiva y Detección de Truncamiento (*Skip Useless Results*)

En el modo de **Optimización Lenta (Algoritmo Completo / Exhaustivo)** de MetaTrader 5, cada combinación del producto cartesiano de parámetros activos recibe un índice entero secuencial `Pass` determinado por el orden de declaración de las variables `input` optimizadas:

$$\text{Pass}(i_{\text{TF}}, i_{\text{Cuerpo}}, i_{\text{ATR}}, i_{\text{RR}}) = i_{\text{TF}} + N_{\text{TF}} \cdot \Big( i_{\text{Cuerpo}} + N_{\text{Cuerpo}} \cdot \big( i_{\text{ATR}} + N_{\text{ATR}} \cdot i_{\text{RR}} \big) \Big)$$

Donde los dominios discretos de la grilla son:
- $i_{\text{TF}} \in \{0, 1, 2, 3, 4, 5, 6, 7\} \implies N_{\text{TF}} = 8$ (`M1, M3, M5, M15, M30, H1, H2, H4`, verificado en `enum ENUM_TF_ESTRATEGIA` de `CandleMomentumATR_EA.mq5`).
- $i_{\text{Cuerpo}} \in \{0, 1, 2, 3, 4\} \leftrightarrow \{80, 85, 90, 95, 100\} \implies N_{\text{Cuerpo}} = 5$.
- $i_{\text{ATR}} \in \{0, 1, \dots, 8\} \leftrightarrow \{0.50, 0.75, 1.00, 1.25, 1.50, 1.75, 2.00, 2.25, 2.50\} \implies N_{\text{ATR}} = 9$.
- $i_{\text{RR}} \in \{0, 1, \dots, 8\} \leftrightarrow \{1.0, 1.5, 2.0, 2.5, 3.0, 3.5, 4.0, 4.5, 5.0\} \implies N_{\text{RR}} = 9$.

Sustituyendo las cardinalidades:

$$\text{Pass} = i_{\text{TF}} + 8 \cdot i_{\text{Cuerpo}} + 40 \cdot i_{\text{ATR}} + 360 \cdot i_{\text{RR}}, \qquad N_{\text{Total Grilla}} = 8 \times 5 \times 9 \times 9 = 3{,}240 \text{ pases } (\text{Pass } 0 \dots 3239)$$

### Verificación Matemática de Exhaustividad y Truncamiento de Exportación
1. **Identidad exacta del índice:** el $100\%$ de las $731$ filas exportadas en `ReportOptimizer-ATR.xml` cumple sin excepción la ecuación diofántica anterior.
2. **Cobertura completa de los 81 bloques de la grilla:** al dividir $\lfloor \text{Pass} / 40 \rfloor \in \{0, \dots, 80\}$ (los $9 \times 9 = 81$ bloques de pares `InpMultiplicadorATR` $\times$ `InpRR`), los **81 bloques** están representados en el XML.
3. **Ausencia de huecos en intervalos constantes:** en todos los intervalos de parámetros donde dos o más valores adyacentes de `InpMultiplicadorATR` producen el mismo resultado rentable, no falta ningún paso intermedio ($0$ huecos).
4. **Filtro de exportación (`Skip Useless Results`):** dado que las $731$ filas exportadas tienen `Profit > 0` ($\min(\text{Profit}) = \$0.63$) y están ordenadas de forma estrictamente decreciente por `Profit`, queda demostrado que la optimización evaluó los **3,240 pases** del algoritmo completo, pero se exportó con la opción nativa de MT5 **"Omitir resultados inútiles" (*Skip Useless Results*)** activa, la cual oculta y excluye de la exportación los $3{,}240 - 731 = 2{,}509$ pases con $\text{Profit} \le 0$ ($77.44\%$ del espacio total).

Por rigor estadístico, todas las tasas de rentabilidad se reportan bajo **doble denominador**:
- **Denominador XML observacional ($n = 731$):** proporción respecto a los pases rentables exportados.
- **Denominador de Grilla Exhaustiva ($N = 3{,}240$, o $405$ pases por temporalidad):** proporción real respecto al espacio completo evaluado, evitando el sesgo de supervivencia (*survivorship bias*).

---

## 3. Definición Matemática de las Métricas y Derivaciones Algebraicas

### 3.1 Métricas Exportadas por MetaTrader 5
- **`Pass`:** identificador único del pase dentro de la grilla de optimización ($0 \dots 3239$).
- **`Profit` ($P_{\text{net}}$):** beneficio monetario neto al cierre del período en la divisa de la cuenta ($\text{USD}$), sobre un depósito inicial $B_0 = \$100{,}000$:
  $$P_{\text{net}} = \text{Gross Profit} - \text{Gross Loss}$$
- **`Expected Payoff` ($EP$):** esperanza matemática muestral por operación en $\text{USD}$:
  $$EP = \frac{P_{\text{net}}}{N_{\text{trades}}}$$
- **`Profit Factor` ($PF$):** razón entre ganancias brutas acumuladas y pérdidas brutas acumuladas:
  $$PF = \frac{\text{Gross Profit}}{\text{Gross Loss}}$$
  *(Nota: cuando $\text{Gross Loss} = 0$, o cuando $N_{\text{trades}}$ es muy reducido, $PF$ carece de estabilidad estadística).*
- **`Equity DD %` ($DD_{\%}$):** caída máxima relativa del patrimonio (*equity*) desde un máximo local hasta un mínimo subsecuente, expresada en porcentaje.
- **`Recovery Factor` ($RF$):** razón entre el beneficio neto total y el drawdown máximo monetario en equidad ($\text{MaxDD}_{\text{USD}}$):
  $$RF = \frac{P_{\text{net}}}{\text{MaxDD}_{\text{USD}}}$$
- **`Sharpe Ratio` ($SR$):** razón de retorno ajustado por volatilidad de los cambios en la curva de equidad calculada internamente por MT5.
- **`Result`:** valor del criterio de optimización seleccionado en el Strategy Tester. En este XML toma valores en $[0.02, 80.64]$ y corresponde al **Criterio Complejo Máx. (*Complex Criterion max*)** nativo de MetaTrader 5 (escala $0$ a $100$ que pondera cantidad de operaciones, drawdown, factor de recuperación, esperanza matemática, factor de beneficio y ratio de Sharpe, penalizando severamente pases con pocas operaciones). Su fórmula cerrada exacta es interna y propietaria de MetaQuotes, por lo que no se emplea como beneficio monetario ni como único criterio de selección.
- **`Custom`:** valor devuelto por `OnTester()`. Vale `0` en los $731$ pases porque `CandleMomentumATR_EA.mq5` opera exclusivamente en `MODE_TRADING` y no define función `OnTester()`.

### 3.2 Derivación Algebraica Exacta de Ganancia Bruta y Pérdida Bruta
Para cualquier pase con $P_{\text{net}} > 0$ y $PF > 1$ (condición que cumplen los $731$ pases exportados), el sistema lineal:

$$\begin{cases} \text{Gross Profit} - \text{Gross Loss} = P_{\text{net}} \\ \dfrac{\text{Gross Profit}}{\text{Gross Loss}} = PF \end{cases}$$

tiene solución única exacta:

$$\text{Gross Loss} = \frac{P_{\text{net}}}{PF - 1}, \qquad \text{Gross Profit} = \frac{P_{\text{net}} \cdot PF}{PF - 1}$$

### 3.3 Imposibilidad de Derivar el Win Rate Real y Benchmark de Equilibrio Teórico
Aunque $\text{Gross Profit}$ y $\text{Gross Loss}$ son recuperables algebraicamente, el **Win Rate muestral ($W = N_{\text{win}} / N_{\text{trades}}$) NO puede determinarse con exactitud** a partir del XML porque:
1. El EA dimensiona cada lote arriesgando el $1.0\%$ del balance actual (`InpRiesgoPorcentaje = 1.0`), lo que introduce interés compuesto operación tras operación.
2. El redondeo al paso de lote (`SYMBOL_VOLUME_STEP`), los costos de spread y posibles cierres al final del backtest hacen que el riesgo monetario efectivo por operación no sea idéntico en todos los trades.

En consecuencia, **no se inventan ni estiman tasas de acierto muestrales**. Únicamente se reporta, como propiedad matemática intrínseca del parámetro `InpRR`, la **tasa de acierto de equilibrio teórico sin costos ($W_{\text{BE}}$)**:

$$W_{\text{BE}}(\text{RR}) = \frac{1}{1 + \text{RR}}$$

---

## 4. Metodología de Detección de Redundancias

Se distinguen conceptualmente dos niveles de redundancia:
1. **Duplicación de métricas (observable en el XML):** dos pases $p_i \neq p_j$ presentan idéntico vector de $8$ resultados numéricos:
   $$\mathbf{m}(p_i) = \mathbf{m}(p_j), \quad \mathbf{m} = (\text{Result}, \text{Profit}, \text{Expected Payoff}, \text{Profit Factor}, \text{Recovery Factor}, \text{Sharpe Ratio}, \text{Equity DD \%}, \text{Trades})$$
2. **Duplicación de operaciones (requiere historial de órdenes o telemetría):** dos configuraciones abren y cierran exactamente los mismos tickets en los mismos precios y marcas de tiempo. Aunque la coincidencia exacta en las $8$ métricas continuas (con $4$ a $6$ decimales) al variar únicamente el umbral de rango es un indicador fuertemente sugestivo de que el filtro seleccionó el mismo subconjunto de velas, la demostración formal de igualdad de operaciones requiere el registro de transacciones individuales.

### Fórmulas de Conteo de Redundancia
Para un conjunto o subconjunto de $M$ pases que contiene $D$ vectores de métricas distintos:
- **Pases redundantes (copias excedentes):** $R_{\text{exceso}} = M - D$.
- **Porcentaje de redundancia:** $\%R = \frac{M - D}{M} \times 100$.
- **Pases en clústeres duplicados:** cantidad total de pases cuya multiplicidad en $\mathbf{m}$ es $\ge 2$.

Para aislar qué parámetro genera redundancia, se particiona el conjunto manteniendo fijos $3$ parámetros y variando únicamente el cuarto parámetro estudiado.

---

## 5. Métricas de Estabilidad Vecina y Robustez Topológica

Cada configuración pertenece a una celda $(i_{\text{Cuerpo}}, i_{\text{ATR}}, i_{\text{RR}})$ dentro de la subgrilla tridimensional de su temporalidad $i_{\text{TF}}$ ($5 \times 9 \times 9 = 405$ celdas). Se definen dos vecindades locales dentro de la misma temporalidad:

1. **Vecindad Ortogonal de 1 Paso (Distancia Manhattan $L_1 = 1$):**
   $$\mathcal{N}_1(c, a, r) = \{(c \pm 1, a, r), (c, a \pm 1, r), (c, a, r \pm 1)\} \cap \mathcal{G}$$
   Consta de entre $3$ (en una esquina de la grilla) y $6$ (en el interior) configuraciones vecinas que difieren en exactamente un incremento elemental ($\pm 5\%$ de cuerpo, $\pm 0.25\text{ ATR}$ o $\pm 0.5\text{ RR}$).
   - **Tasa de Supervivencia Ortogonal (`Pct_Vecinos_Orto_Rentables`):**
     $$S_1 = \frac{|\{q \in \mathcal{N}_1 : \text{Profit}(q) > 0\}|}{|\mathcal{N}_1|} \times 100$$
   - **Mediana Vecina de Profit Factor (`Mediana_PF_Vecinos_Orto`):** mediana de $PF$ entre los vecinos ortogonales rentables.

2. **Vecindad Cúbica $3 \times 3 \times 3$ (Distancia de Chebyshev $L_\infty = 1$):**
   $$\mathcal{N}_\infty(c, a, r) = \{(c + \delta_c, a + \delta_a, r + \delta_r) : \delta_c, \delta_a, \delta_r \in \{-1, 0, 1\}, (\delta_c, \delta_a, \delta_r) \neq (0,0,0)\} \cap \mathcal{G}$$
   Consta de hasta $26$ vecinos inmediatos (incluyendo variaciones simultáneas diagonales en 2 y 3 parámetros).
   - **Tasa de Supervivencia Cúbica (`Pct_Vecinos_Cubo_Rentables`):**
     $$S_\infty = \frac{|\{q \in \mathcal{N}_\infty : \text{Profit}(q) > 0\}|}{|\mathcal{N}_\infty|} \times 100$$

---

## 6. Criterios de Filtrado y Selección de las 20 Configuraciones Candidatas

Para evitar el sobreajuste por selección del máximo muestral (*winner's curse*):
1. **Filtro de Tamaño Muestral Mínimo:** se exige $N_{\text{trades}} \ge 50$ como filtro exploratorio base, complementado con análisis de sensibilidad para $N_{\text{trades}} \ge 100$ y $N_{\text{trades}} \ge 200$. Se descartan todos los pases con $N_{\text{trades}} < 50$ (lo cual elimina automáticamente el $100\%$ de los Profit Factors artificiales $> 2.20$ y el $100\%$ de los pases redundantes del XML).
2. **Filtro de Calidad y Riesgo:** se exige $PF \ge 1.15$ (o $PF \ge 1.15$ en muestras $> 200$ trades), $\text{Expected Payoff} > 0$ y $\text{Equity DD \%} \le 4.0\%$.
3. **Filtro de Estabilidad Topológica:** se exige $S_1 (\text{Vecinos Ortogonales Rentables}) \ge 80\%$ (con preferencia por mesetas con $S_1 = 100\%$ y $S_\infty \ge 60\%$), descartando picos aislados ($S_1 \le 25\%$).
4. **Diversificación Estructural y Cero Redundancia:** las $20$ configuraciones candidatas seleccionadas representan **6 temporalidades distintas (`H4, H1, M30, M15, M5, M3`)**, los **5 niveles de porcentaje de cuerpo (`80%` a `100%`)**, distintos regímenes de `InpMultiplicadorATR` (`0.50` a `2.50`) y `InpRR` (`1.5` a `5.0`), con **0% de duplicación de métricas** entre ellas.

---

## 7. Limitaciones Estructurales de los Datos de Origen

1. **Truncamiento inferior del XML (`Profit > 0`):** al haberse exportado con *Skip Useless Results*, no se observa la magnitud exacta de la pérdida ni el número exacto de operaciones en los $2{,}509$ pases no rentables (solo sabemos con certeza matemática que obtuvieron $\text{Profit} \le 0$).
2. **Ausencia de desglose transaccional por operación:** el XML de resumen del optimizador no contiene la serie temporal de operaciones individuales, porcentaje de aciertos (*win rate*), excursión máxima favorable/adversa (MFE/MAE), duración de cada operación, ni la distribución mensual o trimestral de los retornos dentro del período `2026.01.01 - 2026.10.17`.
3. **Dependencia estadística entre pases:** los pases evaluados sobre el mismo par (`EURUSD`) y ventana histórica comparten las mismas realizaciones de mercado y gran parte de las velas gatillo, por lo que no constituyen ensayos estadísticamente independientes.
