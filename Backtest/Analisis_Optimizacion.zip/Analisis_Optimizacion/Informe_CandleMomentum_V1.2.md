# Informe de Análisis Cuantitativo de Optimización MT5
## `CandleMomentumATR_EA` (V1.2 / Filtro Relativo al ATR) — EURUSD (`2026.01.01` – `2026.10.17`)

---

## 1. Resumen Ejecutivo

### Hechos Comprobados
1. **Archivo analizado:** `g:\Candle Behavior Research\Backtest\ReportOptimizer-ATR.xml` ($11{,}752$ líneas, $613{,}181$ bytes, formato Microsoft Office SpreadsheetML), correspondiente a la optimización de `CandleMomentumATR_EA` sobre `EURUSD` en la ventana `2026.01.01 - 2026.10.17` (`FivePercentOnline-Real`, depósito inicial $\$100{,}000\text{ USD}$, apalancamiento $1:100$).
2. **Pases exportados:** el XML contiene exactamente **731 pases** (`Pass` mínimo $28$, máximo $3233$), todos con beneficio neto positivo ($\text{Profit} \in [\$0.63, \$4{,}658.96]$) y sin valores nulos ni errores de formato.
3. **Redundancia drásticamente reducida:** de los $731$ pases exportados, **689 ($94.25\%$) presentan resultados numéricos distintos** y solamente **42 pases ($5.75\%$)** son copias redundantes (agrupadas en $33$ clústeres de métricas idénticas, que involucran en total a $75$ pases). En todas las configuraciones con $\ge 9$ operaciones ($556$ pases) y con $\ge 50$ operaciones ($314$ pases), la redundancia del filtro ATR es exactamente **0.00% ($0$ pases redundantes)**.

### Cálculos Derivados
1. **Demostración de optimización exhaustiva de 3,240 pases con truncamiento de exportación (*Skip Useless Results*):** el $100\%$ de los $731$ pases cumple de forma exacta la ecuación de indexación lineal del algoritmo exhaustivo (*Slow complete algorithm*) de MetaTrader 5:
   $$\text{Pass} = i_{\text{TF}} + 8 \cdot i_{\text{Cuerpo}} + 40 \cdot i_{\text{ATR}} + 360 \cdot i_{\text{RR}}$$
   sobre una grilla cartesiana de $8\text{ temporalidades} \times 5\text{ niveles de cuerpo} \times 9\text{ múltiplos ATR} \times 9\text{ ratios RR} = 3{,}240\text{ pases}$ ($\text{Pass } 0 \dots 3239$), con presencia verificada en los $81/81$ bloques de $40$ pases. El archivo fue exportado con la opción nativa de MT5 **"Skip Useless Results" (*Omitir resultados inútiles*, $\text{Profit} \le 0$)** activa, lo que excluyó de la exportación los **$2{,}509$ pases ($77.44\%$)** con beneficio negativo o nulo (incluidos los $405/405$ pases de `M1`).
2. **Comparación controlada contra el filtro fijo en Pips (`ReportOptimizer-26672367.xml`):** manteniendo constantes los parámetros comunes ($\text{Cuerpo} \in \{80\%, 90\%, 100\%\}$ y $\text{RR} \in \{1, 2, 3, 4, 5\}$), la redundancia en pases rentables cae del **53.57% en PIPS** al **8.61% en ATR** (y del **34.62% en PIPS** al **0.00% en ATR** para $\text{Trades} \ge 50$). En `H4`, la redundancia cae del **85.96% en PIPS** al **0.00% en ATR**.

### Interpretaciones y Conclusiones Clave
- El filtro `InpMultiplicadorATR` resuelve el problema estructural de insensibilidad que sufría `InpRangoMin_Pips`: adapta automáticamente la exigencia de rango a la volatilidad propia de cada temporalidad.
- Existe una **relación inversa estructural entre la temporalidad y el múltiplo de ATR requerido** para superar los costos transaccionales y el ruido microestructural:
  - En temporalidades bajas (`M3`, `M5`, `M15`), solo las **expansiones extremas de volatilidad ($\text{ATR} \in [1.75, 2.50]$ y $\text{Cuerpo} \in [85\%, 95\%]$)** generan esperanza matemática positiva con muestra suficiente.
  - En temporalidades altas (`H1`, `H4`), la señal funciona como confirmación de impulso direccional con **umbrales moderados ($\text{ATR} \in [0.50, 1.25]$ y $\text{Cuerpo} \in [80\%, 90\%]$)**, mientras que exigir $\ge 1.50\text{ ATR}$ en `H4` reduce la frecuencia muestral por debajo de $50$ operaciones en $9.5$ meses.

---

## 2. Validación e Inspección del Archivo XML

### 2.1 Estructura XML, Namespaces y Metadatos
- **Hecho comprobado:** el archivo `ReportOptimizer-ATR.xml` es un documento válido **SpreadsheetML de Microsoft Excel** (`<?mso-application progid="Excel.Sheet"?>`), con nodo raíz `<Workbook>` y cinco espacios de nombres declarados:
  - `xmlns="urn:schemas-microsoft-com:office:spreadsheet"` (default y `ss:`)
  - `xmlns:o="urn:schemas-microsoft-com:office:office"`
  - `xmlns:x="urn:schemas-microsoft-com:office:excel"`
  - `xmlns:html="http://www.w3.org/TR/REC-html40"`
- **Hoja de cálculo:** contiene una única hoja `<Worksheet ss:Name="Tester Optimizator Results">` con una tabla `<Table>` de **732 elementos `<Row>`**: $1$ fila de encabezados (líneas $37$–$52$) y **731 filas de datos** (líneas $53$–$11{,}748$).

| Propiedad XML (`<DocumentProperties>`) | Valor Exacto en el Archivo | Interpretación Técnica |
|---|---|---|
| `Title` | `CandleMomentumATR_EA EURUSD,M5 2026.01.01-2026.10.17` | EA, símbolo `EURUSD`, TF base del tester (`M5`) y período histórico ($9.5$ meses) |
| `Author` / `Company` | `MetaQuotes Ltd.` | Generador nativo del Strategy Tester de MT5 |
| `Created` | `2026-10-17T15:16:03Z` | Fecha y hora de exportación del reporte |
| `Version` / `Build` | `500` / `64` | MetaTrader 5 (arquitectura 64 bits) |
| `Server` | `FivePercentOnline-Real` | Servidor de cotizaciones y condiciones operativas (spread/ejecución) |
| `Deposit` | `100000 USD` | Capital inicial de simulación ($B_0 = \$100{,}000$) |
| `Leverage` | `100` | Apalancamiento de la cuenta ($1:100$) |
| `Condition` | `0` | Código interno de condición del optimizador |

### 2.2 Columnas Exportadas e Integridad de Datos
El XML exporta exactamente **14 columnas** ($10$ métricas/identificadores del tester y $4$ parámetros de entrada del EA):
1. Métricas e identificadores: `Pass`, `Result`, `Profit`, `Expected Payoff`, `Profit Factor`, `Recovery Factor`, `Sharpe Ratio`, `Custom`, `Equity DD %`, `Trades`.
2. Parámetros optimizados: `InpTimeframe`, `InpPorcentajeCuerpo`, `InpMultiplicadorATR`, `InpRR`.
3. **Detección de valores faltantes o inválidos:** **0 celdas vacías, 0 `NaN` y 0 valores infinitos** en las $731 \times 14 = 10{,}234$ celdas de datos de `ReportOptimizer-ATR.xml`. (En contraste, el archivo previo de pips `ReportOptimizer-26672367.xml` presenta $98$ valores faltantes en `Profit Factor` correspondientes a $98$ pases con `Trades = 0` que en el XML de ATR fueron filtrados al exportar con *Skip Useless Results*).

### 2.3 Modo de Operación (`MODE_TRADING` vs `MODE_RESEARCH`) y Tipo de Optimización
- **Hecho comprobado (`MODE_TRADING`):** la columna `Custom` vale `0` en los $731$ pases y las columnas comerciales (`Profit`, `Profit Factor`, `Equity DD %`, `Trades`) contienen resultados monetarios completos. La inspección del código fuente `CandleMomentumATR_EA.mq5` confirma que el EA opera exclusivamente en **modo comercial (`MODE_TRADING`)** ejecutando órdenes a mercado mediante `g_trade.Buy(...)` y `g_trade.Sell(...)`, sin modo de investigación (`MODE_RESEARCH`) ni función `OnTester()`.
- **Cálculo derivado (Optimización Exhaustiva con Exportación Truncada en $\text{Profit} > 0$):**
  - Los $731$ pases exportados satisfacen al $100\%$ la biyección de enumeración exhaustiva de MT5:
    $$\text{Pass} = i_{\text{TF}} + 8 \cdot i_{\text{Cuerpo}} + 40 \cdot i_{\text{ATR}} + 360 \cdot i_{\text{RR}}$$
  - En el algoritmo genético de MT5 los números de pase se asignan por generación/individuo y presentan huecos aleatorios en regiones de resultados idénticos; aquí existen **0 huecos** en todos los bloques redundantes y están presentes los **81 bloques** ($\lfloor \text{Pass}/40 \rfloor \in [0, 80]$).
  - Por tanto, existe evidencia matemática concluyente de que se ejecutó una **optimización exhaustiva (*Slow complete algorithm*) de 3,240 pases**, exportada desde la tabla de MT5 con el filtro **"Skip Useless Results"** activo (que omitió los $2{,}509$ pases con $\text{Profit} \le 0$).

---

## 3. Comprensión y Verificación de los Parámetros del EA

Cruzando el archivo `ReportOptimizer-ATR.xml` con el código fuente `CandleMomentumATR_EA.mq5` (y comparándolo con `CandleMomentumRR_EA.mq5` y `OneMinuteCandle_EA.mq5`), se establece el estado exacto de cada parámetro mencionado en la especificación:

| Parámetro Conceptual | Nombre en Código / XML | Estado en `ReportOptimizer-ATR.xml` | Valores / Rango Verificado | Observaciones Técnicas |
|---|---|---|---|---|
| Temporalidad de señal | `InpTimeframe` | **Optimizado y exportado** | `1..7` en XML (`M3` a `H4`); `0..7` (`M1` a `H4`) en grilla de $3{,}240$ pases | `0=M1, 1=M3, 2=M5, 3=M15, 4=M30, 5=H1, 6=H2, 7=H4`. `M1` ($i_{\text{TF}}=0$) tuvo $0/405$ pases con $\text{Profit}>0$. |
| % mínimo de cuerpo | `InpPorcentajeCuerpo` | **Optimizado y exportado** | `80, 85, 90, 95, 100` ($5$ niveles, paso $5\%$) | Exige $\frac{|\text{Close}-\text{Open}|}{\text{High}-\text{Low}}\times 100 \ge \text{InpPorcentajeCuerpo}$. |
| Rango mínimo relativo al ATR | `InpMultiplicadorATR` *(referido como `InpMinRangeATR`)* | **Optimizado y exportado** | `0.50, 0.75, 1.00, 1.25, 1.50, 1.75, 2.00, 2.25, 2.50` ($9$ niveles, paso $0.25$) | Exige $(\text{High}-\text{Low}) \ge \text{InpMultiplicadorATR} \times \text{ATR}_1$. |
| Ratio Riesgo/Beneficio | `InpRR` | **Optimizado y exportado** | `1.0, 1.5, 2.0, 2.5, 3.0, 3.5, 4.0, 4.5, 5.0` ($9$ niveles, paso $0.5$) | Define $\text{TP} = \text{Entrada} \pm \text{InpRR} \times |\text{Entrada}-\text{SL}|$. |
| Período ATR | `InpPeriodoATR` | **Fijo (no optimizado)** | Valor por defecto en `.mq5`: `14` *(no exportado en XML)* | Al no optimizarse, MT5 no incluye su columna en el XML. |
| Riesgo monetario por operación | `InpRiesgoPorcentaje` | **Fijo (no optimizado)** | Valor por defecto en `.mq5`: `1.0` ($1\%$ del balance) | Consistente con las pérdidas medias por operación ($\sim \$1{,}000 = 1\%$ de $\$100{,}000$) observadas en el XML. |
| Filtro de spread | `InpSpreadMax_Pips` | **Fijo (no optimizado)** | Valor por defecto en `.mq5`: `1.0` pip | Activo en `OnTick()`: bloquea entradas si $(\text{Ask}-\text{Bid}) > 1.0\text{ pip}$. |
| Rango mínimo en pips | `InpRangoMin_Pips` | **Ausente en `CandleMomentumATR_EA`** | Optimizado en `ReportOptimizer-26672367.xml` (`2.0` a `10.0` pips, paso `0.5`) | Implementado en el EA hermano `CandleMomentumRR_EA.mq5`. |
| Rango máximo en pips / ATR | `InpRangoMax_Pips` / `MaxATR` | **Ausente en `CandleMomentumATR_EA`** | No implementado ni documentado en el XML | No existe cota superior de tamaño de vela en `CandleMomentumATR_EA.mq5`. |
| Modo de filtrado (`PIPS`, `ATR`, etc.) | Selector de modo | **Implícito por separación de EAs** | `CandleMomentumATR_EA` opera $100\%$ en modo `ATR` | El proyecto separó el modo `PIPS` (`CandleMomentumRR_EA`) y el modo `ATR` (`CandleMomentumATR_EA`). |

---

## 4. Validación y Calidad de los Resultados (Estadísticas Globales)

### 4.1 Conteos de Validación y Calidad Muestral

| Indicador de Calidad | Conteo en XML Exportado ($n=731$) | % sobre XML ($731$) | % sobre Grilla Exhaustiva ($3{,}240$) | Clasificación Epistemológica |
|---|---:|---:|---:|---|
| **Total de pases en la grilla evaluada** | $3{,}240$ *(evaluados)* | — | $100.00\%$ | Cálculo derivado exacto (`Pass` $0\dots 3239$) |
| **Total de pases exportados en el XML** | **$731$** | $100.00\%$ | $22.56\%$ | Hecho comprobado directo |
| **Pases con beneficio positivo ($\text{Profit} > 0$)** | **$731$** | $100.00\%$ | $22.56\%$ | Hecho comprobado directo |
| **Pases con beneficio $\le 0$ ($\text{Profit} \le 0$)** | **$0$** *(en XML)* / **$2{,}509$** *(omitidos)* | $0.00\%$ | $77.44\%$ | Derivado de filtro *Skip Useless Results* |
| **Pases sin operaciones ($\text{Trades} = 0$)** | **$0$** *(en XML)* | $0.00\%$ | Incluido en los $2{,}509$ | Hecho comprobado directo |
| **Pases con muestra crítica ($\text{Trades} < 10$)** | **$183$** | $25.03\%$ | $5.65\%$ | Hecho comprobado directo |
| **Pases con muestra baja ($\text{Trades} < 30$)** | **$326$** | $44.60\%$ | $10.06\%$ | Hecho comprobado directo |
| **Pases con muestra insuficiente ($\text{Trades} < 50$)** | **$417$** | **$57.05\%$** | $12.87\%$ | Hecho comprobado directo |
| **Pases con muestra exploratoria ($\text{Trades} \ge 50$)** | **$314$** | **$42.95\%$** | **$9.69\%$** | Hecho comprobado directo |
| **Pases con muestra media ($\text{Trades} \ge 100$)** | **$178$** | **$24.35\%$** | **$5.49\%$** | Hecho comprobado directo |
| **Pases con muestra alta ($\text{Trades} \ge 200$)** | **$66$** | **$9.03\%$** | **$2.04\%$** | Hecho comprobado directo |
| **Pases con valores de métricas inválidos (`NaN`/`Inf`)** | **$0$** | $0.00\%$ | $0.00\%$ | Hecho comprobado directo |
| **Pases con `Profit Factor` distorsionado ($\text{PF} > 3.0$, todos con $\le 9$ trades)** | **$66$** | $9.03\%$ | $2.04\%$ | Hecho comprobado directo |
| **Pases con `Profit Factor` extremo ($\text{PF} > 10.0$, todos con $\le 4$ trades)** | **$29$** | $3.97\%$ | $0.90\%$ | Hecho comprobado directo |
| **Pases con Drawdown moderado ($\text{Equity DD \%} \ge 5.0\%$)** | **$21$** *(máx: $7.39\%$)* | $2.87\%$ | $0.65\%$ | Hecho comprobado directo |
| **Pases con resultados numéricos únicos (distintos)** | **$689$** | **$94.25\%$** | $21.27\%$ | Hecho comprobado directo |
| **Pases redundantes (copias excedentes de métricas)** | **$42$** *(en $33$ clústeres, $75$ pases)* | **$5.75\%$** | $1.30\%$ | Hecho comprobado directo |

### 4.2 Distribución Estadística de las Métricas Exportadas

#### A. Conjunto Global Exportado ($n = 731$ pases)

| Métrica | Media | Desv. Est. | Mínimo | P5 | P25 (Q1) | Mediana (P50) | P75 (Q3) | P95 | Máximo | IQR | Asimetría (Skew) |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| `Result` *(Criterio MT5)* | $18.60$ | $19.71$ | $0.02$ | $0.03$ | $0.10$ | $18.20$ | $29.60$ | $55.04$ | $80.64$ | $29.50$ | $+0.81$ |
| `Profit` ($\text{USD}$) | $\$808.88$ | $\$774.87$ | $\$0.63$ | $\$58.30$ | $\$236.10$ | $\$526.43$ | $\$1{,}178.35$ | $\$2{,}314.12$ | $\$4{,}658.96$ | $\$942.25$ | $+1.54$ |
| `Expected Payoff` ($\text{USD}$) | $\$39.50$ | $\$67.58$ | $\$0.02$ | $\$1.32$ | $\$6.08$ | $\$16.34$ | $\$44.68$ | $\$149.04$ | $\$497.52$ | $\$38.60$ | $+3.96$ |
| `Profit Factor` | $5.3861$ | $21.2388$ | $1.0002$ | $1.0171$ | $1.0791$ | $1.2206$ | $1.7048$ | $5.4868$ | $172.7500$ | $0.6257$ | $+5.98$ |
| `Recovery Factor` | $0.9558$ | $1.0668$ | $0.0006$ | $0.0516$ | $0.2209$ | $0.5541$ | $1.2625$ | $3.1837$ | $5.9739$ | $1.0416$ | $+1.96$ |
| `Sharpe Ratio` | $1.4014$ | $2.0630$ | $0.0010$ | $0.0555$ | $0.2799$ | $0.6513$ | $1.6610$ | $5.1850$ | $15.7154$ | $1.3811$ | $+3.49$ |
| `Equity DD %` | $1.4412\%$ | $1.3087\%$ | $0.0828\%$ | $0.1485\%$ | $0.4892\%$ | $1.0010\%$ | $2.0349\%$ | $4.2031\%$ | $7.3876\%$ | $1.5457\%$ | $+1.51$ |
| `Trades` | $70.23$ | $85.94$ | $1$ | $3$ | $9.5$ | $39$ | $94$ | $230$ | $573$ | $84.5$ | $+2.24$ |
| `Custom` | $0.00$ | $0.00$ | $0.00$ | $0.00$ | $0.00$ | $0.00$ | $0.00$ | $0.00$ | $0.00$ | $0.00$ | $0.00$ |

#### B. Subconjunto Filtrado con Muestra Suficiente ($\text{Trades} \ge 50$, $n = 314$ pases)

| Métrica | Media | Desv. Est. | Mínimo | P25 (Q1) | Mediana (P50) | P75 (Q3) | Máximo |
|---|---:|---:|---:|---:|---:|---:|---:|
| `Result` *(Criterio MT5)* | $36.11$ | $13.89$ | $22.74$ | $25.82$ | $29.53$ | $43.06$ | $80.64$ |
| `Profit` ($\text{USD}$) | $\$1{,}127.27$ | $\$890.53$ | $\$2.81$ | $\$424.07$ | $\$967.90$ | $\$1{,}696.18$ | $\$4{,}658.96$ |
| `Expected Payoff` ($\text{USD}$) | $\$10.98$ | $\$12.70$ | $\$0.02$ | $\$3.26$ | $\$6.53$ | $\$13.85$ | $\$84.63$ |
| `Profit Factor` | $1.1508$ | $0.1826$ | $1.0002$ | $1.0404$ | $1.0886$ | $1.1838$ | **$2.1820$** |
| `Recovery Factor` | $0.5741$ | $0.6246$ | $0.0008$ | $0.1624$ | $0.3848$ | $0.7014$ | $3.5281$ |
| `Sharpe Ratio` | $1.3912$ | $1.4418$ | $0.0016$ | $0.4028$ | $0.9141$ | $1.8332$ | $7.5498$ |
| `Equity DD %` | $2.5125\%$ | $1.3076\%$ | $0.5303\%$ | $1.5461\%$ | $2.3012\%$ | $3.1033\%$ | $7.3876\%$ |
| `Trades` | $140.77$ | $90.70$ | $51$ | $74.25$ | $118$ | $182.75$ | $573$ |

> [!IMPORTANT]
> **Significado de la columna `Result` y distorsión de `Profit Factor` en muestras pequeñas:**
> 1. La columna `Result` ($\in [0.02, 80.64]$) **no es beneficio monetario**; representa el puntaje del *Complex Criterion max* nativo de MT5. Se comprueba empíricamente que MT5 penaliza drásticamente las muestras pequeñas en `Result`: todos los pases con $\text{Trades} < 15$ tienen $\text{Result} \in [0.02, 0.22]$, mientras que todos los pases con $\text{Trades} \ge 50$ tienen $\text{Result} \in [22.74, 80.64]$. Sin embargo, la fórmula exacta de ponderación interna de MetaQuotes no está documentada en el XML, por lo que su significado analítico exacto se trata como no verificado.
> 2. En el conjunto sin filtrar ($n=731$), la media de `Profit Factor` ($5.39$) y su máximo ($172.75$) son artefactos de muestras diminutas: **el 100% de los 66 pases con $\text{PF} > 3.0$ tiene $\le 9$ operaciones** y **el 100% de los 29 pases con $\text{PF} > 10.0$ tiene $\le 4$ operaciones** (por ejemplo, $1$ operación ganadora con un pequeño ajuste o pérdida residual produce $\text{PF} = 172.75$). Al exigir $\text{Trades} \ge 50$, el `Profit Factor` máximo real es **$2.1820$** y la mediana es **$1.0886$**.

![Gráfico 1: Distribución General de Beneficios](01_distribucion_beneficios.png)

![Gráfico 2: Beneficio vs Operaciones](02_beneficio_vs_operaciones.png)

![Gráfico 3: Profit Factor vs Drawdown](03_profit_factor_vs_drawdown.png)

---

## 5. Detección de Optimizaciones Redundantes (Sección Prioritaria)

### 5.1 Distinción entre Duplicación de Métricas y Duplicación de Operaciones
- **Duplicación de métricas (comprobada en el XML):** dos o más configuraciones exhiben exactamente los mismos valores en las $8$ métricas exportadas (`Result`, `Profit`, `Expected Payoff`, `Profit Factor`, `Recovery Factor`, `Sharpe Ratio`, `Equity DD %`, `Trades`).
- **Duplicación de operaciones (inferencia no verificable sin logs de transacciones):** aunque compartir exactamente $8$ métricas continuas con precisión de hasta $6$ decimales al cambiar solo el umbral de tamaño de vela sugiere fuertemente que el filtro admitió exactamente la misma secuencia de velas gatillo, **el XML no incluye identificadores de órdenes ni marcas de tiempo**. Para demostrar formalmente igualdad de operaciones se requiere el historial de transacciones individuales o los archivos `ResearchSignals.csv`.

### 5.2 Tabla de Redundancia por Temporalidad en `ReportOptimizer-ATR.xml`

| Temporalidad | Pases | Resultados distintos | Pases redundantes | % redundancia | Pases involucrados en clústeres ($\ge 2$) |
|---|---:|---:|---:|---:|---:|
| **M1** (`0`) | $0$ *(de $405$)* | $0$ | $0$ | $0.00\%$ | $0$ |
| **M3** (`1`) | $36$ | $36$ | $0$ | **$0.00\%$** | $0$ |
| **M5** (`2`) | $128$ | $128$ | $0$ | **$0.00\%$** | $0$ |
| **M15** (`3`) | $60$ | $60$ | $0$ | **$0.00\%$** | $0$ |
| **M30** (`4`) | $132$ | $124$ | $8$ | **$6.06\%$** | $16$ ($8$ pares) |
| **H1** (`5`) | $164$ | $164$ | $0$ | **$0.00\%$** | $0$ |
| **H2** (`6`) | $83$ | $49$ | $34$ | **$40.96\%$** | $59$ ($16$ pares + $9$ tripletes) |
| **H4** (`7`) | $128$ | $128$ | $0$ | **$0.00\%$** | $0$ |
| **TOTAL XML ATR** | **$731$** | **$689$** | **$42$** | **$5.75\%$** | **$75$ ($10.26\%$ del total)** |

### 5.3 ¿Qué Parámetro Genera los Resultados Repetidos y en Qué Intervalos?
Al agrupar las configuraciones manteniendo fijos $3$ parámetros y variando únicamente $1$ parámetro a la vez:

| Parámetro Variado (manteniendo los otros 3 constantes) | Pases Evaluados en XML | Resultados Distintos | Pases Redundantes Generados | % de Redundancia Atribuible |
|---|---:|---:|---:|---:|
| **`InpMultiplicadorATR`** *(fijos TF, Cuerpo, RR)* | $731$ | $689$ | **$42$** | **$5.75\%$ ($100\%$ de la redundancia total)** |
| **`InpPorcentajeCuerpo`** *(fijos TF, ATR, RR)* | $731$ | $731$ | **$0$** | **$0.00\%$** |
| **`InpRR`** *(fijos TF, Cuerpo, ATR)* | $731$ | $731$ | **$0$** | **$0.00\%$** |
| **`InpTimeframe`** *(fijos Cuerpo, ATR, RR)* | $731$ | $731$ | **$0$** | **$0.00\%$** |

**Radiografía exacta de los únicos 33 clústeres duplicados (42 copias redundantes) en todo el XML:**
1. **`M30` con `InpPorcentajeCuerpo = 100%` y `InpMultiplicadorATR` $\in [0.75, 1.00]$ ($\text{RR} \in [1.5, 5.0]$):** $8$ pares ($8$ pases redundantes), todos con exactamente **$\text{Trades} = 4$**. En `M30`, solo existieron $4$ velas Marubozu perfectas ($100\%$ cuerpo) que cumplieron las condiciones, y las $4$ tuvieron un rango superior a $1.00\text{ ATR}$; por ello, pasar de $0.75\text{ ATR}$ a $1.00\text{ ATR}$ no descartó ninguna de las $4$ velas.
2. **`H2` con `InpPorcentajeCuerpo = 100%` y `InpMultiplicadorATR` $\in [0.50, 0.75, 1.00]$ ($\text{RR} \in [1.0, 5.0]$):** $9$ tripletes ($18$ pases redundantes), todos con exactamente **$\text{Trades} = 1$**. En todo el período solo hubo $1$ vela `H2` con $100\%$ de cuerpo rentable, cuyo rango superó $1.00\text{ ATR}$ (pero fue menor a $1.25\text{ ATR}$).
3. **`H2` con `InpPorcentajeCuerpo` $\in \{85\%, 90\%\}$ y `InpMultiplicadorATR` $\in [2.25, 2.50]$ ($\text{RR} \in [1.0, 4.5]$):** $16$ pares ($16$ pases redundantes), todos con **$\text{Trades} \in \{6, 7, 8\}$**. En la cola extrema de `H2`, las pocas velas que superaron $2.25\text{ ATR}$ también superaron $2.50\text{ ATR}$.

> [!TIP]
> **Hallazgo fundamental sobre la redundancia del filtro ATR:**
> El **100% de las 42 redundancias** de `ReportOptimizer-ATR.xml` ocurre exclusivamente en configuraciones marginales con **$\le 8$ operaciones** ($\text{Trades} \in \{1, 4, 6, 7, 8\}$). Entre las $556$ configuraciones con $\ge 9$ operaciones (y entre las $314$ configuraciones con $\ge 50$ operaciones), **existen 0 pases redundantes (0.00% de redundancia)**: cada incremento de $0.25\text{ ATR}$ filtra efectivamente velas reales y modifica los resultados.

### 5.4 Comparación Directa de Redundancia: Filtro en PIPS (`ReportOptimizer-26672367.xml`) vs Filtro ATR (`ReportOptimizer-ATR.xml`)

| Temporalidad | PIPS (Todos $n=2{,}012$): % Redundancia | PIPS (Solo $\text{Profit}>0$, $n=300$): % Redundancia | ATR ($\text{Profit}>0$, $n=731$): % Redundancia | ATR ($\text{Trades}\ge 50$, $n=314$): % Redundancia |
|---|---:|---:|---:|---:|
| **M1** | $5.60\%$ ($14/250$) | $0.00\%$ ($0/0$) | $0.00\%$ ($0/0$) | $0.00\%$ |
| **M3** | $2.39\%$ ($6/251$) | $0.00\%$ ($0/5$) | **$0.00\%$** ($0/36$) | **$0.00\%$** ($0/27$) |
| **M5** | $0.79\%$ ($2/253$) | $4.44\%$ ($2/45$) | **$0.00\%$** ($0/128$) | **$0.00\%$** ($0/90$) |
| **M15** | $9.09\%$ ($23/253$) | $0.00\%$ ($0/5$) | **$0.00\%$** ($0/60$) | **$0.00\%$** ($0/46$) |
| **M30** | $11.95\%$ ($30/251$) | $57.89\%$ ($22/38$) | **$6.06\%$** ($8/132$) | **$0.00\%$** ($0/60$) |
| **H1** | $23.81\%$ ($60/252$) | $12.00\%$ ($3/25$) | **$0.00\%$** ($0/164$) | **$0.00\%$** ($0/68$) |
| **H2** | $54.80\%$ ($137/250$) | $89.80\%$ ($44/49$) | **$40.96\%$** ($34/83$) | **$0.00\%$** ($0/4$) |
| **H4** | **$78.97\%$** ($199/252$) | **$71.43\%$** ($95/133$) | **$0.00\%$** ($0/128$) | **$0.00\%$** ($0/19$) |
| **GLOBAL** | **$23.46\%$** ($472/2{,}012$) | **$55.33\%$** ($166/300$) | **$5.75\%$** ($42/731$) | **$0.00\%$** ($0/314$) |

![Gráfico 5: Redundancia por Temporalidad](05_redundancia_por_temporalidad.png)

---

## 6. Análisis Individual por Temporalidad

> [!NOTE]
> El encabezado del XML indica `EURUSD,M5` como temporalidad base de ejecución del Strategy Tester, pero el EA evalúa las velas y el indicador `iATR` en la temporalidad `g_tfGatillo = ConvertirTimeframe(InpTimeframe)` propia de cada pase. La proporción de pases rentables sobre la grilla ($405$ pases por temporalidad) describe el comportamiento histórico en la muestra `2026.01.01 - 2026.10.17` y **no debe interpretarse como probabilidad de rentabilidad futura**.

| Temporalidad (`InpTimeframe`) | Pases en XML ($\text{Profit}>0$) | % Rentables sobre XML ($n$) | % Rentables sobre Grilla ($405$) | Beneficio Mediano (Todos / $T\ge 50$) | PF Mediano ($T\ge 10$ / $T\ge 50$) | Drawdown Mediano (Todos / $T\ge 50$) | Trades Mediano (Todos / $T\ge 50$) | Pases con $T\ge 50$ (% XML / % Grilla) | % Redundancia |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| **M1** (`0`) | $0$ | $0.00\%$ | **$0.00\%$** | S/D | S/D | S/D | S/D | $0$ ($0.0\%$ / $0.0\%$) | $0.00\%$ |
| **M3** (`1`) | $36$ | $100.0\%$ | **$8.89\%$** | $\$824.67$ / $\$1{,}183.96$ | $1.0561$ / $1.0561$ | $2.93\%$ / $3.20\%$ | $210.0$ / $216.0$ | $27$ ($75.00\%$ / $6.67\%$) | $0.00\%$ |
| **M5** (`2`) | $128$ | $100.0\%$ | **$31.60\%$** | $\$1{,}104.79$ / $\$1{,}253.35$ | $1.1231$ / $1.0895$ | $2.04\%$ / $2.48\%$ | $114.5$ / $133.5$ | $90$ ($70.31\%$ / $22.22\%$) | $0.00\%$ |
| **M15** (`3`) | $60$ | $100.0\%$ | **$14.81\%$** | $\$1{,}114.58$ / $\$1{,}467.11$ | $1.2153$ / **$1.1713$** | $1.39\%$ / $1.56\%$ | $69.0$ / $76.0$ | $46$ ($76.67\%$ / $11.36\%$) | $0.00\%$ |
| **M30** (`4`) | $132$ | $100.0\%$ | **$32.59\%$** | $\$357.72$ / $\$625.67$ | $1.1171$ / $1.0754$ | $1.06\%$ / $1.87\%$ | $45.5$ / $90.5$ | $60$ ($45.45\%$ / $14.81\%$) | $6.06\%$ |
| **H1** (`5`) | $164$ | $100.0\%$ | **$40.49\%$** | $\$527.59$ / $\$872.94$ | $1.1406$ / $1.0781$ | $1.44\%$ / $2.56\%$ | $31.0$ / $117.5$ | $68$ ($41.46\%$ / $16.79\%$) | $0.00\%$ |
| **H2** (`6`) | $83$ | $100.0\%$ | **$20.49\%$** | $\$295.20$ / $\$227.92$ | $1.1206$ / $1.0343$ | $0.36\%$ / $2.01\%$ | $6.0$ / $77.0$ | $4$ ($4.82\%$ / $0.99\%$) | $40.96\%$ |
| **H4** (`7`) | $128$ | $100.0\%$ | **$31.60\%$** | $\$628.30$ / **$\$2{,}361.71$** | $1.5796$ / **$1.6390$** | $0.49\%$ / $1.72\%$ | $12.0$ / $60.0$ | $19$ ($14.84\%$ / $4.69\%$) | $0.00\%$ |

### Síntesis Operativa por Temporalidad y Rangos Favorables ($\text{Trades} \ge 50$)
- **`M1` (`InpTimeframe = 0`):** $0$ pases rentables sobre $405$. El spread fijo/variable y el ruido de $1$ minuto anulan por completo la continuación inmediata de velas impulsivas.
- **`M3` (`InpTimeframe = 1`):** solo sobrevive el extremo superior de volatilidad: $\text{InpMultiplicadorATR} \in \{2.25, 2.50\}$, $\text{Cuerpo} \in \{85\%, 90\%\}$ y $\text{RR} \in [3.0, 5.0]$. Alta cantidad de operaciones (mediana $210$), pero margen por operación estrecho ($\text{PF mediano} = 1.0561$) y mayor drawdown ($2.93\%$–$6.55\%$).
- **`M5` (`InpTimeframe = 2`):** es la temporalidad con **mayor número absoluto de pases con muestra suficiente** ($90$ pases con $T\ge 50$, $65$ con $T\ge 100$ y $23$ con $T\ge 200$). La zona más robusta se ubica en $\text{InpMultiplicadorATR} \in [1.50, 2.50]$, $\text{Cuerpo} \in [85\%, 95\%]$ y $\text{RR} \in [2.5, 4.5]$ (destacando el pase `1626` con $231$ trades y $\$3{,}634.20$, y el pase `1418` con $75$ trades y $\text{PF} = 1.6252$).
- **`M15` (`InpTimeframe = 3`):** presenta un régimen altamente selectivo y consistente. Ningún pase con $\text{ATR} \le 1.50$ resultó rentable; en cambio, para $\text{InpMultiplicadorATR} \in [1.75, 2.50]$, $\text{Cuerpo} \in \{85\%, 90\%\}$ y $\text{RR} \in [2.0, 4.0]$, el $76.67\%$ de los pases supera las $50$ operaciones con una mediana de $\text{PF} = 1.1713$ (alcanzando $\text{PF} = 1.6675$ en el pase `2099` y $\text{PF} = 1.6060$ en el pase `2491`).
- **`M30` (`InpTimeframe = 4`):** muestra un comportamiento bimodal: funciona con velas muy limpias ($\text{Cuerpo} \in \{90\%, 95\%\}$) tanto en rangos moderados ($\text{ATR} \in [0.75, 1.00]$, $\text{RR} = 1.5$) como en expansiones fuertes ($\text{ATR} \in [1.75, 2.00]$, $\text{RR} \in [1.5, 4.5]$).
- **`H1` (`InpTimeframe = 5`):** alcanza la **mayor tasa de supervivencia en la grilla ($164/405 = 40.49\%$)** y $68$ pases con $T\ge 50$. Sus mejores regiones con muestra amplia se concentran en $\text{InpMultiplicadorATR} \in [0.50, 1.25]$ y $\text{Cuerpo} \in \{80\%, 85\%, 90\%\}$, tanto en $\text{RR} \in [1.5, 2.0]$ (más de $180$ operaciones) como en $\text{RR} \in [3.5, 5.0]$ ($\sim 94$–$167$ operaciones).
- **`H2` (`InpTimeframe = 6`):** es la temporalidad más débil estadísticamente: mediana de solo $6$ operaciones, $40.96\%$ de redundancia y únicamente $4$ pases con $\ge 50$ operaciones (todos con $\text{PF} \le 1.09$).
- **`H4` (`InpTimeframe = 7`):** exhibe el **mayor `Profit Factor` mediano ($1.6390$) y mayor beneficio mediano ($\$2{,}361.71$) entre todas las configuraciones con $\ge 50$ operaciones**. Debido a que en $9.5$ meses existen $\sim 1{,}240$ velas `H4`, solo el subconjunto $\text{Cuerpo} = 80\%$ y $\text{InpMultiplicadorATR} \in [0.50, 1.00]$ supera las $50$ operaciones ($52$ a $78$ trades), formando una meseta continua de altísima rentabilidad ($\text{PF}$ entre $1.32$ y $2.18$).

![Gráfico 4: Rentabilidad por Temporalidad](04_rentabilidad_por_temporalidad.png)

---

## 7. Análisis Profundo del Rango Relativo al ATR (`InpMultiplicadorATR`)

### 7.1 Desempeño Global y Filtrado por `InpMultiplicadorATR`

| `InpMultiplicadorATR` | Pases en XML ($\text{Profit}>0$) | % sobre Grilla ($360$) | Pases con $T\ge 50$ | Trades Mediano (Todos / $T\ge 50$) | Beneficio Mediano (Todos / $T\ge 50$) | PF Mediano (Todos / $T\ge 50$) | Expected Payoff Mediano ($T\ge 50$) | Equity DD % Mediano (Todos / $T\ge 50$) |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| **0.50** | $50$ | $13.89\%$ | $23$ | $45.5$ / $93.0$ | $\$506.52$ / $\$1{,}101.79$ | $1.2189$ / $1.0776$ | $\$5.99$ | $1.22\%$ / $2.07\%$ |
| **0.75** | $67$ | $18.61\%$ | $34$ | $52.0$ / $110.0$ | $\$513.87$ / $\$948.67$ | $1.2440$ / $1.0992$ | $\$7.41$ | $1.47\%$ / $2.05\%$ |
| **1.00** | $68$ | $18.89\%$ | $28$ | $30.0$ / $122.0$ | $\$592.06$ / $\$717.53$ | $1.3647$ / $1.0813$ | $\$6.62$ | $1.12\%$ / $2.28\%$ |
| **1.25** | $60$ | $16.67\%$ | $34$ | $73.0$ / $127.0$ | $\$691.36$ / $\$742.42$ | $1.1466$ / $1.0862$ | $\$6.11$ | $1.60\%$ / $2.05\%$ |
| **1.50** | $54$ | $15.00\%$ | $24$ | $41.0$ / $221.0$ | $\$625.66$ / $\$560.73$ | $1.1384$ / $1.0390$ | $\$2.95$ | $1.28\%$ / $2.84\%$ |
| **1.75** | $78$ | $21.67\%$ | $38$ | $28.0$ / $120.0$ | $\$464.73$ / $\$836.44$ | $1.1537$ / $1.0774$ | $\$6.28$ | $1.06\%$ / $2.38\%$ |
| **2.00** | $89$ | $24.72\%$ | $38$ | $41.0$ / $89.5$ | $\$484.60$ / $\$1{,}020.35$ | $1.2079$ / $1.1087$ | $\$8.87$ | $0.97\%$ / $2.09\%$ |
| **2.25** | $112$ | $31.11\%$ | $42$ | $29.5$ / $118.5$ | $\$487.75$ / $\$1{,}160.43$ | $1.2004$ / $1.0961$ | $\$6.04$ | $0.86\%$ / $2.44\%$ |
| **2.50** | **$153$** | **$42.50\%$** | **$53$** | $24.0$ / $116.0$ | $\$521.78$ / **$\$1{,}253.35$** | $1.3706$ / **$1.1177$** | **$\$9.09$** | $0.71\%$ / $2.37\%$ |

### 7.2 Sensibilidad ante Incrementos de $+0.25\text{ ATR}$ (Manteniendo Fijos TF, Cuerpo y RR)
Evaluando los **$465$ pares de pases rentables adyacentes** en `InpMultiplicadorATR`:

| Transición de Umbral ATR | Pares Vecinos Rentables | Cambio Mediano en `Trades` ($\Delta\text{Trades}$) | Cambio Relativo Mediano ($\Delta\%\text{Trades}$) | Variación Absoluta Mediana en `Profit` ($|\Delta\text{Profit}|$) | Variación Absoluta Mediana en `PF` ($|\Delta\text{PF}|$) | Diagnóstico de Sensibilidad |
|---|---:|---:|---:|---:|---:|---|
| `0.50 -> 0.75` | $48$ | $-8.0$ | $-13.90\%$ | $\$236.51$ | $0.1010$ | **Baja sensibilidad / Meseta estable** (en `H1`, `H4`, `M30`) |
| `0.75 -> 1.00` | $59$ | $-9.0$ | $-16.22\%$ | $\$214.64$ | **$0.0420$** | **Máxima estabilidad vecina** ($|\Delta\text{PF}|$ mínimo de toda la grilla) |
| `1.00 -> 1.25` | $45$ | $-13.0$ | $-27.59\%$ | $\$411.47$ | $0.0972$ | **Transición moderada** (pérdida de muestra en `H4`, entrada de `M5`) |
| `1.25 -> 1.50` | $38$ | $-19.0$ | $-36.31\%$ | $\$346.06$ | $0.1519$ | **Zona de inflexión intermedia** |
| `1.50 -> 1.75` | $42$ | **$-28.0$** | **$-39.04\%$** | **$\$618.10$** | $0.2164$ | **Mayor sensibilidad / Cambio de régimen** (activación de `M15`) |
| `1.75 -> 2.00` | $63$ | $-19.0$ | $-32.79\%$ | $\$224.41$ | $0.2282$ | **Estabilización en régimen de expansión (`M15`, `M30`, `M5`)** |
| `2.00 -> 2.25` | $62$ | $-14.5$ | $-33.38\%$ | $\$323.42$ | $0.2509$ | **Activación de `M3` y consolidación en `M5`/`M15`** |
| `2.25 -> 2.50` | $108$ | $-14.0$ | $-33.33\%$ | $\$202.34$ | $0.1929$ | **Meseta superior de alta selectividad ($108$ pares rentables)** |

### 7.3 Regiones Estables Identificadas vs Zonas de Cambio Drástico
1. **Región Estable 1 — Impulso Estructural en Temporalidades Altas (`H4` y `H1`, $\text{InpMultiplicadorATR} \in [0.50, 1.00]$):**
   - Entre $0.50\text{ ATR}$ y $1.00\text{ ATR}$ la pérdida mediana de operaciones por cada paso de $+0.25\text{ ATR}$ es de apenas $-13.9\%$ a $-16.2\%$, y la variación mediana de `Profit Factor` en `0.75 -> 1.00` es de solo $0.042$. En `H4` ($\text{Cuerpo}=80\%, \text{RR}\in [2.0, 4.5]$) y `H1` ($\text{Cuerpo}\in \{85\%, 90\%\}, \text{RR}\in [1.5, 5.0]$), los tres niveles ($0.50, 0.75, 1.00\text{ ATR}$) conforman un bloque compacto sin caídas abruptas.
2. **Zona de Fractura / Cambio Drástico ($\text{InpMultiplicadorATR} \in [1.25, 1.75]$):**
   - El paso `1.50 -> 1.75 ATR` recorta la mediana de operaciones en un **$-39.04\%$** y produce el mayor salto mediano en beneficio ($\$618.10$). Esto ocurre porque en `M5` y `M15` las velas de tamaño medio ($1.00$–$1.50\text{ ATR}$) sufren un alto desgaste por ruido intradía, mientras que al cruzar el umbral de $1.75\text{ ATR}$ se filtran las falsas rupturas.
3. **Región Estable 2 — Expansión de Volatilidad Intradía (`M5` y `M15`, $\text{InpMultiplicadorATR} \in [2.00, 2.50]$):**
   - Entre $2.00, 2.25$ y $2.50\text{ ATR}$, la proporción de configuraciones rentables en la grilla sube del $24.72\%$ al $42.50\%$, manteniendo entre $53$ y $120$ operaciones en `M5` y `M15` con `Profit Factor` consistente ($1.20$–$1.67$) y $100\%$ de vecinos ortogonales positivos.

![Gráfico 6: Beneficio, PF y Operaciones frente a RangeATR](06_beneficio_vs_range_atr.png)

---

## 8. Comparación Controlada: Filtro ATR vs Filtro PIPS

### 8.1 Diseño de la Comparación Controlada
En `ReportOptimizer-ATR.xml` solo se optimizó `CandleMomentumATR_EA` (filtro `ATR`). Sin embargo, en el mismo directorio `Backtest` se dispone de `ReportOptimizer-26672367.xml`, correspondiente a `CandleMomentumRR_EA` (filtro `InpRangoMin_Pips`) ejecutado sobre **exactamente el mismo activo (`EURUSD`), período (`2026.01.01 - 2026.10.17`), servidor (`FivePercentOnline-Real`), depósito ($\$100{,}000$) y apalancamiento ($1:100$)**.

Para evitar atribuir al filtro diferencias causadas por otros parámetros, **se restringe la comparación al subespacio exactamente común de parámetros de control**:
- $\text{InpTimeframe} \in \{0, 1, 2, 3, 4, 5, 6, 7\}$ (`M1` a `H4`)
- $\text{InpPorcentajeCuerpo} \in \{80\%, 90\%, 100\%\}$ (excluyendo $60\%$ y $70\%$ de PIPS, y excluyendo $85\%$ y $95\%$ de ATR)
- $\text{InpRR} \in \{1.0, 2.0, 3.0, 4.0, 5.0\}$ (excluyendo los medios pasos $1.5, 2.5, 3.5, 4.5$ de ATR)

### 8.2 Resultados Globales y por Temporalidad en el Subespacio Controlado

| Métrica en Subespacio Controlado ($\text{Cuerpo}\in\{80,90,100\}, \text{RR}\in\{1..5\}$) | Filtro ATR ($\text{Profit}>0$, $n=209$) | Filtro PIPS ($\text{Profit}>0$, $n=224$) | Filtro ATR ($\text{Trades}\ge 50$, $n=104$) | Filtro PIPS ($\text{Trades}\ge 50$, $n=78$) |
|---|---:|---:|---:|---:|
| **% de Pases Rentables sobre Evaluados** | **$19.35\%$** ($209/1{,}080$) | $18.65\%$ ($224/1{,}201$) | **$9.63\%$** ($104/1{,}080$) | $6.49\%$ ($78/1{,}201$) |
| **% de Redundancia entre Pases** | **$8.61\%$** ($18/209$) | **$53.57\%$** ($120/224$) | **$0.00\%$** ($0/104$) | **$34.62\%$** ($27/78$) |
| **Configuraciones Distintas Reales** | **$191$** | $104$ | **$104$** | $51$ |
| **Mediana de Operaciones (`Trades`)** | **$48.0$** | $18.0$ | **$119.0$** | $80.5$ |
| **Mediana de Beneficio Neto (`Profit`)** | **$\$481.43$** | $\$366.81$ | **$\$907.56$** | $\$879.02$ |
| **Beneficio Neto Máximo (`Profit`)** | **$\$4{,}188.85$** | $\$3{,}756.59$ | **$\$4{,}188.85$** | $\$3{,}756.59$ |
| **Mediana de `Profit Factor`** | $1.1850$ | $1.4760$ *(sesgado por $T=18$)* | $1.0889$ | $1.1044$ |
| **Mediana de `Equity DD %`** | $1.2246\%$ | $0.6681\%$ | $2.3113\%$ | $1.8019\%$ |

#### Desglose por Temporalidad en el Subespacio Controlado ($\text{Profit} > 0$)

| Temporalidad | ATR: Pases ($n$) | PIPS: Pases ($n$) | ATR: Trades Mediano | PIPS: Trades Mediano | ATR: Profit Mediano | PIPS: Profit Mediano | ATR: % Redundancia | PIPS: % Redundancia |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| **M1** | $0$ | $0$ | — | — | — | — | $0.00\%$ | $0.00\%$ |
| **M3** | **$14$** | $5$ | $137.0$ | $173.0$ | **$\$517.03$** | $\$298.92$ | **$0.00\%$** | $0.00\%$ |
| **M5** | **$46$** | $45$ | **$116.5$** | $21.0$ | **$\$1{,}155.31$** | $\$419.30$ | **$0.00\%$** | $4.44\%$ |
| **M15** | **$21$** | $5$ | **$76.0$** | $138.0$ | **$\$1{,}492.55$** | $\$285.66$ | **$0.00\%$** | $0.00\%$ |
| **M30** | **$48$** | $38$ | **$52.0$** | $3.0$ | **$\$416.68$** | $\$185.08$ | **$8.33\%$** | **$57.89\%$** |
| **H1** | $19$ | $25$ | $79.0$ | $86.0$ | $\$290.33$ | $\$595.04$ | **$0.00\%$** | $12.00\%$ |
| **H2** | $29$ | $49$ | $1.0$ | $1.0$ | $\$235.44$ | $\$295.20$ | $48.28\%$ | **$89.80\%$** |
| **H4** | $32$ | $57$ | $18.0$ | $55.0$ | $\$397.07$ | $\$984.46$ | **$0.00\%$** | **$85.96\%$** |

### Diagnóstico Técnico: ¿Por Qué el Filtro ATR es Superior al Filtro Fijo en Pips?
1. **En temporalidades intradía (`M3`, `M5`, `M15`, `M30`):** una grilla fija de `2.0` a `10.0` pips está descalibrada: en `M5` y `M30`, pedir $7$–$10$ pips deja a la estrategia casi sin operaciones (mediana de $21$ trades en `M5` y $3$ trades en `M30` con PIPS), mientras que el filtro `ATR` adapta el umbral dinámicamente a cada sesión (mediana de $116.5$ trades y $\$1{,}155.31$ en `M5`; $21$ pases rentables con mediana $\$1{,}492.55$ en `M15` frente a solo $5$ pases con $\$285.66$ en PIPS).
2. **En temporalidades altas (`H2` y `H4`):** ocurre el fenómeno inverso: como el rango normal de una vela `H4` en `EURUSD` es de $25$ a $45$ pips, cualquier umbral fijo entre $2.0$ y $10.0$ pips en `CandleMomentumRR_EA` es trivialmente superado por casi todas las velas de cuerpo amplio, provocando un **$85.96\%$ de pases redundantes en `H4`** ($57$ pases que repiten apenas $8$ configuraciones reales). El filtro `ATR` elimina por completo esa redundancia en `H4` (**$0.00\%$**) y permite discriminar verdaderamente el tamaño relativo de la vela.

![Gráfico 9: Comparación Controlada ATR vs PIPS](09_comparacion_atr_vs_pips.png)

---

## 9. Relación entre Porcentaje de Cuerpo de Vela (`InpPorcentajeCuerpo`) y Resultado

### 9.1 Tabla Global por Porcentaje Mínimo de Cuerpo

| `InpPorcentajeCuerpo` | Pases en XML ($\text{Profit}>0$) | % sobre Grilla ($648$) | Pases con $T\ge 50$ (% XML) | Trades Mediano (Todos / $T\ge 50$) | Beneficio Mediano (Todos / $T\ge 50$) | PF Mediano (Todos / $T\ge 50$) | Equity DD % Mediano ($T\ge 50$) | % Redundancia |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| **80%** | $129$ | $19.91\%$ | $71$ ($55.04\%$) | $56.0$ / $98.0$ | $\$527.86$ / $\$839.53$ | $1.1372$ / $1.0857$ | $2.2848\%$ | **$0.00\%$** |
| **85%** | **$185$** | **$28.55\%$** | $89$ ($48.11\%$) | $42.0$ / **$123.0$** | $\$659.56$ / $\$1{,}001.57$ | $1.2023$ / $1.0749$ | $2.5882\%$ | $4.32\%$ |
| **90%** | $174$ | $26.85\%$ | **$109$ ($62.64\%$)** | $74.5$ / $119.0$ | **$\$727.35$ / $\$1{,}223.32$** | $1.1480$ / **$1.1105$** | $2.3365\%$ | $4.60\%$ |
| **95%** | $147$ | $22.69\%$ | $30$ ($20.41\%$) | $26.0$ / $84.0$ | $\$513.87$ / $\$577.82$ | $1.3281$ / $1.0823$ | $1.5281\%$ | **$0.00\%$** |
| **100%** | $96$ | $14.81\%$ | $15$ ($15.63\%$) | **$4.0$** / $74.0$ | $\$250.56$ / $\$637.72$ | $1.6860$ / $1.0681$ | $2.0349\%$ | **$27.08\%$** |

### 9.2 Interacción del Cuerpo con la Temporalidad y el Rango ATR ($\text{Trades} \ge 50$)

| Temporalidad | Cuerpo 80%: Pases ($T\ge 50$) / Med Profit | Cuerpo 85%: Pases ($T\ge 50$) / Med Profit | Cuerpo 90%: Pases ($T\ge 50$) / Med Profit | Cuerpo 95%: Pases ($T\ge 50$) / Med Profit | Cuerpo 100%: Pases ($T\ge 50$) / Med Profit |
|---|---|---|---|---|---|
| **M3** | $2$ / $\$851.14$ | **$12$ / $\$1{,}266.47$** | **$12$ / $\$1{,}200.73$** | $1$ / $\$133.99$ | $0$ / S/M |
| **M5** | $8$ / $\$983.64$ | $12$ / $\$1{,}326.60$ | **$36$ / $\$1{,}892.05$** | $19$ / $\$874.74$ | $15$ / $\$637.72$ |
| **M15** | $7$ / $\$510.09$ | $16$ / $\$1{,}049.58$ | **$23$ / $\$1{,}221.98$** | $0$ / S/M | $0$ / S/M |
| **M30** | $16$ / $\$668.50$ | $9$ / $\$220.11$ | **$25$ / $\$652.72$** | $10$ / $\$523.40$ | $0$ / S/M |
| **H1** | $19$ / $\$799.14$ | **$36$ / $\$1{,}001.70$** | $13$ / $\$674.85$ | $0$ / S/M | $0$ / S/M |
| **H2** | $0$ / S/M | $4$ / $\$227.92$ | $0$ / S/M | $0$ / S/M | $0$ / S/M |
| **H4** | **$19$ / $\$2{,}361.71$** | $0$ / S/M *(máx 43 tr)* | $0$ / S/M *(máx 17 tr)* | $0$ / S/M | $0$ / S/M |

### Hallazgos Clave sobre el Porcentaje de Cuerpo
1. **El óptimo global de estabilidad se ubica en el intervalo $\text{Cuerpo} \in [85\%, 90\%]$:** concentra $198$ de los $314$ pases con muestra suficiente ($63.06\%$), maximizando tanto el beneficio mediano ($\$1{,}223.32$ en $90\%$) como el `Profit Factor` mediano con $T\ge 50$ ($1.1105$ en $90\%$).
2. **Desplazamiento del cuerpo óptimo según temporalidad:**
   - En **`M5`, `M15` y `M30`**, exigir **$\text{Cuerpo} = 90\%$** supera consistentemente a $80\%$ y $85\%$ porque filtra velas con mecha de rechazo en el cierre que en temporalidades cortas suelen anticipar reversiones inmediatas.
   - En **`H1`**, el óptimo de muestra y beneficio se desplaza a **$\text{Cuerpo} = 85\%$** ($36$ pases con $T\ge 50$, mediana $\$1{,}001.70$).
   - En **`H4`**, exigir $\ge 85\%$ de cuerpo reduce la muestra por debajo de $50$ operaciones ($15$ a $43$ trades), por lo que **$\text{Cuerpo} = 80\%$** es el único nivel que preserva tamaño muestral suficiente ($52$–$78$ trades) con excelente desempeño ($\$2{,}361.71$ mediano).
3. **Colapso muestral en $\text{Cuerpo} = 100\%$:** exigir ausencia total de mechas ($100\%$) reduce la mediana global a **4 operaciones**, genera el **$61.90\%$ de todas las redundancias del XML** ($26/42$) y solo deja $15$ pases con $\ge 50$ operaciones (exclusivamente en `M5` con $\text{ATR} \in [0.75, 1.25]$).

![Gráfico 7: Heatmap ATR vs Porcentaje de Cuerpo](07_heatmap_atr_vs_cuerpo.png)

---

## 10. Análisis del Ratio Riesgo/Beneficio (`InpRR`)

> [!WARNING]
> **Advertencia Metodológica sobre el Win Rate:**
> El XML de optimización de MT5 no exporta la cantidad de operaciones ganadoras ni perdedoras. Dado el dimensionamiento compuesto del lote ($1\%$ del balance instantáneo) y los redondeos de volumen, **no es posible deducir ni inventar la tasa de acierto real (*win rate*)**. La columna $W_{\text{BE Teórico}} = \frac{1}{1+\text{RR}}$ se incluye exclusivamente como referencia matemática del punto de equilibrio sin costos.

| `InpRR` | $W_{\text{BE Teórico}}$ ($1/(1+\text{RR})$) | Pases en XML ($\text{Profit}>0$) | % sobre Grilla ($360$) | Pases con $T\ge 50$ | Trades Mediano ($T\ge 50$) | Beneficio Mediano ($T\ge 50$) | PF Mediano ($T\ge 50$) | Expected Payoff Mediano ($T\ge 50$) | Equity DD % Mediano ($T\ge 50$) |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| **1.0** | $50.00\%$ | $46$ | $12.78\%$ | $22$ | $120.0$ | $\$433.10$ | $1.0784$ | $\$3.95$ | **$1.3219\%$** |
| **1.5** | $40.00\%$ | $74$ | $20.56\%$ | $36$ | $120.0$ | $\$496.94$ | $1.0962$ | $\$6.17$ | $1.4545\%$ |
| **2.0** | $33.33\%$ | $72$ | $20.00\%$ | $30$ | $119.5$ | $\$980.08$ | $1.1047$ | $\$7.03$ | $1.8711\%$ |
| **2.5** | $28.57\%$ | $74$ | $20.56\%$ | $26$ | $105.0$ | $\$934.92$ | $1.1049$ | $\$8.05$ | $1.8019\%$ |
| **3.0** | $25.00\%$ | $95$ | $26.39\%$ | $39$ | $118.0$ | $\$1{,}102.96$ | $1.0726$ | $\$5.86$ | $2.2388\%$ |
| **3.5** | $22.22\%$ | **$110$** | **$30.56\%$** | **$48$** | $117.0$ | $\$1{,}225.65$ | **$1.1099$** | **$\$9.40$** | $2.7436\%$ |
| **4.0** | $20.00\%$ | $100$ | $27.78\%$ | $43$ | $121.0$ | **$\$1{,}261.40$** | $1.1036$ | $\$8.72$ | $2.8919\%$ |
| **4.5** | $18.18\%$ | $95$ | $26.39\%$ | $39$ | $108.0$ | $\$1{,}201.24$ | $1.0946$ | $\$8.33$ | $3.1034\%$ |
| **5.0** | $16.67\%$ | $65$ | $18.06\%$ | $31$ | $114.0$ | $\$785.83$ | $1.0700$ | $\$6.57$ | $3.0101\%$ |

### Comportamiento del Ratio RR por Temporalidad ($\text{Trades} \ge 50$)
1. **Asimetría positiva en recorridos de continuación ($\text{RR} \in [2.5, 4.5]$ vs $\text{RR} = 1.0$):**
   - El ratio $\text{RR} = 1.0$ es el que **menos pases rentables genera en toda la grilla ($46/360 = 12.78\%$)** y el de menor beneficio mediano con muestra suficiente ($\$433.10$). Cuando una vela impulsiva genuina rompe con fuerza, cortar el recorrido en $1.0\text{R}$ desperdicia la cola derecha de continuación tendencial y deja poco margen para cubrir el spread.
   - La región **$\text{RR} \in [2.5, 4.5]$** maximiza simultáneamente la proporción de pases rentables ($26.4\%$–$30.6\%$), el `Expected Payoff` mediano ($\$8.05$–$\$9.40$) y el `Profit Factor` mediano ($1.095$–$1.110$).
2. **Costo en Drawdown de elevar el RR:**
   - Existe una relación monótona creciente entre `InpRR` y el `Equity DD %` mediano (con $T\ge 50$): sube de **$1.32\%$ en $\text{RR}=1.0$** a **$1.87\%$ en $\text{RR}=2.0$**, **$2.74\%$ en $\text{RR}=3.5$** y **$3.10\%$ en $\text{RR}=4.5$**. Al alejar el Take Profit, menor proporción de operaciones alcanza el objetivo antes de revertir al Stop Loss, alargando las rachas adversas.
3. **Diferencias por temporalidad:**
   - En **`H1` y `M30`**, los ratios cortos-medios **$\text{RR} \in [1.5, 2.0]$** ofrecen la mejor relación retorno/drawdown con alta frecuencia ($180$–$230$ trades, $\text{PF} \approx 1.17$–$1.24$, $\text{DD} \approx 1.0\%$–$1.9\%$).
   - En **`H4`, `M15` y `M5`**, la ventaja se expande significativamente en **$\text{RR} \in [2.5, 4.5]$**: en `H4`, el `Profit Factor` mediano sube de $1.3592$ ($\text{RR}=2.0$) a $1.6486$ ($\text{RR}=2.5$) y $2.1236$ ($\text{RR}=4.5$), pero cae abruptamente a $1.0681$ en $\text{RR}=5.0$ (indicando agotamiento del impulso antes de alcanzar $5\text{R}$).

![Gráfico 8: Heatmap ATR vs RR](08_heatmap_atr_vs_rr.png)

---

## 11. Interacciones Multidimensionales entre Parámetros

### 11.1 Tabla Cruzada Principal: `Temporalidad` $\times$ `InpMultiplicadorATR` (`Profit Factor` Mediano y Conteo para $\text{Trades} \ge 50$)

| Temporalidad | `0.50 ATR` | `0.75 ATR` | `1.00 ATR` | `1.25 ATR` | `1.50 ATR` | `1.75 ATR` | `2.00 ATR` | `2.25 ATR` | `2.50 ATR` |
|---|---|---|---|---|---|---|---|---|---|
| **M3** | S/M ($0$) | S/M ($0$) | S/M ($0$) | S/M ($0$) | S/M ($0$) | S/M ($0$) | S/M ($0$) | $1.0610$ ($11$) | $1.0541$ ($16$) |
| **M5** | S/M ($0$) | $1.0036$ ($1$) | $1.0539$ ($5$) | $1.0965$ ($11$) | $1.0540$ ($11$) | $1.0671$ ($10$) | $1.1009$ ($14$) | $1.1004$ ($14$) | **$1.2055$ ($24$)** |
| **M15** | S/M ($0$) | S/M ($0$) | S/M ($0$) | S/M ($0$) | S/M ($0$) | $1.1146$ ($7$) | **$1.2445$ ($11$)** | **$1.1841$ ($15$)** | **$1.2557$ ($13$)** |
| **M30** | $1.0484$ ($4$) | $1.1171$ ($7$) | $1.1005$ ($6$) | $1.0493$ ($8$) | $1.0320$ ($10$) | **$1.1375$ ($13$)** | $1.0585$ ($10$) | $1.0984$ ($2$) | S/M ($0$, $\max T=38$) |
| **H1** | $1.0745$ ($9$) | $1.0732$ ($17$) | **$1.1076$ ($13$)** | $1.0921$ ($15$) | $1.0393$ ($3$) | $1.0502$ ($8$) | $1.0632$ ($3$) | S/M ($0$, $\max T=39$) | S/M ($0$, $\max T=27$) |
| **H2** | $1.0887$ ($2$) | $1.0398$ ($1$) | $1.0096$ ($1$) | S/M ($0$) | S/M ($0$) | S/M ($0$) | S/M ($0$) | S/M ($0$, $\max T=8$) | S/M ($0$, $\max T=8$) |
| **H4** | **$1.6788$ ($8$)** | **$1.6550$ ($8$)** | **$1.3592$ ($3$)** | S/M ($0$, $\max T=35$) | S/M ($0$, $\max T=26$) | S/M ($0$, $\max T=25$) | S/M ($0$, $\max T=18$) | S/M ($0$, $\max T=16$) | S/M ($0$, $\max T=15$) |

*(Nota: `S/M` indica que ninguna configuración en esa celda alcanzó $\ge 50$ operaciones rentables; entre paréntesis se informa el conteo exacto de pases con $\text{Trades} \ge 50$ sobre un total de $45$ combinaciones evaluadas por celda $\text{TF} \times \text{ATR}$).*

### 11.2 Ley de Diagonalidad `Temporalidad` $\times$ `RangeATR`
La tabla cruzada anterior revela la **estructura fundamental del sistema**: los resultados válidos con muestra suficiente se disponen sobre una **diagonal descendente** desde el extremo superior derecho (`M3`/`M5`/`M15` con $\text{ATR} \in [1.75, 2.50]$) hacia el extremo inferior izquierdo (`H1`/`H4` con $\text{ATR} \in [0.50, 1.25]$):
- **Esquina superior izquierda (`M1`–`M15` con $\text{ATR} \le 1.50$):** vacía por **mortalidad operativa** ($\text{Profit} \le 0$). En temporalidades bajas, una vela de $0.50$–$1.25\text{ ATR}$ mide apenas $1.5$ a $4$ pips; el spread de entrada ($\le 1.0\text{ pip}$) representa entre el $25\%$ y el $60\%$ del riesgo $1\text{R}$, destruyendo la esperanza matemática.
- **Esquina inferior derecha (`H1`–`H4` con $\text{ATR} \ge 2.00$):** vacía de muestras $\ge 50$ por **escasez física de eventos**. En `H4` existen pases rentables en $\text{ATR} \in [1.25, 2.50]$ ($70$ pases en el XML), pero todos tienen entre $2$ y $35$ operaciones en $9.5$ meses.

---

## 12. Evaluación de Robustez y Detección de Sobreajuste

### 12.1 Análisis de Sensibilidad según Umbral Mínimo de Operaciones ($N \ge 50, 100, 200$)

| Filtro de Muestra Mínima | Pases que Superan el Filtro | % del XML ($731$) | % de la Grilla ($3{,}240$) | Beneficio Mediano | Profit Factor Mediano | Profit Factor P90 | Equity DD % Mediano | % Vecinos Orto Rentables (Mediana) | Pases en Clúster Robusto ($S_1\ge 75\%, \text{PF}\ge 1.10, \text{DD}\le 3.5\%$) |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| Sin filtro ($N \ge 1$) | $731$ | $100.00\%$ | $22.56\%$ | $\$526.43$ | $1.2206$ | $2.9186$ | $1.0010\%$ | $66.67\%$ | $291$ |
| Muestra $\ge 30$ trades | $405$ | $55.40\%$ | $12.50\%$ | $\$942.45$ | $1.1127$ | $1.4727$ | $1.8825\%$ | $66.67\%$ | $143$ |
| **Muestra $\ge 50$ trades (Base)** | **$314$** | **$42.95\%$** | **$9.69\%$** | **$\$967.90$** | **$1.0886$** | **$1.3802$** | **$2.3012\%$** | **$66.67\%$** | **$93$** |
| **Muestra $\ge 100$ trades** | **$178$** | **$24.35\%$** | **$5.49\%$** | **$\$999.62$** | **$1.0689$** | **$1.1950$** | **$2.9039\%$** | **$66.67\%$** | **$31$** |
| **Muestra $\ge 200$ trades** | **$66$** | **$9.03\%$** | **$2.04\%$** | **$\$1{,}178.35$** | **$1.0517$** | **$1.1167$** | **$3.6311\%$** | **$60.00\%$** | **$5$** |

### 12.2 Detección de Picos Aislados y Configuraciones Frágiles (Casos a Descartar)
El análisis topológico de vecindad permite detectar configuraciones que aparentan ser atractivas por beneficio o cantidad de operaciones, pero que constituyen **picos aislados o bordes inestables**:
1. **Picos aislados puros ($0\%$ a $25\%$ de vecinos ortogonales rentables, $33$ pases en el XML):**
   - `Pass 374` (`H2, Cuerpo=85%, ATR=0.50, RR=1.5`, $123$ trades, $\$215.75$, $\text{PF}=1.0289$): tiene **0 de 5 vecinos ortogonales rentables ($0.0\%$)** y **0 de 17 vecinos en su cubo $3\times 3\times 3$ rentables ($0.0\%$)**. Es una isla completamente rodeada de pérdidas.
   - `Pass 1564` (`M30, Cuerpo=80%, ATR=1.25, RR=3.0`, $332$ trades, $\$729.99$, $\text{PF}=1.0276$): solo $1/5$ vecinos ortogonales ($20\%$) y $1/17$ vecinos cúbicos ($5.88\%$) son rentables.
   - `Pass 524` (`M30, Cuerpo=80%, ATR=1.50, RR=1.5`, $255$ trades, $\$1{,}950.73$, $\text{PF}=1.1289$): aunque logra casi $\$2{,}000$ con $255$ trades, solo el **$23.53\%$ ($4/17$) de su cubo $3\times 3\times 3$** es rentable.
2. **Pases de alto beneficio absoluto pero margen por operación ínfimo y alto drawdown:**
   - `Pass 2338` (`M5, Cuerpo=90%, ATR=1.50, RR=4.0`, $545$ trades, Profit $\$3{,}072.89$, puesto #12 en beneficio del XML): su `Profit Factor` es apenas **$1.0614$**, su `Expected Payoff` es de solo $\$5.64/\text{trade}$, su `Equity DD %` sube a **$5.88\%$** y solo el $42.31\%$ de su cubo vecino es positivo. Un mínimo incremento del spread real en vivo convertiría este pase en perdedor.
   - `Pass 2089` (`M3, Cuerpo=85%, ATR=2.25, RR=3.5`, $323$ trades, Profit $\$3{,}099.59$, puesto #9 en beneficio del XML): presenta un `Profit Factor` de **$1.1102$** con `Equity DD %` de **$5.22\%$** y solo $50.0\%$ del cubo vecino rentable, siendo netamente inferior en estabilidad a su vecino `Pass 2129` ($\text{ATR}=2.50$, $213$ trades, $\text{PF}=1.1576$, $100\%$ vecinos ortogonales y $76.5\%$ del cubo rentable).

![Gráfico 10: Estabilidad entre Parámetros Vecinos](10_estabilidad_parametros_vecinos.png)

![Gráfico 12: Operaciones vs Estabilidad Aparente](12_operaciones_vs_estabilidad.png)

---

## 13. Clasificación de 20 Configuraciones Candidatas para Validación Independiente

> [!CAUTION]
> **Advertencia de Validación:** Ninguna de las 20 configuraciones listadas a continuación debe considerarse validada para operar con capital real. Han sido seleccionadas de un único período histórico (`2026.01.01 - 2026.10.17`) para representar **10 subregiones estructuralmente diversas y estables** (con $\text{Trades} \ge 50$, $\text{PF} \ge 1.15$, $\text{DD} \le 3.86\%$, $\ge 80\%$ de vecinos ortogonales rentables y **0% de redundancia entre sí**), con el único propósito de someterlas a pruebas fuera de muestra (*Out-of-Sample*).

### 13.1 Tabla Maestro de las 20 Configuraciones Candidatas

*(Nota: En todos los candidatos el modo de filtrado es `ATR` con `InpPeriodoATR = 14` fijo, `InpRiesgoPorcentaje = 1.0%` fijo e `InpSpreadMax_Pips = 1.0` fijo).*

| # | Pase | TF | Cuerpo | Filtro | Rango mín. (`ATR`) | RR | Trades | Profit ($\text{USD}$) | PF | DD % | Exp. Payoff | Rec. Factor | Sharpe | % Vecinos Orto ($S_1$) | % Cubo $3^3$ ($S_\infty$) | Mediana PF Vecinos |
|---:|---:|---|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| **1** | `1087` | **H4** | `80%` | ATR(14) | `0.50` | `2.5` | $76$ | $\$3{,}072.75$ | $1.6486$ | $0.85\%$ | $\$40.43$ | **$3.53$** | $2.90$ | **$100.0\%$** | $90.9\%$ | $1.5159$ |
| **2** | `2167` | **H4** | `80%` | ATR(14) | `0.50` | `4.0` | $60$ | $\$4{,}188.85$ | $1.9842$ | $1.72\%$ | $\$69.81$ | $2.37$ | $2.45$ | **$100.0\%$** | **$100.0\%$** | $1.9239$ |
| **3** | `2567` | **H4** | `80%` | ATR(14) | `0.75` | `4.5` | $55$ | $\$4{,}654.63$ | **$2.1820$** | $1.72\%$ | $\$84.63$ | $2.63$ | $2.60$ | **$100.0\%$** | $82.4\%$ | $1.9466$ |
| **4** | `1167` | **H4** | `80%` | ATR(14) | `1.00` | `2.5` | $52$ | $\$2{,}058.67$ | $1.6390$ | $0.87\%$ | $\$39.59$ | $2.34$ | $2.40$ | **$100.0\%$** | $94.1\%$ | $1.5428$ |
| **5** | `413` | **H1** | `85%` | ATR(14) | `0.75` | `1.5` | **$202$** | $\$2{,}291.76$ | $1.1952$ | $1.50\%$ | $\$11.35$ | $1.49$ | $2.14$ | **$100.0\%$** | $46.2\%$ | $1.0557$ |
| **6** | `845` | **H1** | `80%` | ATR(14) | `1.25` | `2.0` | $177$ | $\$1{,}825.01$ | $1.1549$ | $1.79\%$ | $\$10.31$ | $1.00$ | $1.12$ | $80.0\%$ | $47.1\%$ | $1.1039$ |
| **7** | `2941` | **H1** | `90%` | ATR(14) | `0.75` | `5.0` | $94$ | $\$1{,}935.79$ | $1.2334$ | $2.80\%$ | $\$20.59$ | $0.66$ | $0.98$ | **$100.0\%$** | **$100.0\%$** | $1.1827$ |
| **8** | `2005` | **H1** | `80%` | ATR(14) | `1.75` | `3.5` | $86$ | $\$1{,}500.52$ | $1.2189$ | $2.71\%$ | $\$17.45$ | $0.54$ | $0.94$ | $80.0\%$ | $52.9\%$ | $1.0541$ |
| **9** | `1660` | **M30** | `90%` | ATR(14) | `1.75` | `3.0` | $70$ | $\$2{,}076.50$ | $1.4259$ | $1.16\%$ | $\$29.66$ | $1.78$ | $2.64$ | **$100.0\%$** | $61.5\%$ | $1.2276$ |
| **10** | `460` | **M30** | `90%` | ATR(14) | `1.00` | `1.5` | $183$ | $\$1{,}830.56$ | $1.1715$ | $1.77\%$ | $\$10.00$ | $1.02$ | $2.53$ | $83.3\%$ | $57.7\%$ | $1.1171$ |
| **11** | `428` | **M30** | `95%` | ATR(14) | `0.75` | `1.5` | $72$ | $\$995.56$ | $1.2440$ | $1.03\%$ | $\$13.83$ | $0.96$ | $4.24$ | **$100.0\%$** | $65.4\%$ | $1.1195$ |
| **12** | `2099` | **M15** | `90%` | ATR(14) | `2.25` | `3.5` | $53$ | $\$2{,}466.01$ | $1.6675$ | $1.04\%$ | $\$46.53$ | $2.38$ | $4.39$ | $83.3\%$ | $69.2\%$ | $1.4807$ |
| **13** | `2131` | **M15** | `85%` | ATR(14) | `2.50` | `3.5` | $62$ | $\$2{,}488.80$ | $1.5622$ | $0.81\%$ | $\$40.14$ | $3.07$ | $4.20$ | **$100.0\%$** | $88.2\%$ | $1.3811$ |
| **14** | `2419` | **M15** | `90%` | ATR(14) | `2.00` | `4.0` | $87$ | $\$2{,}896.45$ | $1.4185$ | $2.25\%$ | $\$33.29$ | $1.24$ | $2.61$ | $83.3\%$ | $50.0\%$ | $1.2544$ |
| **15** | `1051` | **M15** | `85%` | ATR(14) | `2.50` | `2.0` | $64$ | $\$1{,}441.67$ | $1.3702$ | **$0.53\%$** | $\$22.53$ | $2.71$ | $4.10$ | **$100.0\%$** | $70.6\%$ | $1.1473$ |
| **16** | `1626` | **M5** | `95%` | ATR(14) | `1.50` | `3.0` | **$231$** | $\$3{,}634.20$ | $1.1942$ | $1.80\%$ | $\$15.73$ | $2.01$ | $4.01$ | **$100.0\%$** | $80.8\%$ | $1.0960$ |
| **17** | `1418` | **M5** | `90%` | ATR(14) | `2.50` | `2.5` | $75$ | $\$3{,}098.29$ | $1.6252$ | $1.51\%$ | $\$41.31$ | $1.97$ | $7.00$ | **$100.0\%$** | $82.4\%$ | $1.4439$ |
| **18** | `3178` | **M5** | `90%` | ATR(14) | `2.25` | `5.0` | $116$ | $\$2{,}980.51$ | $1.2932$ | $2.45\%$ | $\$25.69$ | $1.16$ | $2.39$ | **$100.0\%$** | $88.2\%$ | $1.1466$ |
| **19** | `1594` | **M5** | `100%` | ATR(14) | `1.25` | `3.0` | $74$ | $\$1{,}781.79$ | $1.2943$ | $1.69\%$ | $\$24.08$ | $1.02$ | **$7.55$** | **$100.0\%$** | $70.6\%$ | $1.0838$ |
| **20** | `2129` | **M3** | `85%` | ATR(14) | `2.50` | `3.5` | **$213$** | $\$2{,}838.30$ | $1.1576$ | $3.86\%$ | $\$13.33$ | $0.69$ | $2.12$ | **$100.0\%$** | $76.5\%$ | $1.1036$ |

![Gráfico 11: Mapa de las 20 Configuraciones Candidatas](11_mapa_configuraciones_candidatas.png)

### 13.2 Justificación Individual de cada Candidato (Fortaleza, Riesgo Estadístico y Vecino de Control)

1. **Candidato #1 — `Pass 1087` (`H4 | Cuerpo=80% | ATR=0.50 | RR=2.5`):**
   - *Por qué investigarlo:* Representa el extremo de menor riesgo y mayor eficiencia de recuperación de la meseta `H4` con ratio moderado ($\text{RR}=2.5$).
   - *Fortaleza:* Mayor `Recovery Factor` ($3.53$) de todos los pases con $\ge 50$ trades; `Equity DD %` de apenas $0.85\%$, $76$ operaciones y $100\%$ de vecinos ortogonales rentables.
   - *Riesgo estadístico:* Muestra acotada ($76$ trades) por la frecuencia natural de `H4`; subir el cuerpo a $85\%$ reduce la muestra a $42$ trades.
   - *Vecino de control:* `Pass 1127` (`H4, Cuerpo=80%, ATR=0.75, RR=2.5` $\to$ $65$ trades, $\$2{,}825.46$, $\text{PF}=1.7102$, $\text{DD}=0.85\%$).
2. **Candidato #2 — `Pass 2167` (`H4 | Cuerpo=80% | ATR=0.50 | RR=4.0`):**
   - *Por qué investigarlo:* Es el centro geométrico de la meseta de alta asimetría en `H4`.
   - *Fortaleza:* $100\%$ de vecinos ortogonales y **$100\%$ de su cubo $3\times 3\times 3$ rentables**, con $\text{PF}=1.9842$, $\$4{,}188.85$ y $60$ operaciones.
   - *Riesgo estadístico:* $\text{RR}=4.0$ exige tolerar menor porcentaje de aciertos ($W_{\text{BE}}=20\%$) y mayor varianza por racha.
   - *Vecino de control:* `Pass 2207` (`H4, Cuerpo=80%, ATR=0.75, RR=4.0` $\to$ $55$ trades, $\$3{,}708.49$, $\text{PF}=1.9466$, $\text{DD}=1.76\%$).
3. **Candidato #3 — `Pass 2567` (`H4 | Cuerpo=80% | ATR=0.75 | RR=4.5`):**
   - *Por qué investigarlo:* Alcanza el máximo `Profit Factor` ($2.1820$) y máximo `Expected Payoff` ($\$84.63$) entre los $314$ pases con muestra $\ge 50$.
   - *Fortaleza:* Vecindad ortogonal $100\%$ rentable con mediana vecina de $\text{PF}=1.9466$ y $\text{DD}=1.72\%$.
   - *Riesgo estadístico:* $55$ operaciones (cerca del corte de $50$) y alta dependencia de grandes recorridos tendenciales ($4.5\text{R}$).
   - *Vecino de control:* `Pass 2527` (`H4, Cuerpo=80%, ATR=0.50, RR=4.5` $\to$ $60$ trades, $\$4{,}658.96$, $\text{PF}=2.0653$, $\text{DD}=2.01\%$).
4. **Candidato #4 — `Pass 1167` (`H4 | Cuerpo=80% | ATR=1.00 | RR=2.5`):**
   - *Por qué investigarlo:* Verifica el comportamiento de `H4` cuando se exige que la vela gatillo supere al menos $1.00\text{ ATR}$ completo.
   - *Fortaleza:* $\text{PF}=1.6390$, $\text{DD}=0.87\%$, $100\%$ de vecinos ortogonales y $94.1\%$ del cubo $3\times 3\times 3$ rentables.
   - *Riesgo estadístico:* $52$ operaciones (en el límite del filtro exploratorio); en $1.25\text{ ATR}$ la muestra baja a $35$ trades.
   - *Vecino de control:* `Pass 1127` (`H4, Cuerpo=80%, ATR=0.75, RR=2.5` $\to$ $65$ trades, $\$2{,}825.46$, $\text{PF}=1.7102$).
5. **Candidato #5 — `Pass 413` (`H1 | Cuerpo=85% | ATR=0.75 | RR=1.5`):**
   - *Por qué investigarlo:* Principal representante del enfoque de **alta frecuencia en `H1` con objetivo corto ($\text{RR}=1.5$)**.
   - *Fortaleza:* Supera el umbral más estricto de **200 operaciones ($202$ trades)** con $\text{PF}=1.1952$, $\text{DD}=1.50\%$, $\text{RF}=1.49$ y $100\%$ de vecinos ortogonales rentables.
   - *Riesgo estadístico:* En las diagonales del cubo $3\times 3\times 3$ ($46.2\%$ rentable) cae el rendimiento si se sube simultáneamente el cuerpo a $90\%$ y el RR a $2.5$.
   - *Vecino de control:* `Pass 773` (`H1, Cuerpo=85%, ATR=0.75, RR=2.0` $\to$ $188$ trades, $\$2{,}356.47$, $\text{PF}=1.1902$, $\text{DD}=1.95\%$).
6. **Candidato #6 — `Pass 845` (`H1 | Cuerpo=80% | ATR=1.25 | RR=2.0`):**
   - *Por qué investigarlo:* Evalúa en `H1` la combinación de cuerpo más flexible ($80\%$) compensada por mayor exigencia de rango ($1.25\text{ ATR}$).
   - *Fortaleza:* $177$ operaciones, $\text{PF}=1.1549$, $\text{DD}=1.79\%$ y $80\%$ de vecinos ortogonales positivos.
   - *Riesgo estadístico:* `Expected Payoff` moderado ($\$10.31$), sensible a incrementos de costos operativos.
   - *Vecino de control:* `Pass 485` (`H1, Cuerpo=80%, ATR=1.25, RR=1.5` $\to$ $193$ trades, $\$1{,}629.21$, $\text{PF}=1.1422$, $\text{DD}=1.72\%$).
7. **Candidato #7 — `Pass 2941` (`H1 | Cuerpo=90% | ATR=0.75 | RR=5.0`):**
   - *Por qué investigarlo:* Representa una segunda meseta independiente en `H1` basada en cuerpo muy limpio ($90\%$) y captura de tendencias largas ($\text{RR}=5.0$).
   - *Fortaleza:* **$100\%$ de vecinos ortogonales y $100\%$ del cubo $3\times 3\times 3$ rentables**, $94$ operaciones y $\text{PF}=1.2334$.
   - *Riesgo estadístico:* $\text{RR}=5.0$ implica rachas de pérdidas más largas ($\text{DD}=2.80\%$, $\text{RF}=0.66$).
   - *Vecino de control:* `Pass 2581` (`H1, Cuerpo=90%, ATR=0.75, RR=4.5` $\to$ $94$ trades, $\$1{,}620.88$, $\text{PF}=1.2018$, $\text{DD}=2.27\%$).
8. **Candidato #8 — `Pass 2005` (`H1 | Cuerpo=80% | ATR=1.75 | RR=3.5`):**
   - *Por qué investigarlo:* Explora el régimen de velas de expansión fuerte en `H1` ($\text{ATR}=1.75$).
   - *Fortaleza:* $86$ operaciones con $\text{PF}=1.2189$, $\$1{,}500.52$ y $80\%$ de vecinos ortogonales rentables.
   - *Riesgo estadístico:* Subir el filtro por encima de $2.00\text{ ATR}$ en `H1` deja menos de $50$ operaciones.
   - *Vecino de control:* `Pass 2045` (`H1, Cuerpo=80%, ATR=2.00, RR=3.5` $\to$ $56$ trades, $\$919.31$, $\text{PF}=1.2088$, $\text{DD}=1.55\%$).
9. **Candidato #9 — `Pass 1660` (`M30 | Cuerpo=90% | ATR=1.75 | RR=3.0`):**
   - *Por qué investigarlo:* Es la configuración más sólida de `M30` en el régimen de expansión de volatilidad.
   - *Fortaleza:* Mayor beneficio ($\$2{,}076.50$) y mayor $\text{PF}$ ($1.4259$) en `M30` con $T\ge 50$; $70$ operaciones, $\text{DD}=1.16\%$ y $100\%$ de vecinos ortogonales rentables.
   - *Riesgo estadístico:* Al bajar el cuerpo a $85\%$ en `M30` la rentabilidad se degrada.
   - *Vecino de control:* `Pass 1300` (`M30, Cuerpo=90%, ATR=1.75, RR=2.5` $\to$ $70$ trades, $\$935.15$, $\text{PF}=1.1929$, $\text{DD}=1.18\%$).
10. **Candidato #10 — `Pass 460` (`M30 | Cuerpo=90% | ATR=1.00 | RR=1.5`):**
    - *Por qué investigarlo:* Evalúa `M30` en un régimen de alta frecuencia ($183$ trades) y salida rápida ($\text{RR}=1.5$).
    - *Fortaleza:* $183$ operaciones (casi $200$), $\text{PF}=1.1715$, $\$1{,}830.56$, $\text{DD}=1.77\%$ y $83.3\%$ de vecinos ortogonales rentables.
    - *Riesgo estadístico:* Menor beneficio esperado por operación ($\$10.00$) frente a configuraciones con $\text{ATR}=1.75$.
    - *Vecino de control:* `Pass 420` (`M30, Cuerpo=90%, ATR=0.75, RR=1.5` $\to$ $230$ trades, $\$1{,}619.33$, $\text{PF}=1.1171$, $\text{DD}=1.78\%$).
11. **Candidato #11 — `Pass 428` (`M30 | Cuerpo=95% | ATR=0.75 | RR=1.5`):**
    - *Por qué investigarlo:* Representa el subespacio de velas cuasi-Marubozu ($\text{Cuerpo}=95\%$) con umbral ATR bajo en `M30`.
    - *Fortaleza:* $72$ operaciones, $\text{PF}=1.2440$, $\text{DD}=1.03\%$, $\text{Sharpe}=4.24$ y $100\%$ de vecinos ortogonales rentables.
    - *Riesgo estadístico:* Con $95\%$ de cuerpo, si se exige simultáneamente $\text{ATR} \ge 1.50$, la muestra en `M30` cae por debajo de $50$ trades.
    - *Vecino de control:* `Pass 68` (`M30, Cuerpo=95%, ATR=0.75, RR=1.0` $\to$ $75$ trades, $\$779.61$, $\text{PF}=1.2214$, $\text{DD}=1.06\%$).
12. **Candidato #12 — `Pass 2099` (`M15 | Cuerpo=90% | ATR=2.25 | RR=3.5`):**
    - *Por qué investigarlo:* Máximo `Profit Factor` ($1.6675$) en `M15` con muestra $\ge 50$.
    - *Fortaleza:* Excelente relación retorno/riesgo ($\text{Profit}=\$2{,}466.01$, $\text{DD}=1.04\%$, $\text{RF}=2.38$, $\text{Sharpe}=4.39$) y mediana vecina de $\text{PF}=1.4807$.
    - *Riesgo estadístico:* Muestra de $53$ operaciones (justo por encima del umbral de $50$).
    - *Vecino de control:* `Pass 1739` (`M15, Cuerpo=90%, ATR=2.25, RR=3.0` $\to$ $53$ trades, $\$2{,}059.91$, $\text{PF}=1.5748$, $\text{DD}=1.14\%$).
13. **Candidato #13 — `Pass 2131` (`M15 | Cuerpo=85% | ATR=2.50 | RR=3.5`):**
    - *Por qué investigarlo:* Centro de la meseta más estable de `M15` con $\text{Cuerpo}=85\%$.
    - *Fortaleza:* $100\%$ de vecinos ortogonales y $88.2\%$ del cubo $3\times 3\times 3$ rentables; $62$ trades, $\text{PF}=1.5622$, $\text{DD}=0.81\%$ y $\text{RF}=3.07$.
    - *Riesgo estadístico:* Situado en el borde superior de la grilla explorada de ATR ($2.50$), por lo que no se observa el vecino en $2.75\text{ ATR}$.
    - *Vecino de control:* `Pass 2491` (`M15, Cuerpo=85%, ATR=2.50, RR=4.0` $\to$ $59$ trades, $\$2{,}665.19$, $\text{PF}=1.6060$, $\text{DD}=0.81\%$).
14. **Candidato #14 — `Pass 2419` (`M15 | Cuerpo=90% | ATR=2.00 | RR=4.0`):**
    - *Por qué investigarlo:* Mayor beneficio absoluto en `M15` ($\$2{,}896.45$) con una muestra más holgada ($87$ operaciones).
    - *Fortaleza:* $\text{PF}=1.4185$, $87$ trades y $83.3\%$ de vecinos ortogonales rentables.
    - *Riesgo estadístico:* Se ubica cerca del límite inferior de activación de `M15` (en $1.75\text{ ATR}$ el $\text{PF}$ baja a $1.1872$ y en $1.50\text{ ATR}$ no es rentable).
    - *Vecino de control:* `Pass 2459` (`M15, Cuerpo=90%, ATR=2.25, RR=4.0` $\to$ $51$ trades, $\$1{,}872.13$, $\text{PF}=1.4807$, $\text{DD}=1.38\%$).
15. **Candidato #15 — `Pass 1051` (`M15 | Cuerpo=85% | ATR=2.50 | RR=2.0`):**
    - *Por qué investigarlo:* Evalúa la expansión extrema en `M15` con un objetivo conservador ($\text{RR}=2.0$).
    - *Fortaleza:* **Menor `Equity DD %` ($0.5303\%$) de todos los 314 pases con $\ge 50$ operaciones**, con $64$ trades, $\text{PF}=1.3702$, $\text{RF}=2.71$ y $100\%$ de vecinos ortogonales rentables.
    - *Riesgo estadístico:* Borde superior de la grilla en $\text{ATR}=2.50$.
    - *Vecino de control:* `Pass 1771` (`M15, Cuerpo=85%, ATR=2.50, RR=3.0` $\to$ $64$ trades, $\$1{,}718.59$, $\text{PF}=1.3811$, $\text{DD}=0.82\%$).
16. **Candidato #16 — `Pass 1626` (`M5 | Cuerpo=95% | ATR=1.50 | RR=3.0`):**
    - *Por qué investigarlo:* Es la **mejor configuración de gran tamaño muestral ($\ge 200$ operaciones)** de toda la optimización.
    - *Fortaleza:* **$231$ operaciones** con $\$3{,}634.20$ de beneficio (puesto #6 global del XML), $\text{PF}=1.1942$, $\text{DD}=1.80\%$, $\text{RF}=2.01$, $\text{Sharpe}=4.01$, $100\%$ de vecinos ortogonales y $80.8\%$ del cubo rentables.
    - *Riesgo estadístico:* En `M5` con $\text{ATR}=1.50$, el SL en pips es moderado, por lo que requiere ejecución con spread controlado ($\le 1.0\text{ pip}$) y bajo slippage.
    - *Vecino de control:* `Pass 1986` (`M5, Cuerpo=95%, ATR=1.50, RR=3.5` $\to$ $226$ trades, $\$2{,}842.15$, $\text{PF}=1.1478$, $\text{DD}=1.90\%$).
17. **Candidato #17 — `Pass 1418` (`M5 | Cuerpo=90% | ATR=2.50 | RR=2.5`):**
    - *Por qué investigarlo:* Representa el régimen de **máxima selectividad por ATR en `M5`**.
    - *Fortaleza:* Mayor $\text{PF}$ en `M5` con $\ge 50$ operaciones ($\text{PF}=1.6252$, $75$ trades, $\$3{,}098.29$, $\text{DD}=1.51\%$, $\text{Sharpe}=7.00$), con $100\%$ de vecinos ortogonales y $82.4\%$ del cubo rentables.
    - *Riesgo estadístico:* En el borde superior de la grilla explorada ($\text{ATR}=2.50$).
    - *Vecino de control:* `Pass 1778` (`M5, Cuerpo=90%, ATR=2.50, RR=3.0` $\to$ $75$ trades, $\$2{,}908.58$, $\text{PF}=1.5395$, $\text{DD}=1.51\%$).
18. **Candidato #18 — `Pass 3178` (`M5 | Cuerpo=90% | ATR=2.25 | RR=5.0`):**
    - *Por qué investigarlo:* Mejor configuración de `M5` con **más de 100 operaciones ($116$ trades)** y alto ratio riesgo/beneficio.
    - *Fortaleza:* $\text{PF}=1.2932$, $\$2{,}980.51$, $\text{DD}=2.45\%$, $100\%$ de vecinos ortogonales y $88.2\%$ del cubo $3\times 3\times 3$ rentables.
    - *Riesgo estadístico:* Ubicado en el borde superior de $\text{RR}=5.0$.
    - *Vecino de control:* `Pass 2818` (`M5, Cuerpo=90%, ATR=2.25, RR=4.5` $\to$ $116$ trades, $\$2{,}824.87$, $\text{PF}=1.2837$, $\text{DD}=2.73\%$).
19. **Candidato #19 — `Pass 1594` (`M5 | Cuerpo=100% | ATR=1.25 | RR=3.0`):**
    - *Por qué investigarlo:* Única subregión donde el filtro de **vela Marubozu pura ($\text{Cuerpo}=100\%$)** conserva muestra estadística suficiente ($74$ operaciones).
    - *Fortaleza:* $\text{PF}=1.2943$, $\$1{,}781.79$, $\text{DD}=1.69\%$, $\text{Sharpe}=7.55$ y $100\%$ de vecinos ortogonales rentables.
    - *Riesgo estadístico:* La condición $\text{Close}=\text{High}$ o $\text{Close}=\text{Low}$ exacta ($100\%$ cuerpo) es sensible al feed de ticks del broker.
    - *Vecino de control:* `Pass 1954` (`M5, Cuerpo=100%, ATR=1.25, RR=3.5` $\to$ $73$ trades, $\$1{,}338.13$, $\text{PF}=1.2131$, $\text{DD}=1.74\%$).
20. **Candidato #20 — `Pass 2129` (`M3 | Cuerpo=85% | ATR=2.50 | RR=3.5`):**
    - *Por qué investigarlo:* Único clúster con muestra $>200$ operaciones que sobrevive en la temporalidad ultra-corta `M3`.
    - *Fortaleza:* $213$ operaciones, $\$2{,}838.30$, $\text{PF}=1.1576$, $100\%$ de vecinos ortogonales y $76.5\%$ del cubo $3\times 3\times 3$ rentables.
    - *Riesgo estadístico:* Mayor `Equity DD %` de los 20 candidatos ($3.86\%$) y elevada sensibilidad al costo de spread/slippage en `M3`.
    - *Vecino de control:* `Pass 2489` (`M3, Cuerpo=85%, ATR=2.50, RR=4.0` $\to$ $213$ trades, $\$1{,}936.00$, $\text{PF}=1.1036$, $\text{DD}=3.77\%$).

---

## 14. Limitaciones del Archivo XML de Optimización

Se diferencia explícitamente qué información **está demostrada** por el XML y qué información **no existe en el archivo y no puede inventarse**:

| Dimensión Analítica | ¿Determinable desde `ReportOptimizer-ATR.xml`? | Alcance Exacto y Limitación |
|---|---|---|
| **Métricas agregadas por pase (`Profit`, `PF`, `EP`, `DD%`, `RF`, `Sharpe`, `Trades`)** | **SÍ (en los $731$ pases con $\text{Profit}>0$)** | Valores finales exactos del período `2026.01.01 - 2026.10.17`. Faltan las métricas de los $2{,}509$ pases con $\text{Profit}\le 0$ por haberse exportado con *Skip Useless Results*. |
| **Ganancia Bruta y Pérdida Bruta agregadas (`Gross Profit`, `Gross Loss`)** | **SÍ (Cálculo derivado exacto)** | Recuperables exactamente mediante $\text{GL} = \text{Profit}/(\text{PF}-1)$ y $\text{GP} = \text{Profit}+\text{GL}$ porque todos los pases exportados cumplen $\text{PF} > 1$. |
| **Operaciones individuales y secuencia de ganancias/pérdidas** | **NO** | El XML no contiene tickets, precios ni fechas de entrada/salida. No puede probarse igualdad de operaciones entre pases ni calcularse rachas máximas ganadoras/perdedoras. |
| **Tasa de acierto real (*Win Rate*)** | **NO** | No se exportan `Winning Trades` ni `Losing Trades`. Por el interés compuesto del riesgo ($1\%$ del balance) y redondeo de lotes, no puede despejarse de forma exacta a partir de $\text{PF}$ y $\text{RR}$. |
| **Comisiones desglosadas y Spread real de cada entrada** | **NO** | Solo se conoce por el código que el EA filtra $\text{Spread} \le 1.0\text{ pip}$, pero no el spread medio pagado ni si la cuenta `FivePercentOnline-Real` aplicó comisión por lote. |
| **Excursión Máxima Favorable (MFE) y Adversa (MAE)** | **NO** | Requiere instrumentación en código (`MODE_RESEARCH` / `ResearchLevels.csv`). |
| **Duración de operaciones y primera llegada a niveles $R$** | **NO** | Indeterminable desde el XML; impide saber cuánto tiempo permanece expuesto el capital o cuántas órdenes se acumulan simultáneamente en la misma dirección. |
| **Estabilidad temporal interna (resultados por mes o trimestre)** | **NO** | Un pase con $\$3{,}000$ de beneficio podría haber ganado $\$4{,}000$ en un solo mes de alta volatilidad y perdido $\$1{,}000$ en los otros $8.5$ meses. |

---

## 15. Recomendaciones para la Siguiente Etapa

### A. Cómo Mejorar la Próxima Optimización en MT5
1. **Desactivar obligatoriamente "Skip Useless Results" (*Omitir resultados inútiles*) antes de exportar el XML:** esto permitirá observar los $3{,}240$ pases completos, cuantificar la pendiente de caída hacia terreno negativo en los bordes de cada meseta y medir la distribución completa de pérdidas.
2. **Separar la grilla de `InpMultiplicadorATR` según la familia de temporalidad (evitando combinaciones estériles):**
   - **Descartar `M1` (`InpTimeframe = 0`) y `H2` (`InpTimeframe = 6`):** `M1` tuvo $0/405$ pases rentables y `H2` carece de tamaño muestral ($95\%$ de sus pases tienen $< 50$ trades).
   - **En `M5` y `M15`:** no evaluar $\text{InpMultiplicadorATR} \in [0.50, 1.25]$ (zona muerta por ruido y costos); explorar en su lugar el intervalo **`[1.50, 3.50]` con paso `0.25`** (ya que en $2.50\text{ ATR}$ la curva sigue en su máximo y necesitamos observar dónde decae la muestra entre $2.75$ y $3.50\text{ ATR}$).
   - **En `M30`, `H1` y `H4`:** concentrar `InpMultiplicadorATR` en **`[0.40, 2.00]` con paso `0.20`**, evitando valores $> 2.00\text{ ATR}$ que reducen las operaciones por debajo del umbral estadístico.
3. **Acotar `InpPorcentajeCuerpo` a `[75%, 95%]` con paso `5%`:** eliminar `100%` en temporalidades $\ge \text{M15}$ (donde produce muestras de $1$ a $14$ trades y genera redundancia) e incluir `75%` en `H1`/`H4` para verificar si amplía la muestra de `H4` por encima de $100$ operaciones sin degradar el `Profit Factor`.

### B. Procedimiento de Validación Fuera de Muestra (*Out-of-Sample* / OOS)
1. **Congelar los parámetros exactos de los 20 candidatos (`Top_20_Candidatos.csv`) y sus respectivos pases vecinos de control** sin reoptimizar.
2. **Ejecutar backtests individuales (con modelado "Cada tick basado en ticks reales") en dos bloques temporales independientes no utilizados en esta optimización:**
   - **OOS Histórico Anterior (*Back-test OOS*):** `2024.01.01 - 2025.12.31` ($24$ meses completos que contienen distintos regímenes de volatilidad y tasas de interés en `EURUSD`).
   - **OOS Posterior (*Forward-test*):** desde `2026.10.18` en adelante.
3. **Criterio de aceptación OOS:** una región candidata solo se considerará validada si **tanto el pase candidato como su pase vecino de control** mantienen $\text{Profit Factor} > 1.15$, $\text{Expected Payoff} > 0$, estabilidad semestral positiva y ausencia de rachas que superen $1.5 \times \text{DD}_{\text{IS}}$ en el período `2024–2025`.

### C. Datos Adicionales y Telemetría Requeridos (`MODE_RESEARCH`)
Para verificar si la ventaja observada proviene de una asimetría real en la microestructura posterior a velas impulsivas, conviene instrumentar un modo de telemetría (`ResearchSignals.csv` y `ResearchLevels.csv`) que registre para cada vela gatillo:
- Rango en pips, valor exacto de $\text{ATR}_{14}$, ratio $\text{Rango}/\text{ATR}$ y porcentaje de cuerpo.
- Excursión máxima favorable (MFE) y adversa (MAE) medidas en múltiplos de $R$ antes de tocar el extremo opuesto de la vela ($-1R$).
- Probabilidad empírica de primera llegada (*First-Passage Time*) a $+1R, +2R, +3R, +4R, +5R$ antes de $-1R$, desglosada por sesión horaria (Londres, Nueva York, Asia) y número de posiciones simultáneas abiertas.

---

## 16. Conclusión Final Obligatoria (Respuesta a las 10 Preguntas Clave)

### 1. ¿Qué aprendimos sobre la continuación de velas impulsivas?
- **Hecho comprobado / Cálculo derivado:** De las $3{,}240$ combinaciones evaluadas en `EURUSD`, solo $731$ ($22.56\%$) obtuvieron beneficio positivo y solo $314$ ($9.69\%$) superaron las $50$ operaciones. Entre estas últimas, los ratios $\text{RR} \in [2.5, 4.5]$ superan ampliamente a $\text{RR} = 1.0$ en beneficio mediano ($\$935$–$\$1{,}261$ vs $\$433$) y `Profit Factor` ($1.10$–$1.11$ vs $1.078$).
- **Interpretación:** La continuación inmediata tras una vela de intención **no es un fenómeno universal en cualquier vela grande**, sino un efecto condicional que requiere filtrar el ruido de la temporalidad y dejar correr las ganancias entre $2.5\text{R}$ y $4.5\text{R}$ para compensar las falsas rupturas.

### 2. ¿Qué temporalidades presentan las regiones de resultados más favorables?
- **Hecho comprobado:**
  - Por **eficiencia y `Profit Factor` con $\ge 50$ trades:** **`H4`** ($\text{PF mediano} = 1.6390$, beneficio mediano $\$2{,}361.71$, DD mediano $1.72\%$) y **`M15`** ($\text{PF mediano} = 1.1713$, beneficio mediano $\$1{,}467.11$, DD mediano $1.56\%$).
  - Por **amplitud de muestra ($\ge 100$ y $\ge 200$ trades) y densidad de mesetas:** **`M5`** ($90$ pases con $T\ge 50$ y $23$ con $T\ge 200$) y **`H1`** ($164/405 = 40.49\%$ de la grilla rentable y $68$ pases con $T\ge 50$).
  - **Temporalidades desfavorables:** **`M1`** ($0/405$ rentables) y **`H2`** (mediana de $6$ operaciones y $40.96\%$ de redundancia).

### 3. ¿El filtro `RangeATR` aporta más información que el filtro de pips?
- **Cálculo derivado (comparación controlada):** **Sí, de manera contundente.** En el subespacio común controlado, el filtro `InpMultiplicadorATR` reduce la redundancia entre pases rentables del **$53.57\%$ (PIPS) al $8.61\%$ (ATR)** globalmente, del **$85.96\%$ al $0.00\%$ en `H4`**, y del **$34.62\%$ al $0.00\%$ en configuraciones con $\ge 50$ operaciones**, además de triplicar el beneficio mediano en `M5` y `M15`.
- **Interpretación:** El ATR normaliza el umbral respecto a la volatilidad de cada marco temporal y régimen de mercado, logrando una separación informativa de señales que un umbral fijo en pips no puede ofrecer.

### 4. ¿Cuántos pases de optimización fueron redundantes?
- **Hecho comprobado:** En `ReportOptimizer-ATR.xml` existen exactamente **42 pases redundantes ($5.75\%$ de los $731$ exportados)**, dejando **689 configuraciones con resultados distintos ($94.25\%$)**. Esos $42$ pases forman parte de $33$ clústeres de métricas idénticas ($75$ pases involucrados en total) generados al $100\%$ por variar `InpMultiplicadorATR` en configuraciones extremas de **$\le 8$ operaciones** (`M30` con $\text{Cuerpo}=100\%$ y `H2` con $\text{Cuerpo}\in\{85\%,90\%,100\%\}$). Para $\text{Trades} \ge 9$ ($556$ pases) y $\text{Trades} \ge 50$ ($314$ pases), hubo **0 pases redundantes ($0.00\%$)**.

### 5. ¿Qué parámetros tienen mayor influencia aparente sobre los resultados?
- **Cálculo derivado / Interpretación:** En orden jerárquico de impacto estructural:
  1. **La interacción `InpTimeframe` $\times$ `InpMultiplicadorATR`:** determina la viabilidad misma de la estrategia (en `M3`/`M15` exige $\ge 1.75$–$2.25\text{ ATR}$ para ser rentable; en `H1`/`H4` concentra las muestras válidas en $0.50$–$1.25\text{ ATR}$).
  2. **`InpPorcentajeCuerpo`:** controla drásticamente la frecuencia muestral (pasar de $90\%$ a $100\%$ hunde la mediana global de operaciones de $74.5$ a $4.0$).
  3. **`InpRR`:** modula la captura de cola derecha y el drawdown (subir de $\text{RR}=1.0$ a $\text{RR}=3.5$–$4.0$ casi triplica el beneficio mediano con $T\ge 50$, a cambio de elevar el drawdown mediano de $1.32\%$ a $2.89\%$).

### 6. ¿Qué combinaciones muestran mayor estabilidad entre parámetros vecinos?
- **Cálculo derivado:** Las cuatro regiones tipo meseta con $100\%$ de supervivencia ortogonal ($S_1 = 100\%$) y alta supervivencia cúbica ($S_\infty \ge 75\%$) son:
  1. **`H4`:** $\text{Cuerpo} = 80\%$, $\text{ATR} \in [0.50, 1.00]$, $\text{RR} \in [2.5, 4.5]$ ($S_1 = 100\%$, $S_\infty = 82\%$–$100\%$, $\text{PF} = 1.60$–$2.18$).
  2. **`M5`:** $\text{Cuerpo} \in [85\%, 95\%]$, $\text{ATR} \in [1.50, 2.50]$, $\text{RR} \in [2.5, 4.5]$ ($S_1 = 100\%$, $S_\infty = 80\%$–$100\%$, $74$ a $231$ trades).
  3. **`M15`:** $\text{Cuerpo} \in [85\%, 90\%]$, $\text{ATR} \in [2.00, 2.50]$, $\text{RR} \in [2.0, 4.0]$ ($S_1 = 83\%$–$100\%$, $S_\infty = 69\%$–$88\%$, $\text{PF} = 1.37$–$1.67$).
  4. **`H1`:** $\text{Cuerpo} \in [85\%, 90\%]$, $\text{ATR} \in [0.50, 1.00]$, tanto en $\text{RR} \in [1.5, 2.0]$ ($188$–$202$ trades) como en $\text{RR} \in [4.5, 5.0]$ ($S_\infty = 92\%$–$100\%$).

### 7. ¿Qué configuraciones conviene descartar?
- **Recomendación basada en hechos y cálculos:**
  1. Todas las configuraciones con **$\text{Trades} < 50$** ($417$ pases en el XML), incluidos **todos los pases con $\text{Profit Factor} > 2.20$** (que tienen $\le 45$ operaciones, o $\le 9$ operaciones cuando $\text{PF} > 3.0$).
  2. Las temporalidades **`M1`** ($0\%$ rentable) y **`H2`** (muestra insuficiente y alta redundancia).
  3. El parámetro **`InpPorcentajeCuerpo = 100%`** en todas las temporalidades salvo `M5` (por colapso muestral y redundancia).
  4. Los **picos aislados** con baja estabilidad vecina ($S_1 \le 25\%$ o $S_\infty \le 30\%$, como `Pass 374`, `Pass 1564`, `Pass 524`, `Pass 2324`) y los pases de alta frecuencia con `Expected Payoff` marginal y alto drawdown (`Pass 2338`, `Pass 1978`).

### 8. ¿Cuáles merecen una validación fuera de muestra?
- **Recomendación:** Los **20 candidatos diversificados** documentados en la Sección 13 y en `Top_20_Candidatos.csv`, priorizando cinco cabezas de serie por familia:
  - **`Pass 1087` y `Pass 2167` en `H4`** (`Cuerpo=80%, ATR=0.50, RR=2.5 y 4.0`).
  - **`Pass 1626` y `Pass 1418` en `M5`** (`Cuerpo=95%, ATR=1.50, RR=3.0` con $231$ trades, y `Cuerpo=90%, ATR=2.50, RR=2.5` con $75$ trades).
  - **`Pass 2131` y `Pass 2419` en `M15`** (`Cuerpo=85%–90%, ATR=2.00–2.50, RR=3.5–4.0`).
  - **`Pass 413` y `Pass 2941` en `H1`** (`Cuerpo=85%, ATR=0.75, RR=1.5` con $202$ trades, y `Cuerpo=90%, ATR=0.75, RR=5.0`).
  - **`Pass 1660` y `Pass 460` en `M30`** (`Cuerpo=90%, ATR=1.75, RR=3.0` y `ATR=1.00, RR=1.5`).

### 9. ¿Qué información falta para evaluar la ventaja estadística real?
- **Hecho comprobado:** Faltan el registro de operaciones individuales (fechas, precios, direcciones, volumen), la tasa de acierto real (*win rate*), la descomposición mensual/trimestral de la curva de equidad, la concurrencia de posiciones simultáneas abiertas, el impacto de comisiones/slippage real y las distribuciones de MFE/MAE por señal.

### 10. ¿Cuál debería ser el próximo experimento cuantitativo?
- **Recomendación:** Ejecutar una **validación fuera de muestra (*Out-of-Sample*) en el período histórico reservado `2024.01.01 - 2025.12.31` ($24$ meses)** sobre los **20 pases candidatos y sus 20 vecinos de control** utilizando ticks reales en MT5, exportando el informe detallado de operaciones de cada pase para medir la estabilidad interanual, el *win rate* efectivo, la concurrencia de órdenes y la supervivencia real de las cuatro mesetas identificadas (`H4`, `M5`, `M15`, `H1`).
